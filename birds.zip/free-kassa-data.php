<?

# Автоподгрузка классов
function __autoload($name){ include("classes/_class.".$name.".php");}

# Класс конфига 
$config = new config;

# Функции
$func = new func;


$fk_merchant_id = $config->free_id; //merchant_id ID магазина free-kassa.ru http://free-kassa.ru/merchant/cabinet/help/
$fk_merchant_key = $config->free_key; //Секретный ключ http://free-kassa.ru/merchant/cabinet/profile/tech.php

if (isset($_GET['prepare_once'])) {
    $hash = md5($fk_merchant_id.":".$_GET['oa'].":".$fk_merchant_key.":".$_GET['l']);
    echo '<hash>'.$hash.'</hash>';
    exit;
}
?>