<?php
session_start();

define('TIME', time());
define('BASE_DIR', $_SERVER['DOCUMENT_ROOT']);

if (!isset($_SESSION['user_id'])) { exit(); }

function __autoload($name){ include(BASE_DIR."/classes/_class.".$name.".php");}

$config = new config;

$db = new db($config->HostDB, $config->UserDB, $config->PassDB, $config->BaseDB);

$db->Query("SET NAMES 'utf8'");
$db->Query("SET CHARACTER SET 'utf8'");
$db->Query("SET SESSION collation_connection = 'utf8_general_ci'");

$id = (int)$_GET['view'];

$db->query("SELECT * FROM db_serfing WHERE id = '".$id."' and money >= price and status = '2' LIMIT 1");

if ($db->NumRows())
{
    $result = $db->FetchArray();

    $_SESSION['view']['cnt'] = md5(session_id().$_SESSION['user_id'].$result['id']);
    $_SESSION['view']['id'] = $result['id'];
    //if ($result['timer']) {
        $_SESSION['view']['timer'] = $result['timer'];
    //}else{
        //$_SESSION['view']['timer'] = 10;
    //}
    $_SESSION['view']['timestart'] = TIME;

?>

<!DOCTYPE html>
<html>
<head>
<title>Просмотр сайта</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link href="https://fonts.googleapis.com/css?family=Play" rel="stylesheet">
    <link href="/style/frame.css" rel="stylesheet" type="text/css">


    <script type="text/javascript">
        var vtime = stattime = <?php echo $_SESSION['view']['timer']; ?>;
        var cnt = '<?php echo $_SESSION['view']['cnt']; ?>';
    </script>

    <script type="text/javascript" src="/assets/js/serfing.js"></script>

    <script type="text/javascript">
        //setInterval(startClock, 1000);
        startClock();
    </script>

  <script type="text/javascript">
  function getXMLHTTP() {
    var xmlhtmp=null;
    if(window.XMLHttpRequest) {
      xmlhtmp=new XMLHttpRequest();
    } else if(window.ActiveXObject) {
      xmlhtmp=new ActiveXObject("Microsoft.XMLHTTP");
    }
    return xmlhtmp;
  }
  var cptfix=0;
  var cptcode=0;
  var focus=0;
  var focuscheck=<?=$result['wind'];?>;
  var time=<?=$result['timer'];?>;
  var clickid=18821850;
  var TTimer;
  function timerStep() {
    if(time<0) {
      time=0;
      cptfix=1;
      checkClick();
      return;
    }
    else
    {
      if(document.getElementById("timer")!=null) {
        time--;
        document.getElementById("timer").innerHTML=time;
        if(time==0) {
          clearTimeout(TTimer);
          cptfix=1;
          getCaptcha();
        }
        else
        {
          TTimer=setTimeout(timerStep, 1000);
        }
      }
    }
  }

  function hasIsFocus() {
    if(cptfix==0) {
      if(document.hasFocus()) {
        if(focus==0) {
          console.log("ass");
          document.getElementById("check").innerHTML='Дождитесь окончания таймера:<div class="timer notranslate" id="timer">'+time+'</div>';
          timerStart();
          focus=1;
        }
      }
      else
      {
        if(focus==1) {
          clearTimeout(TTimer);
          document.getElementById("check").innerHTML='<span style="color:#9e0707;">Окно не активно! Не уходите с вкладки!</span>';
          focus=0;
        }
      }
    }
  }

  function getRandomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }

  function changeCpt(num) {
    cptcode=num;
    checkClick();
  }

  function loadArguments() {
    var xmlh=getXMLHTTP();
    xmlh.onreadystatechange=function() {
      if(xmlh.readyState==4 && xmlh.status==200) {
        if(xmlh.responseText!='') {
          $("#check").append(xmlh.responseText);
        }
      }
    };
    xmlh.open("GET", "/ajax/myserfing/us-stepserf.php", true);
    xmlh.setRequestHeader("Content-Type", "text/xml")
    xmlh.send(null);
  }

  function getCaptcha() {
    document.getElementById('check').style.display = 'none';
    nextstep(0, cnt);
  }

  function checkFocus() {
    setInterval(hasIsFocus, 100);
  }

  function timerStart() {
    clearTimeout(TTimer);
    TTimer=setTimeout(timerStep, 1000);
  }

  function checkClick() {
    var xmlh=getXMLHTTP();
    xmlh.onreadystatechange=function() {
      if(xmlh.readyState==4 && xmlh.status==200) {
        if(xmlh.responseText!='time_error' && xmlh.responseText!='create_error' && xmlh.responseText!='captcha_error') {
          window.location.href = '';
        }
        else if(xmlh.responseText=='captcha_error') {
          getCaptcha();
        }
        else
        {
          document.getElementById("check").innerHTML='Просмотр не засчитан! Повторите позже';
        }
      }
    };
    //xmlh.open("GET", "", true);
    //xmlh.setRequestHeader("Content-Type", "text/xml")
    //xmlh.send(null);
    document.getElementById("check").innerHTML='Загрузка сайта...';
  }

  setTimeout(function() {
    timerStart();
    if (focuscheck == 1) {
      checkFocus();
    }
    document.getElementById('blockwait').style.display = 'none';
  }, 2000);

  </script>
</head>
<body id="body">
<table class='table_gl' style='position: absolute; bottom: 0px;height:80px;' >
  <tr>
    <td style='width: 100%;text-align:center;padding-left: 10px;' rowspan='2'>
      <div class='logo'><a href='/'><img src='/img/logo.png'></a></div>
      <div id='check'>Дождитесь окончания таймера:<div class='timer notranslate' id='timer'><?=$_SESSION['view']['timer'];?></div></div>

                    <div id="blockverify">
                        <div id="blockwait">
                            Подождите, сайт загружается...
                        </div>
                        <div id="blocktimer" style="display: none;">
                            <form class="clockalert" name="frm" method="post" action="" onsubmit="return false;">
                                <input name="clock" size="3" readonly="readonly" type="text" value=""/>
                                <br />
                                <span></span>
                            </form>
                        </div>

                    </div>
    </td>
  </tr>
</table>
<iFrame style='padding-bottom: 80px;' src='<?php echo $result['url']; ?>' width='100%' height='100%' id='framesite' frameborder='0' scrolling='yes'></iFrame>
</body>
</html>

<?php
}else{
    exit('Не существует или закончились просмотры');
}
?>