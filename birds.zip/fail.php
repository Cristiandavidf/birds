<center><b>Пополнение баланса было отменено</b>
<BR /><a href="/profile">Перейти в аккаунт</a>
</center>