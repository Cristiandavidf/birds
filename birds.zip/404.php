
<html>
<head>
<title>Страницы не существует</title>
<meta charset="windows-1251" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<link rel="stylesheet" href="/assets/css/bootstrap.min.css" />
<link rel="stylesheet" href="/assets/css/main.css" />
<link rel="icon" href="favicon.ico">
</head>
<body>
<style>
.error404 {
font-size: 170px !important;line-height: 175px;font-weight: bold;margin-bottom: 50px;
}

@media screen and (max-width: 890px) {
.error404 {	font-size: 95px !important;
	line-height: 95px;font-weight: bold;
	margin-bottom: 50px;

	}
}
@media screen and (max-width: 560px) {
.error404 {	font-size: 65px !important;
	line-height: 65px;font-weight: bold;
	margin-bottom: 20px;

	}
}
</style>
<div class="container">
<div class="wrapper">
<center>
<a href="/"><img src="/img/birds.png" alt="" /></a>
</center>
<div style="border-radius: 6px;">
<center>
<h2>Страница не существует</h2>
<p class="error404">ОШИБКА 404</p>

<a href="/" class="btn btn-success btn-lg">Перейти на главную</a><br/><br/><br/>
</center>

</div>
</div>
</div>

<footer id="footer" class="footer">
<div class="text-center copyright">
© 2019 | Все права защищены. 
</div>
</footer>
</body>
</html>