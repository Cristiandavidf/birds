<?php // защита от GoodScript.ru 
function check_text($text) {
	  $arraysql = array('UNION','SELECT','OUTFILE','LOAD_FILE','GROUP BY','ORDER BY','INFORMATION_SCHEMA.TABLES','BENCHMARK','FLOOR','SLEEP','CHAR');
	  $replacesql ='';
	  $text2=$text;
	  $text2=mb_strtoupper($text2);
	  $text2=str_replace($arraysql, $replacesql, $text2,$count);
	  if($count!=0){ echo "Ошибка, повторите ввод. "; exit;}
	  
	  $array_find = array("'",'"','/**/','0x','/*','--');
	  $array_replace ='';
	  $text=str_replace($array_find, $array_replace, $text);
	return $text;
}
foreach($_GET as $i => $value){ $_GET[$i]=check_text($_GET[$i]);}
foreach($_POST as $i => $value){ $_POST[$i]=check_text($_POST[$i]);}
foreach($_COOKIE as $i => $value){ $_COOKIE[$i]=check_text($_COOKIE[$i]);}

?>
