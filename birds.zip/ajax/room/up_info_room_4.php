<?php
session_start();
#####################################
# Модуль Рулетка ROOM для ФФ
# Автор APTEMOH
# E-mail: ArtIncProject@yandex.ru
# Skype: ArtIncProject
# VK.com: https://vk.com/id381626457
#####################################
$usid = $_SESSION['user_id'];

define('TIME', time());
define('BASE_DIR', $_SERVER['DOCUMENT_ROOT']);

header("Content-type: text/html; charset=utf-8");

if (!isset($_SESSION['user_id'])) { exit(); }

function __autoload($name){ include(BASE_DIR."/classes/_class.".$name.".php");}

$config = new config;

# База данных
$db = new db($config->HostDB, $config->UserDB, $config->PassDB, $config->BaseDB);

$db->Query("SET NAMES 'utf8'");
$db->Query("SET CHARACTER SET 'utf8'");
$db->Query("SET SESSION collation_connection = 'utf8_general_ci'");

$db->Query("SELECT money_b FROM db_users_b WHERE id = '$usid'");
$balance = $db->FetchArray();

# ================
    if (isset($_SESSION['user_id']) && isset($_SESSION['user']))
    {

        $ses_user = (isset($_SESSION['user_id'])) ? $_SESSION['user_id'] : '';
        $pass = (isset($_SESSION['user'])) ? $_SESSION['user'] : '';

        $db->Query("SELECT `user_id`,`vk_id`,`vk_avatar`,`vk_avatar_100`,`user_login`,`user_pass`,`user_prava`,`user_ref`,`user_email`,`user_balance`,`user_payeer`,`chek_ban`
        FROM `p_users` WHERE `user_id`='$usid' LIMIT 1"); //`user_pass`='{$pass}' AND

        if ($db->NumRows() == 1)
        {
            //$skyrow = mysql_fetch_array($skybase);
            $skyrow = $db->FetchArray();
            $prava = $skyrow['user_prava'];
            $name =  $skyrow['user_login'];
            $user_email = $skyrow['user_email'];
            
            $user_ref_set = $skyrow['user_ref'];
            
            $payeer_purse = $skyrow['user_payeer'];
            $vk_avatar = $skyrow['vk_avatar'];
            $vk_user_id_global = $skyrow['vk_id'];
            $vk_avatar_100 = $skyrow['vk_avatar_100'];
            
            $user_balance_global = sprintf("%.2f", $balance["money_b"]);       
            
        }else { echo '<center><br /><div class="alert alert-danger">Попытка взлома. За тобой уже выехали! </div><br /></center>'; exit(); }


    }
# ================

$site_commission_loto_room_5 = 20;
$error = 0;
    
    function showDate( $date ) // $date --> время в формате Unix time
    {
        $stf      = 0;
        $cur_time = time();
        $diff     = $cur_time - $date;

        if ($diff<6) {$value ='только что';} else {

            $seconds = array( 'секунду назад', 'секунды назад', 'секунд назад' );
            $minutes = array( 'минуту назад', 'минуты назад', 'минут назад' );
            $hours   = array( 'час назад', 'часа назад', 'часов назад' );
            $days    = array( 'день назад', 'дня назад', 'дней назад' );
            $weeks   = array( 'неделю назад', 'недели назад', 'недель назад' );
            $months  = array( 'месяц назад', 'месяца назад', 'месяцев назад' );
            $years   = array( 'год назад', 'года назад', 'лет назад' );
            $decades = array( 'десятилетие назад', 'десятилетия назад', 'десятилетий назад' );

            $phrase = array( $seconds, $minutes, $hours, $days, $weeks, $months, $years, $decades );
            $length = array( 1, 60, 3600, 86400, 604800, 2630880, 31570560, 315705600 );

            for ( $i = sizeof( $length ) - 1; ( $i >= 0 ) && ( ( $no = $diff / $length[ $i ] ) <= 1 ); $i -- ) {
            ;
            }
            if ( $i < 0 ) {
                $i = 0;
            }
            $_time = $cur_time - ( $diff % $length[ $i ] );
            $no    = floor( $no );
            $value = sprintf( "%d %s ", $no, getPhrase( $no, $phrase[ $i ] ) );

            if ( ( $stf == 1 ) && ( $i >= 1 ) && ( ( $cur_time - $_time ) > 0 ) ) {
                $value .= time_ago( $_time );
            }

        }
        return $value;
    }
 

    function getPhrase( $number, $titles ) {
        $cases = array( 2, 0, 1, 1, 1, 2 );
     
        return $titles[ ( $number % 100 > 4 && $number % 100 < 20 ) ? 2 : $cases[ min( $number % 10, 5 ) ] ];
    }
    
    

    
    
    function up_users_num($db,$qx,$w)
    {

        $users_roulette_koll = $db->Query("SELECT * FROM `p_roulette_users_game_4` $qx ");

        if ($w == 1) {

            $result = $db->NumRows();

        } elseif ($w == 2) {

            $qwe = $db->FetchArray();
            $result = $qwe['finish'];
        }

        elseif ($w == 3) {

        $result .= '<table class="table table-bordered"  cellpadding="5" cellspacing="0">';
        if($db->NumRows() >0) {
            $result .= '<thead>';
            $result .= '<th></th>';
            $result .= '<th>Пользователь</th>';
            $result .= '<th>Ставка</th>';
            $result .= '<th>Шанс</th>';
            $result .= '<th>Когда</th>';
            $result .= '</thead>';


            while($row = $db->FetchArray())
            {

                $ava = ($row['avatar'] == 0) ? 'noavatar.png' : $row['avatar'];

                if ($cv == 1) { $bg_color = "2F343A"; $td_color = "ffffff"; $cv=0; } else { $bg_color = "2F343A"; $td_color = "ffffff"; $cv++; }
                $result .= '<tr>';

                $result .= '<td width="50px" align="center"><img width="24px" height="24px" src="/img/room/'.$ava.'" /></td>';
                $result .= '<td width="150px"><b>'.$row['user_login'].'</b> </td>';
                $result .= '<td> <span>'.$row['sum_bet'].' Coin</span></td>';
                $result .= '<td> <span class="label label-info">'.$row['percent'].'%</span></td>';
                $result .= '<td width="200px"> <span>'.showDate($row['data']).'</span></td>';
                $result .= '</tr>';

            }

        } else {$result .= '<tr class="bg-info user_row"><td align="center" width="100%">Ожидание игроков...</td></tr>';}


        $result .= '</table>';
        }

        elseif ($w == 4) {

            $qwe = $db->FetchArray();
            $result = $qwe['check_finish'];
        }


        return $result;

    }


    function up_users_stats($db)
    {


        $users_roulette_koll = $db->Query("SELECT * FROM `p_roulette_users_stat_4` ORDER BY `data` DESC LIMIT 10");

        $result .= '<table class="table table-bordered" cellpadding="6" cellspacing="0">';
        $result .= '<thead>';
        $result .= '<th></th>';
        $result .= '<th>Пользователь</th>';
        $result .= '<th>Выигрыш</th>';
        $result .= '<th>Шанс</th>';
        $result .= '<th>Ставка</th>';
        $result .= '<th>Дата</th>';
        $result .= '</thead>';


        while($row = $db->FetchArray())
        {
            if ($cv == 1) { $bg_color = "2F343A"; $td_color = "ffffff"; $cv=0; } else { $bg_color = "2F343A"; $td_color = "ffffff"; $cv++; }

            if($row['lost'] == 0) {$win ='да';} else {$win ='нет'; $bg_color ='#F5DEB3'; $td_color = "2F343A";}

            $ava = ($row['avatar'] == 0) ? 'noavatar.png' : $row['avatar'];

            $result .= '<tr>';
            $result .= '<td width="50px"><img class="table_avatar" width="24px" height="24px" src="/img/room/'.$ava.'" /></td>';
            $result .= '<td width="200px"><b>'.$row['user_login'].'</b></td>';
            $result .= '<td width="150px"><span class="text-success">'.$row['sum'].' Coin</span></td>';
            $result .= '<td><span class="label label-info">'.$row['percent'].'% </span></td>';
            $result .= '<td width="150px"><span class="text-info">'.$row['sum_bet'].' Coin</span></td>';
            $result .= '<td><span>'.$row['data'].'</span></td>';
            $result .= '</tr>';

        }
        $result .= '</table>';

        return $result;


    }


    function up_bank($db)
    {
        global $site_commission_loto_room_5;
        $query = $db->Query("select SUM(`sum_bet`) from `p_roulette_users_game_4`");
        $result = $db->FetchArray();
        $real_bank = $result[0]+0;

        $formula = $real_bank/100 * $site_commission_loto_room_5;

        $bank = $real_bank - $formula;

        return round($bank,2);
    }



    $time_to_show = up_users_num($db,' WHERE `id`=1',2) - time();
    $total_users_in = up_users_num($db,'ORDER BY `data` DESC LIMIT 10',1);



    if ($total_users_in == 2) {
    $max_users_progress = 30;
    } 

    elseif ($total_users_in == 3) {
    $max_users_progress = 35;
    }

    elseif ($total_users_in == 4) {
    $max_users_progress = 40;
    }

    elseif ($total_users_in == 5) {
    $max_users_progress = 45;
    }

    elseif ($total_users_in == 6) {
    $max_users_progress = 50;
    }

    elseif ($total_users_in == 7) {
    $max_users_progress = 55;
    }

    elseif ($total_users_in == 8) {
    $max_users_progress = 60;
    }

    elseif ($total_users_in == 9) {
    $max_users_progress = 65;
    }

    elseif ($total_users_in == 10) {
    $max_users_progress = 70;
    }




    if ($time_to_show <0) {

        //$progress_bar = '<div id="man"><div id="eye-l"></div><div id="eye-r"></div><div id="nose"></div><div id="mouth"></div></div><div id="wall">ОЖИДАНИЕ ИГРОКОВ</div>'; 
        $time_to_finish = 1;

    }else{

        $formula_progressa = floor(($time_to_show * 100)/$max_users_progress);

        $progress_bar = '<div class="alert alert-warning" style="color:#FF6A00;text-transform: uppercase;"><b>Подождите...</b>
        <br/>До старта игры осталось '.$time_to_show.' сек. Ставь быстрее...</div>'; 

        #<progress title="осталось '.$time_to_show.' сек." value="'.$formula_progressa.'" max="100"></progress>

        //$time_to_finish = 0;
        $win_name = 0;
    }


    //если юзеров больше этого количества, то рулетка будет запущена
    $user_num_start_roulette = 1;


if ($time_to_finish == 1 and up_users_num($db,' WHERE `id`=1',4) == 0) {


    //если юзеров больше 1, то запускаем рулетку
    if (up_users_num($db,'ORDER BY `data` DESC LIMIT 10',1) > $user_num_start_roulette) {

        $update_check_finish = $db->Query("UPDATE `p_roulette_users_game_4` SET `check_finish`=`check_finish`+'1' WHERE `id`='1' LIMIT 1");
        //ожидание
        sleep(1);
        $finish_num = $db->Query("SELECT `check_finish` FROM `p_roulette_users_game_4` WHERE `id`='1' ");
            
        $finish_num_rov = $db->FetchArray();
        //////

        if ($finish_num_rov['check_finish'] == 1) {


            $query = $db->Query("SELECT SUM(`sum_bet`) FROM `p_roulette_users_game_4`");
            $result = $db->FetchArray();
            $bank = $result[0] + 0;

            $query_users_roulette = $db->Query("SELECT * FROM `p_roulette_users_game_4`");
            while($rov = $db->FetchArray()){     

                //$kolvo = 1000 * $rov['sum_bet']/100;
                //$kolvo = 800 * $rov['sum_bet']/100;
                $kolvo = 150;
                $percent = $rov['sum_bet'] * 100/$bank;

                $ava = ($rov['avatar'] == 0) ? 'noavatar.png' : $rov['avatar'];

                for ($i = 0; $i < $kolvo; $i++) {
                    $massiv[] = $rov['user_id'];
                    $avatars[] = '<li><img src="/img/room/'.$ava.'"><label>'.$rov['user_login'].'</label></li>';
                }

            }

            shuffle($massiv);
            shuffle($avatars);


            $input = $massiv;
            $rand_keys = array_rand($input, 1);

            //кто выиграл
            $winner_id = $input[$rand_keys];


            $query_user_winner = $db->Query("SELECT * FROM `p_roulette_users_game_4` WHERE `user_id`='{$winner_id}'");
            $rov_winner = $db->FetchArray();
            $data_roulette = date("Y-m-d H:i:s");

            $ava = ($rov_winner['avatar'] == 0) ? 'noavatar.png' : $rov_winner['avatar'];

            //
            //array_splice($avatars, 30, 0, '<li id="win"><img src="'.$rov_winner['avatar'].'"></li>');
            array_splice($avatars, 95, 0, '<li id="win"><img src="/img/room/'.$ava.'"></li>');

            $str = '';
            $i = 0;
             
            foreach($avatars as $key => $val)
            {
                $str .= $val."\n";
                if (++$i == 100) break;
            }

            file_put_contents('p.php', '');

            file_put_contents('p.php', $str, FILE_APPEND);
            //


            //банк без того кто выиграл
            

            $query2 = $db->Query("SELECT SUM(`sum_bet`) FROM `p_roulette_users_game_4`");
            $result2 = $db->FetchArray();
            $bank2 = $result2[0];


            $formula = $bank2/100 * $site_commission_loto_room_5; 
            $user_profit = $bank2 - $formula;
            

            //добавим победителей в стату
            $add_ref_link_trek = $db->Query("INSERT INTO `p_roulette_users_stat_4` SET `user_id`='{$winner_id}',`user_login`='{$rov_winner['user_login']}',`avatar`='{$rov_winner['avatar']}',`data`='{$data_roulette}',`sum`='{$user_profit}',`sum_bet`='{$rov_winner['sum_bet']}',`percent`='{$rov_winner['percent']}'");

            $update_winners = $db->Query("UPDATE `p_users` SET `user_total_zarabotok`=`user_total_zarabotok`+'{$user_profit}',`total_roulette_money`=`total_roulette_money`+'{$user_profit}',`total_roulette_win`=`total_roulette_win`+'1'  WHERE `user_id`='{$winner_id}' LIMIT 1");

            $db->Query("UPDATE `db_users_b` SET `money_b`=`money_b`+'{$user_profit}' WHERE `id`='{$winner_id}' LIMIT 1");

            # ================
            $db->Query("UPDATE `p_users` SET `total_roulette_lost`=`total_roulette_lost`-1 WHERE `user_id`='{$winner_id}' LIMIT 1");
            # ================


            //стата для админа
            //$add_roulette_stat_admin = $db->Query("UPDATE `p_roulette_stat` SET `last_game_data`='{$data_roulette}',`admin_profit`=`admin_profit`+'{$formula}',`total_game`=`total_game`+'1'  WHERE `id`='1' LIMIT 1");


            //чистим таблицу юзеров рулетки
            $cleaning_roulette_tab = $db->Query("TRUNCATE TABLE `p_roulette_users_game_4`");

            //}


        } else {

            $update_check_finish = $db->Query("UPDATE `p_roulette_users_game_4` SET `check_finish`='0' WHERE `id`='1' LIMIT 1");

        }


    }

}


    //время
    function last_game_time_win($db,$q)
    {

        $query = $db->Query("SELECT * FROM `p_roulette_users_stat_4` ORDER BY `id` DESC LIMIT 1");
        $result = $db->FetchArray();
        return $result[$q];
    }


    list($date, $time) = explode(" ", last_game_time_win($db,4)); 
    list($year,$month,$day) = explode("-", $date); 
    list($hour, $minute, $second) = explode(":", $time); 

    if (empty($hour)) {
        $hour = NULL;
    }
    if (empty($year)) {
        $year = NULL;
    }
    $time_last_win = mktime($hour, $minute, $second, $month, $day, $year);


    $period_time = time() - $time_last_win;

    if ($period_time < 20){

        $winner_animation = file_get_contents('p.php');

    } else {

        $winner_animation = 0;

        $win_r = 0;


        //показываем победителя
        if ($period_time <24){
            $p = 0;
            if(last_game_time_win($db,3) == 0){
$ava = 'noavatar.png';
}else $ava = last_game_time_win($db,3);
            $win_name = '
             <div class="user user-sidebar alert alert-success" style="width: 99%; margin: 0 auto; padding: 15px;">
            <div class="user-avatar-top">
            <img width="90" height="90" src="/img/room/'.$ava.'" class="win_avatar">
            </div>

            <div class="user-info-top">
            <div class="user-name-top" style="padding-left: 30px;">Победитель: <b>'.last_game_time_win($db,2).'</b> с шансом <b>'.last_game_time_win($db,7).'%</b></div>
            <div class="user_balance-top" style="padding-left: 30px; padding-top: 1px; font-size: 15px;">Ставка: <b>'.last_game_time_win($db,6).'</b> Coin</div>
            <div class="user_balance-top" style="padding-left: 30px; padding-top: 1px; font-size: 18px;">Выигрыш: <b class="label label-success">'.last_game_time_win($db,5).'</b> Coin</div>
            </div>
            </div>

            <br/><br/><br/><br/><br/><br/>
            ';

        } else {$period_time = 0; $win_name = 0; $p = 1; $winner_animation = 0;}



    }


    if ($prava >0) {
        if (up_users_num($db,'where `user_id`='.$_SESSION['user_id'].'',1) == 0) {$user_in = 0;} else {$user_in = 1;}
    } else {$user_in = 0;}  

    // массив для ответа
    $result = array(
        'total_users' => $total_users_in,
        'vusers' => up_users_num($db,'ORDER BY `data` DESC LIMIT 10',3),
        'last_game' => up_users_stats($db),
        'res' => $res,
        'new_balance' => '<b>'.round($user_balance_global,2).' Coin</b>',
        'time_to_show' => $progress_bar,
        'time_to_finish' => $p,
        'user' => $user_in,
        'bank' => up_bank($db).' Coin',
        'win' => $win_name,
        'win_time'=> $period_time,
        'win_r' =>$win_r,
        'winner_animation' => $winner_animation,
        //'test' => $test,
    );
    echo json_encode($result);

?> 