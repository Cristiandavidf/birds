<?php
session_start();
session_start();
#####################################
# Модуль Рулетка ROOM для ФФ
# Автор APTEMOH
# E-mail: ArtIncProject@yandex.ru
# Skype: ArtIncProject
# VK.com: https://vk.com/id381626457
#####################################
$usid = $_SESSION['user_id'];

define('TIME', time());
define('BASE_DIR', $_SERVER['DOCUMENT_ROOT']);

header("Content-type: text/html; charset=utf-8");

if (!isset($_SESSION['user_id'])) { exit(); }

function __autoload($name){ include(BASE_DIR."/classes/_class.".$name.".php");}

$config = new config;

# База данных
$db = new db($config->HostDB, $config->UserDB, $config->PassDB, $config->BaseDB);

$db->Query("SET NAMES 'utf8'");
$db->Query("SET CHARACTER SET 'utf8'");
$db->Query("SET SESSION collation_connection = 'utf8_general_ci'");

$db->Query("SELECT money_b FROM db_users_b WHERE id = '$usid'");
$balance = $db->FetchArray();

# 1% идет рефереру
$ref_percent_bet = 1;

$db->Query("SELECT referer_id FROM db_users_a WHERE id = '$usid'");
$ref = $db->FetchArray();
$user_ref_set = $ref['referer_id'];

# ================

    /**
     * Определение цело или дробное
     * @param  [type] $sum [description]
     * @return [type]      [description]
     */
    function myNum($sum){

        if ($sum > 0) {

            if (is_int($sum) && $sum > 0) {
                #echo "Целое!";
                
                if (is_numeric($sum)) {
                    #echo "Число!";
                    $theNumber=(filter_var($sum, FILTER_SANITIZE_NUMBER_INT));
                }else{
                    #echo "Не число!";
                    return false;
                }
            }else{
                #echo "Дробное!";
                
                if (is_numeric($sum)) {
                    #echo "Число!";
                    $theNumber=(filter_var($sum, FILTER_SANITIZE_NUMBER_FLOAT, array('flags' => FILTER_FLAG_ALLOW_FRACTION, FILTER_FLAG_ALLOW_THOUSAND)));
                }else{
                    #echo "Не число!";
                    return false;
                }
            }

        }else return false;

        return $theNumber;
    }

    if (isset($_SESSION['user_id']) && isset($_SESSION['user']))
    {

        $ses_user = (isset($_SESSION['user_id'])) ? $_SESSION['user_id'] : '';
        $pass = (isset($_SESSION['user'])) ? $_SESSION['user'] : '';

        $db->Query("SELECT `user_id`,`vk_id`,`vk_avatar`,`vk_avatar_100`,`user_login`,`user_pass`,`user_prava`,`user_ref`,`user_email`,`user_balance`,`user_payeer`,`chek_ban`
        FROM `p_users` WHERE `user_id`='$usid' LIMIT 1"); //`user_pass`='{$pass}' AND

        if ($db->NumRows() == 1)
        {
            //$skyrow = mysql_fetch_array($skybase);
            $skyrow = $db->FetchArray();
            $prava = $skyrow['user_prava'];
            $name =  $skyrow['user_login'];
            $user_email = $skyrow['user_email'];
            
            //$user_ref_set = $skyrow['user_ref'];
            
            $payeer_purse = $skyrow['user_payeer'];
            $vk_avatar = $skyrow['vk_avatar'];
            $vk_user_id_global = $skyrow['vk_id'];
            $vk_avatar_100 = $skyrow['vk_avatar_100'];
            
            //$user_balance_global = $skyrow['user_balance'];  
            $user_balance_global = sprintf("%.2f", $balance["money_b"]);     
            
        }else { echo '<link href="st.css" rel="stylesheet" type="text/css"><center><br /><div class="alert">Попытка взлома. За тобой уже выехали!  </div><br /></center>'; exit(); }


    }
# ================

    $error = 0;
    
    $users_roulette_koll = $db->Query("SELECT * FROM `p_roulette_users_game_4`");
    $koll_users_roulette = $db->NumRows();
    
    $pay_method = 1;
    $sum_bet = myNum($_POST['sum_bet']);

    # ==========
    $queryBank = $db->Query("SELECT SUM(`sum_bet`) from `p_roulette_users_game_4` WHERE `user_id`='{$_SESSION['user_id']}'");
    $resultBank = $db->FetchArray();
    $bankUser = $resultBank[0] + 0;
    $resSum = $bankUser + $sum_bet; 
    # ==========
    
    if ($prava==0){
        $error = 7; 
        $oshibka = '7';
    }
    //метод не может быть пустым
    elseif (!isset($pay_method)) {
        $error = 999;   
        $oshibka = 'Иди уроки учи!';     
    }       

    //метод число 1 или 6 и один символ
    elseif(!preg_match("/[1-2]{1}/",$pay_method)) { 
        $error = 2; 
        $oshibka = 'У тебя почти получилось!';   
    } 

    //проверка суммы
    elseif($sum_bet == false) {    
        $error = 88; 
        $oshibka = 'Сумма введена не верно!';   
    }    
    
    //проверка суммы
    elseif(!preg_match("/^\d+(?:[.]\d{1,2}|)$/",$sum_bet)) {    
        $error = 8; 
        $oshibka = 'Сумма введена не верно '.$sum_bet.'!';   
    }   
    
    //
    elseif($pay_method == 1 and $user_balance_global <$sum_bet) {   
        $error = 3; 
        $oshibka = 'На балансе не достаточно средств для ставки!';   
    }

    
    //
    elseif($sum_bet <100) {   
        $error = 10;    
        $oshibka = 'Минимальная сумма ставки 100 Coin!';      
    }

    //
    elseif($sum_bet > 1000) {   
        $error = 11;    
        $oshibka = 'Максимальная сумма ставки 1000 Coin!';      
    }

    //
    elseif($resSum > 1000) {   
        $error = 12;    
        $oshibka = 'Максимальная сумма ставки в игре составляет 1000 Coin!';      
    }
    
    
    elseif($koll_users_roulette >100) {
    
        $error = 5; 
        $oshibka = 'Подождите пару секунд до следующей игры!';   
    }   
    

    //если нет ошибок, то идем далее    
    if ($error == 0) {

        //поплнял ли баланс этот господин

        function check_add_money_user($db)
        {       
            $baseuser = $db->Query("SELECT COUNT(`user_id`) FROM `p_update` WHERE `user_id`='{$_SESSION['user_id']}'");
            $row = $db->FetchRow();
            return $total = $row[0];
        }
        //if (check_add_money_user($db) >0) {

        
        
        if($pay_method == 1) {
            //$take_money_osn_balance = $db->Query("UPDATE `p_users` SET `user_balance`=`user_balance`-'{$sum_bet}'  WHERE `user_id`='{$_SESSION['user_id']}' LIMIT 1");
            $db->Query("UPDATE `db_users_b` SET `money_b`=`money_b`-'{$sum_bet}'  WHERE `id`='{$_SESSION['user_id']}' LIMIT 1");
            $new_balance = $user_balance_global - $sum_bet;
            $res = 'ok';
        }
        

        $db->Query("SELECT * FROM `p_roulette_users_game_4`");
        $row_roulette_users_finish = $db->FetchArray(); //запрос вверху
        
        $finish_time = $row_roulette_users_finish['finish'];
        
        if ($finish_time == 0) {$finish = time() + 30;} 
        
            //есть ли юзер в рулетке
            $user_roulette_test = $db->Query("SELECT * FROM `p_roulette_users_game_4` WHERE `user_id`='{$_SESSION['user_id']}'");
            $test_users_roulette = $db->NumRows();
        
            if ($test_users_roulette == 0){

                $data_roulette = time();
                $add_users_roulette_tab = $db->Query("INSERT INTO `p_roulette_users_game_4` SET `user_id`='{$_SESSION['user_id']}',`user_login`='{$name}',`sum_bet`='{$sum_bet}',`avatar`='{$vk_avatar_100}',`data`='{$data_roulette}'");
                
                if($user_ref_set > 0) {
                    $referer_percent = $sum_bet/100 * $ref_percent_bet;
                       
                    $db->Query("UPDATE `p_users` SET `user_total_zarabotok`=`user_total_zarabotok`+'{$referer_percent}' WHERE `user_id`='{$user_ref_set}' LIMIT 1");


                                                
                    $db->Query("UPDATE `p_users` SET `total_ref_money`=`total_ref_money`+'{$referer_percent}' WHERE `user_id`='{$_SESSION['user_id']}' LIMIT 1");  

                    $db->Query("UPDATE `db_users_b` SET `money_b`=`money_b`+'{$referer_percent}', `from_referals`=`from_referals`+'{$referer_percent}' WHERE `id`='{$user_ref_set}' LIMIT 1");                          
                    
                }
                
                if ($koll_users_roulette +1 == 2) {
                   $add_finish_time  = $db->Query("UPDATE `p_roulette_users_game_4` SET `finish`='{$finish}'");
                }

                # ================
                $db->Query("UPDATE `p_users` SET `total_roulette_lost`=`total_roulette_lost`+1 WHERE `user_id`='{$_SESSION['user_id']}' LIMIT 1");
                # ================
            
            } else {
            
                $update_user_bet  = $db->Query("UPDATE `p_roulette_users_game_4` SET `sum_bet`=`sum_bet`+'{$sum_bet}' WHERE `user_id`='{$_SESSION['user_id']}'");

                if($user_ref_set > 0) {
                    $referer_percent = $sum_bet/100 * $ref_percent_bet;
                       
                    $db->Query("UPDATE `p_users` SET `user_total_zarabotok`=`user_total_zarabotok`+'{$referer_percent}' WHERE `user_id`='{$user_ref_set}' LIMIT 1");


                                                
                    $db->Query("UPDATE `p_users` SET `total_ref_money`=`total_ref_money`+'{$referer_percent}' WHERE `user_id`='{$_SESSION['user_id']}' LIMIT 1");  

                    $db->Query("UPDATE `db_users_b` SET `money_b`=`money_b`+'{$referer_percent}', `from_referals`=`from_referals`+'{$referer_percent}' WHERE `id`='{$user_ref_set}' LIMIT 1");                          
                    
                }
            }
        
            
            $query = $db->Query("SELECT SUM(`sum_bet`) from `p_roulette_users_game_4`");
            $result = $db->FetchArray();
            $bank = $result[0] + 0;

            $db->Query("SELECT * FROM `p_roulette_users_game_4`");
            
            while($rov = $db->FetchArray()){     

                $percent_update = $rov['sum_bet'] * 100/$bank;

                //$percent_update[] = round($percent,2);

                $update_user_percent = $db->MultiQuery("UPDATE `p_roulette_users_game_4` SET `percent`='{$percent_update}' WHERE `user_id`='{$rov['user_id']}'");
    
            }
    
    
    //} else {$oshibka = 'Вам необходимо хотябы раз пополнить баланс через PAYEER или FREE-KASSA!'; }
    

    }


    // массив для ответа
    $result = array(
        'error' => $oshibka,
        'html' => '',
        'res' => $res,
        'new_balance' => '<font color="#FFD800"><b>'.round($new_balance,2).' Coin</b></font>',
    );
    echo json_encode($result);
?>