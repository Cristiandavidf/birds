<?PHP

class config{

	public $HostDB = "localhost";
	public $UserDB = "root";
	public $PassDB = "";
	public $BaseDB = "abc";    
	public $BasePrefix = "db";
	public $FolderAdmin = "admin"; //Название папки админки! Сначала измените название самой папки затем тут впишите ее название!
	
	public $SYSTEM_START_TIME = 1552000000;
	public $VAL = "RUB";
	public $VAL2 = "Руб.";
	
	public $SITE_NAME = "Juice.Script";
	public $SUPPORT = "support@juice.script";
	public $recaptcha = '123456';

	# Free-kassa настройки
	public $free_id = '123456';
	public $free_key = 'oa65402';
	public $free_key2 = 'id3231yf';

	# PAYEER настройки
	public $AccountNumber = 'P1010101010';
	public $apiId = '1234567890';
	public $apiKey = 'HnZf28JZCs5NDGL5';

	public $shopID = '1234567890';
	public $secretW = 'HnZf28JZCs5NDGL5';
	
   /**
     * Возвращает ID админа
     * @return [type] = INT [description] = ID Админа
     */
    public function serfIdAdmin()
    {
        return $serfIdAdmin = 1;
    }
}
?>