
  <ul>
	<li><center><h3 class="welcome">Админ-панель</h3></center></li>
	<li><a href="index.php?menu=stats">Статистика</a></li>
	<li><a href="index.php?menu=config">Настройки</a></li>	
	<li><a href="index.php?menu=news">Новости</a></li>
	<li><a href="index.php?menu=blogs">Блоги</a></li>
	<li class="line"></li>
	<li><a href="index.php?menu=payments">Список выплат</a></li>
	<li><a href="index.php?menu=story_buy">История покупок</a></li>
	<li><a href="index.php?menu=story_swap">История обменов</a></li>
	<li><a href="index.php?menu=story_insert">История вложений</a></li>
	<li class="line"></li>
	<li><a href="index.php?menu=contest">Конкурс</a></li>
	<li><a href="index.php?menu=compconfig">Конкурс рефералов</a></li>
	<li><a href="index.php?menu=invcompconfig">Конкурс инвесторов</a></li>
	<li class="line"></li>
	<li><a href="index.php?menu=users">Пользователи</a></li>
	<li><a href="index.php?menu=serfing">Список серфинга</a></li>
	<li><a href="index.php?menu=multi">Мультиаккаунты</a></li>
	<li><a href="index.php?menu=reklamstats">Откуда рефералы</a></li>
	<li><a href="index.php?menu=sender">Рассылка игрокам</a></li>
	<li class="line"></li>
	<li><a href="/">Переход на сайт</a></li>
	<li><a href="index.php?menu=exit">Выход</a></li>
</ul>