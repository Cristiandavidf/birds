<html>
	<head>
		<title>Панель управления</title>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
		<link rel="stylesheet" href="/assets/css/admin.css" />
	</head>
	<body>

<div class="container-fluid">
<div class="row">
	<div class="col-3">
		<div class="col-left"><?PHP include("inc/_admin_menu.php"); ?></div>
	</div>

	<div class="col-9">
		<div class="content">