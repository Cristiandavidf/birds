<div class="page-header">
	<h1>Настройки</h1>
</div> 
 
<?PHP
$db->Query("SELECT * FROM db_config WHERE id = '1'");
$data_c = $db->FetchArray();

# Обновление
if(isset($_POST["admin"])){

	$admin = $func->IsLogin($_POST["admin"]);
//	$pass = $func->IsLogin($_POST["pass"]);
	
	
	$ser_per_wmr = intval($_POST["ser_per_wmr"]);
	$ser_per_wmz = intval($_POST["ser_per_wmz"]);
	$ser_per_wme = intval($_POST["ser_per_wme"]);
	$percent_swap = intval($_POST["percent_swap"]);
	$percent_sell = intval($_POST["percent_sell"]);
	$items_per_coin = intval($_POST["items_per_coin"]);
	
	$name_a = ($_POST["name_a"]);
	$name_b = ($_POST["name_b"]);
	$name_c = ($_POST["name_c"]);
	$name_d = ($_POST["name_d"]);
	$name_e = ($_POST["name_e"]);
	$name_f = ($_POST["name_f"]);
	$name_g = ($_POST["name_g"]);
	$name_h = ($_POST["name_h"]);
	$name_i = ($_POST["name_i"]);
	$name_j = ($_POST["name_j"]);

	$lvl1_in_h = intval($_POST["a_in_h"]);
	$lvl2_in_h = intval($_POST["b_in_h"]);
	$lvl3_in_h = intval($_POST["c_in_h"]);
	$lvl4_in_h = intval($_POST["d_in_h"]);
	$lvl5_in_h = intval($_POST["e_in_h"]);
	$lvl6_in_h = intval($_POST["f_in_h"]);
	$lvl7_in_h = intval($_POST["g_in_h"]);
	$lvl8_in_h = intval($_POST["h_in_h"]);
	$lvl9_in_h = intval($_POST["i_in_h"]);
	$lvl0_in_h = intval($_POST["j_in_h"]);
	
	$amount_lvl1_t = intval($_POST["amount_a_t"]);
	$amount_lvl2_t = intval($_POST["amount_b_t"]);
	$amount_lvl3_t = intval($_POST["amount_c_t"]);
	$amount_lvl4_t = intval($_POST["amount_d_t"]);
	$amount_lvl5_t = intval($_POST["amount_e_t"]);
	$amount_lvl6_t = intval($_POST["amount_f_t"]);
	$amount_lvl7_t = intval($_POST["amount_g_t"]);
	$amount_lvl8_t = intval($_POST["amount_h_t"]);
	$amount_lvl9_t = intval($_POST["amount_i_t"]);
	$amount_lvl0_t = intval($_POST["amount_j_t"]);

	$sum_0 = ($_POST["sum_0"]);
	$sum_1 = ($_POST["sum_1"]);
	$sum_2 = ($_POST["sum_2"]);
	$sum_3 = ($_POST["sum_3"]);
	$bon_0 = ($_POST["bon_0"]);
	$bon_1 = ($_POST["bon_1"]);
	$bon_2 = ($_POST["bon_2"]);
	$bon_3 = ($_POST["bon_3"]);

	# Проверка на ошибки
	$errors = true;
	
	
	if($percent_swap < 1 OR $percent_swap > 99){
		$errors = false; echo "<center><font color = 'red'><b>Прибавляемый процент должен быть (от 1 до 99).</b></font></center><BR />"; 
	}
	
	if($percent_sell < 1 OR $percent_sell > 100){
		$errors = false; echo "<center><font color = 'red'><b>Золото на вывод (от 1 до 100).</b></font></center><BR />"; 
	}
	
	if($items_per_coin < 1 OR $items_per_coin > 50000){
		$errors = false; echo "<center><font color = 'red'><b>Курс продожи 1 золота, должно быть (от 1 до 50000).</b></font></center><BR />"; 
	}

	if($lvl1_in_h < 6 OR $lvl2_in_h < 6 OR $lvl3_in_h < 6 OR $lvl4_in_h < 6 OR $lvl5_in_h < 6){
		$errors = false; echo "<center><font color = 'red'><b>Прибыль животных в час не менее 6 золота!</b></font></center><BR />"; 
	}
	
	
	if($amount_lvl1_t < 1 OR $amount_lvl2_t < 1 OR $amount_lvl3_t < 1 OR $amount_lvl4_t < 1 OR $amount_lvl5_t < 1){
		$errors = false; echo "<center><font color = 'red'><b>Минимальная стоимость животного 1 золото!</b></font></center><BR />"; 
	}
	
	# Обновление
	if($errors){
	
		$db->Query("UPDATE db_config SET 
		
		ser_per_wmr = '$ser_per_wmr',
		ser_per_wmz = '$ser_per_wmz',
		ser_per_wme = '$ser_per_wme',
		percent_swap = '$percent_swap',
		percent_sell = '$percent_sell',
		items_per_coin = '$items_per_coin',

		name_a = '$name_a',
		name_b = '$name_b',
		name_c = '$name_c',
		name_d = '$name_d',
		name_e = '$name_e',
		name_f = '$name_f',
		name_g = '$name_g',
		name_h = '$name_h',
		name_i = '$name_i',
		name_j = '$name_j',

		a_in_h = '$lvl1_in_h',
		b_in_h = '$lvl2_in_h',
		c_in_h = '$lvl3_in_h',
		d_in_h = '$lvl4_in_h',
		e_in_h = '$lvl5_in_h',
		f_in_h = '$lvl6_in_h',
		g_in_h = '$lvl7_in_h',
		h_in_h = '$lvl8_in_h',
		i_in_h = '$lvl9_in_h',
		j_in_h = '$lvl0_in_h',

		amount_a_t = '$amount_lvl1_t',
		amount_b_t = '$amount_lvl2_t',
		amount_c_t = '$amount_lvl3_t',
		amount_d_t = '$amount_lvl4_t',
		amount_e_t = '$amount_lvl5_t',
		amount_f_t = '$amount_lvl6_t',
		amount_g_t = '$amount_lvl7_t',
		amount_h_t = '$amount_lvl8_t',
		amount_i_t = '$amount_lvl9_t',
		amount_j_t = '$amount_lvl0_t',
		
		sum_0 = '$sum_0',
		sum_1 = '$sum_1',
		sum_2 = '$sum_2',
		sum_3 = '$sum_3',
		bon_0 = '$bon_0',
		bon_1 = '$bon_1',
		bon_2 = '$bon_2',
		bon_3 = '$bon_3'

		WHERE id = '1'");
		
		echo "<center><font color = 'green'><b>Успешно сохранено!</b></font></center><BR />";
		$db->Query("SELECT * FROM db_config WHERE id = '1'");
		$data_c = $db->FetchArray();
	}
	
}

?>
<form action="" method="post">

<div class="row">
<div class="col-lg-6">
<input style="display: none;" type="text" name="admin" value="<?=$data_c["admin"]; ?>" />

<h5>В обменнике прибавлять %:</h5>
<div class="row mb-3">
<div class="input-group col-lg-6">
<input class="form-control" type="text" name="percent_swap" value="<?=$data_c["percent_swap"]; ?>" />
<div class="input-group-prepend"><span class="input-group-text"><span>процентов</span></span></div>
</div>
</div>

<h5>Коэфициент при продаже на вывод:</h5>
<div class="row mb-3">
<div class="input-group col-lg-6">
<input class="form-control" type="text" name="percent_sell" value="<?=$data_c["percent_sell"]; ?>" />
<div class="input-group-prepend"><span class="input-group-text"><span>процентов</span></span></div>
</div>
</div>

<h5>Курс продажи 1 монета:</h5>
<div class="row mb-3">
<div class="input-group col-lg-6">
<input class="form-control" type="text" name="items_per_coin" value="<?=$data_c["items_per_coin"]; ?>" />
<div class="input-group-prepend"><span class="input-group-text"><span>Продукции</span></span></div>
</div>
</div>

<h5>Стоимость валюты сайта (монет):</h5>
<div class="row">
<div class="input-group col-lg-4">
<input class="form-control" type="text"name="ser_per_wmr" value="<?=$data_c["ser_per_wmr"]; ?>" />
<div class="input-group-prepend"><span class="input-group-text"><span>1 РУБ</span></span></div>
</div>

<div class="input-group col-lg-4">
<input class="form-control" type="text"name="ser_per_wmz" value="<?=$data_c["ser_per_wmz"]; ?>" />
<div class="input-group-prepend"><span class="input-group-text"><span>1 USD</span></span></div>
</div>

<div class="input-group col-lg-4">
<input class="form-control" type="text"name="ser_per_wme" value="<?=$data_c["ser_per_wme"]; ?>" />
<div class="input-group-prepend"><span class="input-group-text"><span>1 EUR</span></span></div>
</div>
</div>

</div>

<div class="col-lg-6"><h5>Настройка персонажей:</h5>
<table class="table table-bordered">
<thead>
	<th>Персонажи</th>
	<th width="103">Доход в час</th>
	<th>Стоимость</th>
</thead>

<tr>
	<td><input class="form-control" type="text" name="name_a" value="<?=$data_c["name_a"]; ?>" /></td>
	<td><input class="form-control" type="text" name="a_in_h" value="<?=$data_c["a_in_h"]; ?>" /></td>
	<td><div class="input-group"><input class="form-control" type="text" name="amount_a_t" value="<?=$data_c["amount_a_t"]; ?>" /><div class="input-group-prepend"><span class="input-group-text"><span id="res_val">монет</span></span></div></div></td>
</tr>
<tr>
	<td><input class="form-control" type="text" name="name_b" value="<?=$data_c["name_b"]; ?>" /></td>
	<td><input class="form-control" type="text" name="b_in_h" value="<?=$data_c["b_in_h"]; ?>" /></td>
	<td><div class="input-group"><input class="form-control" type="text" name="amount_b_t" value="<?=$data_c["amount_b_t"]; ?>" /><div class="input-group-prepend"><span class="input-group-text"><span id="res_val">монет</span></span></div></div></td>
</tr>
<tr>
	<td><input class="form-control" type="text" name="name_c" value="<?=$data_c["name_c"]; ?>" /></td>
	<td><input class="form-control" type="text" name="c_in_h" value="<?=$data_c["c_in_h"]; ?>" /></td>
	<td><div class="input-group"><input class="form-control" type="text" name="amount_c_t" value="<?=$data_c["amount_c_t"]; ?>" /><div class="input-group-prepend"><span class="input-group-text"><span id="res_val">монет</span></span></div></div></td>
</tr>
<tr>
	<td><input class="form-control" type="text" name="name_d" value="<?=$data_c["name_d"]; ?>" /></td>
	<td><input class="form-control" type="text" name="d_in_h" value="<?=$data_c["d_in_h"]; ?>" /></td>
	<td><div class="input-group"><input class="form-control" type="text" name="amount_d_t" value="<?=$data_c["amount_d_t"]; ?>" /><div class="input-group-prepend"><span class="input-group-text"><span id="res_val">монет</span></span></div></div></td>
</tr>
<tr>
	<td><input class="form-control" type="text" name="name_e" value="<?=$data_c["name_e"]; ?>" /></td>
	<td><input class="form-control" type="text" name="e_in_h" value="<?=$data_c["e_in_h"]; ?>" /></td>
	<td><div class="input-group"><input class="form-control" type="text" name="amount_e_t" value="<?=$data_c["amount_e_t"]; ?>" /><div class="input-group-prepend"><span class="input-group-text"><span id="res_val">монет</span></span></div></div></td>
</tr>
<tr>
	<td><input class="form-control" type="text" name="name_f" value="<?=$data_c["name_f"]; ?>" /></td>
	<td><input class="form-control" type="text" name="f_in_h" value="<?=$data_c["f_in_h"]; ?>" /></td>
	<td><div class="input-group"><input class="form-control" type="text" name="amount_f_t" value="<?=$data_c["amount_f_t"]; ?>" /><div class="input-group-prepend"><span class="input-group-text"><span id="res_val">монет</span></span></div></div></td>
</tr>

<tr>
	<td><input class="form-control" type="text" name="name_g" value="<?=$data_c["name_g"]; ?>" /></td>
	<td><input class="form-control" type="text" name="g_in_h" value="<?=$data_c["g_in_h"]; ?>" /></td>
	<td><div class="input-group"><input class="form-control" type="text" name="amount_g_t" value="<?=$data_c["amount_g_t"]; ?>" /><div class="input-group-prepend"><span class="input-group-text"><span id="res_val">монет</span></span></div></div></td>
</tr>

<tr>
	<td><input class="form-control" type="text" name="name_h" value="<?=$data_c["name_h"]; ?>" /></td>
	<td><input class="form-control" type="text" name="h_in_h" value="<?=$data_c["h_in_h"]; ?>" /></td>
	<td><div class="input-group"><input class="form-control" type="text" name="amount_h_t" value="<?=$data_c["amount_h_t"]; ?>" /><div class="input-group-prepend"><span class="input-group-text"><span id="res_val">монет</span></span></div></div></td>
</tr>

<tr>
	<td><input class="form-control" type="text" name="name_i" value="<?=$data_c["name_i"]; ?>" /></td>
	<td><input class="form-control" type="text" name="i_in_h" value="<?=$data_c["i_in_h"]; ?>" /></td>
	<td><div class="input-group"><input class="form-control" type="text" name="amount_i_t" value="<?=$data_c["amount_i_t"]; ?>" /><div class="input-group-prepend"><span class="input-group-text"><span id="res_val">монет</span></span></div></div></td>
</tr>

<tr>
	<td><input class="form-control" type="text" name="name_j" value="<?=$data_c["name_j"]; ?>" /></td>
	<td><input class="form-control" type="text" name="j_in_h" value="<?=$data_c["j_in_h"]; ?>" /></td>
	<td><div class="input-group"><input class="form-control" type="text" name="amount_j_t" value="<?=$data_c["amount_j_t"]; ?>" /><div class="input-group-prepend"><span class="input-group-text"><span id="res_val">монет</span></span></div></div></td>
</tr>

</table>


<h5>Настройка бонусов при пополнении:</h5>
<table class="table table-bordered">
<thead>
	<th>#</th>
	<th>Сумма пополнения(свыше)</th>
	<th>Процент начисления</th>
</thead>

<tr>
	<td>1</td>
	<td><span class="p-2 mt-5">Бонус за первое пополнение</span></td>
	<td><div class="input-group"><input class="form-control" type="text" name="bon_0" value="<?=$data_c["bon_0"]; ?>" /><div class="input-group-prepend"><span class="input-group-text"><span>%</span> </span></div></div></td>
</tr>
<tr>
	<td>1</td>
	<td><div class="input-group"><input class="form-control" type="text" name="sum_1" value="<?=$data_c["sum_1"]; ?>" /><div class="input-group-prepend"><span class="input-group-text"><span>РУБ</span> </span></div></div></td>
	<td><div class="input-group"><input class="form-control" type="text" name="bon_1" value="<?=$data_c["bon_1"]; ?>" /><div class="input-group-prepend"><span class="input-group-text"><span>%</span> </span></div></div></td>
</tr>
<tr>
	<td>2</td>
	<td><div class="input-group"><input class="form-control" type="text" name="sum_2" value="<?=$data_c["sum_2"]; ?>" /><div class="input-group-prepend"><span class="input-group-text"><span>РУБ</span> </span></div></div></td>
	<td><div class="input-group"><input class="form-control" type="text" name="bon_2" value="<?=$data_c["bon_2"]; ?>" /><div class="input-group-prepend"><span class="input-group-text"><span>%</span> </span></div></div></td>
</tr>
<tr>
	<td>3</td>
	<td><div class="input-group"><input class="form-control" type="text" name="sum_3" value="<?=$data_c["sum_3"]; ?>" /><div class="input-group-prepend"><span class="input-group-text"><span>РУБ</span> </span></div></div></td>
	<td><div class="input-group"><input class="form-control" type="text" name="bon_3" value="<?=$data_c["bon_3"]; ?>" /><div class="input-group-prepend"><span class="input-group-text"><span>%</span> </span></div></div></td>
</tr>

</table>

</div>
</div>

<center>
	<input type="submit" class="btn btn-success mb-2" value="Сохранить изменения" />
</center>
</form>