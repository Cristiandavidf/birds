<div class="page-header">
	<h1>Список серфинга</h1>
</div>


<table cellpadding='3' cellspacing='0' border='0' class='table table-bordered' align='center' width="99%">
  <tr class="bg-light">
    <td align="center" width="50">ID</td>
    <td align="center">Название/Ссылка</td>
    <td align="center">Владелец</td>
	<td align="center">Баланс</td>
    <td align="center">Просмотров</td>
	<td align="center">Добавлено</td>
	<td align="center">DEL</td>
  </tr>


<?PHP
    if (isset($_GET['delete']))
    {
        $id = (int)$_GET['delete'];

        #if (isset($_SESSION['admin']))
        if ($config->serfIdAdmin() == $_SESSION["user_id"])
        {
            $db->query("SELECT `money`, `user_name` FROM `db_serfing` WHERE id = '".$id."' LIMIT 1");

            $result = $db->FetchArray();

            $db->query("DELETE FROM db_serfing WHERE id = '".$id."'");
        }
    }

 $db->Query("SELECT * FROM db_serfing WHERE id ORDER BY time_add DESC");

 if ($db->NumRows())
 {
   while ($row = $db->FetchArray())
   {
	
	?>
	<tr>
    <td align="center" width="50"><?=$row["id"]; ?></td>
    <td><?=$row["title"]; ?> <br/><small>Ссылка: <?=$row["url"]; ?></small></td>
    <td align="center" width="200"><?=$row["user_name"]; ?></td>
	<td align="center" width="75"><?=$row["money"]; ?></td>
    <td align="center" width="200"><?=$row["view"]; ?></td>
	<td align="center" width="150"><?=date("d.m.Y в H:i:s",$row["time_add"]); ?></td>

<td>
<?php if ($config->serfIdAdmin() == $_SESSION["user_id"]) { ?><a class="btn btn-sm btn-danger" href="?menu=serfing&delete=<?=$row['id']; ?>" title="Удалить ссылку и вернуть деньги">X</a><?php } ?>
</td>
</tr>
	<?PHP
	
	}

?>

</table>
<BR />
<?PHP

}else echo "<center><b>Записей нет</b></center><BR />";
?>