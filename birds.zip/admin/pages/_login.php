<div class="page-header">
	<h1>Админ-панель</h1>
</div>

<?PHP
if(isset($_SESSION["admin"])){ Header("Location: /".$admFolder.""); return; }

if(isset($_POST["admlogin"])){

	$db->Query("SELECT * FROM ".$pref."_admin_log WHERE id = 1 LIMIT 1");
	$data_log = $db->FetchArray();
	$pass = $_POST["admpass"];
	$pass = $func->md5Password($pass);
	$login = $db->RealEscape($_POST['admlogin']);
		$log = $_POST["logcode"];
	
	if($log == "123456")  {


	if(strtolower($_POST["admlogin"]) == strtolower("admin") AND strtolower($_POST["admpass"]) == strtolower("admin") ){ 
	
		$_SESSION["admin"] = true;
		Header("Location: /".$admFolder."");
		return;
	}else echo "<center><font color = 'red'><b>Неверно введен логин и/или пароль</b></font></center><BR />";
	
	}else echo "<center><font color = 'red'><b>Доступ 
закрыт</b></font></center><BR />";
	
}
?>
<div class="p-3 col-lg-4">
<form action="" method="post">
	<input type="text" placeholder="Логин админа" class="form-control mb-2" name="admlogin" value="" />
	<input type="password" placeholder="Пароль" class="form-control mb-2" name="admpass" value="" />
	<input type="text" placeholder="Пин" class="form-control mb-3" name="logcode" value="" />
	<input type="submit" value="Войти" class="btn btn-success"/>
</form>
</div>