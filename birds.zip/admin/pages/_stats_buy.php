<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<div class="s-bk-lf">
	<div class="acc-title">Статистика покупок </div>
</div>
<div class="silver-bk">	
<?PHP
$db->Query("SELECT * FROM db_stats_buy");

if($db->NumRows() > 0){
	
?>


<table border="1" bordercolor="red" cellspacing="10">
<td align='center'>Первый уровень</td>
<td align='center'>Второй уровень</td>
<td align='center'>Третий уровень</td>
<td align='center'>Четверый уровень</td>
<td align='center'>Пятый уровень</td>
<td align='center'>Шестой уровень</td>
<?PHP

	while($data = $db->FetchArray()){
	
	?>
<tr>
<td align='center'><?=$data['amount_a_t'];?> ед.</td>
<td align='center'><?=$data['amount_b_t'];?> ед.</td>
<td align='center'><?=$data['amount_c_t'];?> ед.</td>
<td align='center'><?=$data['amount_d_t'];?> ед.</td>
<td align='center'><?=$data['amount_e_t'];?> ед.</td>
<td align='center'><?=$data['amount_f_t'];?> ед.</td>
</tr>
<?PHP
	
	}

?>
</table>
<?PHP


}else echo "<center><b>Нету ничего :(</b></center><BR />";


?>


<?
$db->Query("SELECT * FROM db_stats_buy LIMIT 1");
$data = $db->FetchArray();

if(isset($_POST['stats'])){
# 1 фрукт 

# Рассчитываем сумму добавления покупки 
//$dobavim = $data['amount_a_t'] * 1;  // для 1 дерева 
$dobavim2 = $data['amount_b_t'] * 1;  // для 2 дерева 
$dobavim3 = $data['amount_c_t'] * 5;  // для 3 дерева 
$dobavim4 = $data['amount_d_t'] * 25;  // для 4 дерева 
$dobavim5 = $data['amount_e_t'] * 50;  // для 5 дерева 
$dobavim6 = $data['amount_f_t'] * 100;  // для 6 дерева 

# Рассчитываем сумму добавления доходности 
//$dohod = $data['amount_a_t'] * 0.02;  // для 1 дерева 
$dohod2 = $data['amount_b_t'] * 0.1;  // для 1 дерева 
$dohod3 = $data['amount_c_t'] * 0.80;  // для 1 дерева 
$dohod4 = $data['amount_d_t'] * 3.50;  // для 1 дерева 
$dohod5 = $data['amount_e_t'] * 8.00;  // для 1 дерева 
$dohod6 = $data['amount_f_t'] * 20.00;  // для 1 дерева 




# Добавляем
/*
if($data['amount_a_t'] >= 100) {
$db->Query("UPDATE db_config SET `amount_a_t` = `amount_a_t` + '{$dobavim}'");
$db->Query("UPDATE db_config SET `a_in_h` = `a_in_h` + '{$dohod}'");
}
*/

# 2 фрукт 


# Добавляем
if($data['amount_b_t'] >= 100) {
$db->Query("UPDATE db_config SET `amount_b_t` = `amount_b_t` + '{$dobavim2}'");
$db->Query("UPDATE db_config SET `b_in_h` = `b_in_h` + '{$dohod2}'");
}



# 3 фрукт 


# Добавляем
if($data['amount_c_t'] >= 100) {
$db->Query("UPDATE db_config SET `amount_c_t` = `amount_c_t` + '{$dobavim3}'");
$db->Query("UPDATE db_config SET `c_in_h` = `c_in_h` + '{$dohod3}'");
}

# 4 фрукт 


# Добавляем
if($data['amount_d_t'] >=100) {
$db->Query("UPDATE db_config SET `amount_d_t` = `amount_d_t` + '{$dobavim4}'");
$db->Query("UPDATE db_config SET `d_in_h` = `d_in_h` + '{$dohod4}'");
}

# 5 фрукт 


# Добавляем
if($data['amount_e_t'] >= 100) {
$db->Query("UPDATE db_config SET `amount_e_t` = `amount_e_t` + '{$dobavim5}'");
$db->Query("UPDATE db_config SET `e_in_h` = `e_in_h` + '{$dohod5}'");
}

# 6 фрукт 


# Добавляем
if($data['amount_f_t'] >= 100) {
$db->Query("UPDATE db_config SET `amount_f_t` = `amount_f_t` + '{$dobavim6}'");
$db->Query("UPDATE db_config SET `f_in_h` = `f_in_h` + '{$dohod6}'");
}


echo "<script>swal('Успех!', 'Запросы выполнены!', 'success');</script>";
}
?>
<center>
<form action="" method="POST">
<button type="submit" name="stats" class="btn btn-success">Выполнить запросы</button>
</form>
</center>







</div>
