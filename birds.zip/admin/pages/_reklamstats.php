<div class="page-header">
	<h1>Рекламная Статистика</h1>
</div>

<?PHP
$time=time()-86400;
$reklam=array();
$re=array();
if(isset($_GET[n])){
$db->Query("SELECT refsite FROM db_users_a ORDER BY `id` DESC limit 500");}else{
$db->Query("SELECT refsite FROM db_users_a where date_reg > $time");}
while($bord = $db->FetchArray()){
if(empty($bord[refsite])){ $bord[refsite]="Cтранник";}
array_push($reklam,"$bord[refsite]");
}

$reklam=array_flip(array_count_values($reklam));
foreach ($reklam as $key => $val) {
array_push($re,"$key");
}
arsort($re);
?>
<center></br>
<a id='new1' href="index.php?menu=reklamstats" class="btn_3d" style="margin-right: 10px;">Последнии 24 часа</a>
<a href="index.php?menu=reklamstats&n=1" class="btn_3d">Последнии 500 рег</a></center>
<center>
<? if(!isset($_GET[n])){ echo"<h3>Последнии 24 часа</h3>";}else{ echo"<h3>Последнии 500 рег</h3>";} ?>
<table cellpadding='3' cellspacing='0' class='table table-bordered' align='center' width="99%">
    <thead>
		<tr>
			<td>№</td>        
			<td>Пришел с:</td>
			<td>Колличество</td>
		</tr>
    </thead>
	<?
	   $i=1; 
	  foreach ($re as $key => $val) {?>
        <tr> 
   	    <td><?=$i?></td>        
        <td><?=$reklam[$val]?></td>
        <td><?=$val?></td>
    </tr>        
    <? $i++; } ?>
</table>