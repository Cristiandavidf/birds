<div class="page-header">
	<h1>Список блогов</h1>
</div>

<center><a href = "index.php?menu=blogs" class="stn">Список статьей</a> || <a href = "index.php?menu=blogs&add" class="stn">Добавить статью</a></center>
<BR />
<?PHP
if(isset($_POST["del"])){

$ret_id = intval($_POST["del"]);

$db->Query("DELETE FROM ".$pref."_blogs WHERE id = '$ret_id'");
	
	echo "<center><b>Статья удалена</b></center><BR />";

}

# добавление новости
if(isset($_GET["add"])){

	if(isset($_POST["title"], $_SESSION["add_news"]) AND $_SESSION["add_news"] == $_POST["add_news"]){
	
	unset($_SESSION["add_news"]);
	
	$title = $func->TextClean($_POST["title"]);
	$text = $_POST["ntext"];
	$text = $db->RealEscape($_POST["ntext"]);
		if(strlen($title) >= 3){
		
			$db->Query("INSERT INTO ".$pref."_blogs (title, news, date_add) VALUES ('$title','$text','".time()."')");
			echo "<center><b><font color = '#914A1F'>Новость добавлена</font></b></center><BR />";
			
		}else echo "<center><b><font color = 'red'>Заголовок не может быть менее 3х символов</font></b></center><BR />";
	
	}

?>

<form action="" method="post">
<b>Заголовок:</b><BR />
<input type="text" name="title" size="45" value="<?=(isset($_POST["title"])) ? $_POST["title"] : false; ?>" /><BR /><BR />
<b>Новость:</b><BR />
<textarea name="ntext" cols="78" rows="25"><?=(isset($_POST["ntext"])) ? $_POST["ntext"] : false; ?></textarea><BR />
<center><input type="submit" value="Сохранить" class="btn_8"/></center>
<?PHP
$_SESSION["add_news"] = rand(1,1000);
?>
<input type="hidden" name="add_news" value="<?=$_SESSION["add_news"]; ?>" />

</form>


<?PHP
return;
}


# редактирование
if(isset($_GET["edit"])){

$idr = intval($_GET["edit"]);

$db->Query("SELECT * FROM ".$pref."_blogs WHERE id = '$idr' LIMIT 1");

if($db->NumRows() != 1){ echo "<center><b>Статья с таким ID не найдена</b></center><BR />"; return;}

	if(isset($_POST["title"])){
	
	$title = $func->TextClean($_POST["title"]);
	$title = (strlen($title) > 0) ? $title : "Без заголовка";
	$text = $_POST["ntext"];
	$text =  $db->RealEscape($_POST["ntext"]);
	$db->Query("UPDATE ".$pref."_blogs SET title = '$title', news = '$text' WHERE id = '$idr'");
	$db->Query("SELECT * FROM ".$pref."_blogs WHERE id = '$idr' LIMIT 1");
	
	 echo "<center><b>Статья отредактирована</b></center><BR />";
	
	}

$news = $db->FetchArray();




?>

<form action="" method="post">
<b>Заголовок:</b><BR />
<input type="text" name="title" size="45" value="<?=$news["title"]; ?>" /><BR /><BR />
<b>Новость:</b><BR />
<textarea name="ntext" cols="78" rows="25"><?=$news["news"]; ?></textarea><BR />
<center><input type="submit" value="Сохранить" class="btn_8"/></center>
</form>


<?PHP

return;
}

$db->Query("SELECT * FROM ".$pref."_blogs ORDER BY id DESC");

if($db->NumRows() > 0){

?>
<table cellpadding='3' cellspacing='0' border='0' class='table' align='center' width="99%">
  <tr bgcolor="#efefef">
    <td align="center" width="50" class="m-tb">ID</td>
    <td align="center" class="m-tb">Название</td>
	<td align="center" width="70" class="m-tb">Действие</td>
  </tr>


<?PHP

	while($data = $db->FetchArray()){
	
	?>
	<tr class="htt">
    <td align="center" width="50"><?=$data["id"]; ?></td>
    <td align="center"><a href="index.php?menu=blogs&edit=<?=$data["id"]; ?>" style="font-size: 18px;"><?=$data["title"]; ?></a></td>
	<td align="center" width="70">
	<form action="" method="post">
	<input type="hidden" name="del" value="<?=$data["id"]; ?>" />
	<input type="submit" value="Удалить" class="btn btn-danger"/>
	</form>
	</td>
  	</tr>
	<?PHP
	
	}

?>

</table>
<?PHP

}else echo "<center><b>Статьей нет</b></center><BR />";
?>
