<!DOCTYPE html>
<html>
	<head>
		<title>Успешное пополнение</title>
		<meta charset="utf-8" />
		<link rel="stylesheet" href="/assets/css/main.css" />
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" integrity="sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB" crossorigin="anonymous">
		<link rel="icon" href="/favicon.ico">
	</head>
	<body>

<div class="row">
    <div class="col-md-3"></div>
    <div class="col-md-6"><br/>
        <div class="card p-5 bg-success text-light">
            
<center><h3>Ваш баланс успешно пополнен</h3>
<a class="btn btn-outline-light" href="/profile">Перейти в аккаунт</a>
</center>

        </div>
    </div>
    <div class="col-md-3"></div>
</div>




</body>
</html>