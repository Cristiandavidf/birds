<!DOCTYPE html>
<html>
<head>
 <title>JuiceScript - {!TITLE!}</title>
 <meta name="description" content="{!DESCRIPTION!}">
 <meta name="keywords" content="{!KEYWORDS!}">
 <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
 <meta http-equiv="x-ua-compatible" content="ie=edge">
 <link href="/assets/css/bootstrap.min.css" rel="stylesheet">
 <link href="/assets/css/mdb.min.css" rel="stylesheet">
 <link href="/assets/css/main.css" rel="stylesheet">
 <link href="/assets/css/cars.css" rel="stylesheet">
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css" />

 <script type="text/javascript" src="/assets/js/functions.js"></script>
 <script src="/assets/js/jquery.min.js"></script>
 <script src='https://www.google.com/recaptcha/api.js'></script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/wow/1.1.2/wow.min.js"></script>
 <script>new WOW().init();</script>
 <link rel="icon" href="/favicon.ico">

</head>
<body>


<?
$usid = $_SESSION["user_id"];
$db->Query("SELECT * FROM db_users_a WHERE id = '$usid'");
$user_data = $db->FetchArray();

$newsus = $user_data["news"];

$numnews = 0;
$db->Query("SELECT * FROM db_news ORDER BY id DESC");
while($newses = $db->FetchArray()){
$numnews = $numnews+1;
}
?>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-navbar">
<a class="navbar-brand wow bounceInLeft" href="/"><img src="/img/logo.png" style="margin1: -5px 0 -8px;width: 97%;"></a>
	<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
	<span class="navbar-toggler-icon"></span>
	</button>
	<div class="collapse navbar-collapse" id="navbarsExampleDefault">
	<ul class="navbar-nav mr-auto">
	<?php if($numnews == $newsus){ ?>
		<li class="nav-item"><a class="nav-link" href="/news">Новости</a></li>
	<?php } else if($numnews > $newsus) { $newsplus = $numnews-$newsus; ?>
		<li class="nav-item"><a class="nav-link" href="/news"><font id="blink">Новости</font></a></li>
	<?php } ?>
	<li class="nav-item"><a class="nav-link" href="/about">О нас</a></li>
<?php if ($_SESSION["user_id"]) : ?>
	<li class="nav-item"><a class="nav-link" href="/contest">Конкурсы</a></li>		
<?php endif;?>
<?php if (!$_SESSION["user_id"]) : ?>
	<li class="nav-item"><a class="nav-link" href="/contest">Конкурсы</a></li>	
	<li class="nav-item"><a class="nav-link" href="/serfing">Серфинг</a></li>
<?php endif;?>
	<li class="nav-item"><a class="nav-link" href="/stats">Статистика</a></li>
	<li class="nav-item"><a class="nav-link" href="/otziv">Отзывы</a></li>
	<li class="nav-item"><a class="nav-link" href="/rules">Правила</a></li>
	<li class="nav-item"><a class="nav-link" href="/help">Помощь</a></li>
	<li class="nav-item"><a href="#" onclick="doGTranslate('ru|ru');return false;" title="Russian" class="gflag nturl" style="background-position:-500px -200px;"><img src="//gtranslate.net/flags/blank.png" height="22" width="32" alt="Russian" /></a></li>
	<li class="nav-item"><a href="#" onclick="doGTranslate('ru|en');return false;" title="English" class="gflag nturl" style="background-position:-0px -0px;"><img src="//gtranslate.net/flags/blank.png" height="22" width="32" alt="English" /></a></li>
	
	</ul>
	<ul class="navbar-nav navbar-right">
<?php if ($_SESSION["user_id"]) : ?>
	<li class="nav-item"><a class="nav-link" href="/profile"><?=$_SESSION["user"]; ?></a></li>
<?php endif;?>
<?php if (!$_SESSION["user_id"]) : ?>
	<li class="nav-item"><a class="nav-link btn-outline-warning" href="/signup">Регистрация</a></li>
	<li class="nav-item"><a class="nav-link btn-outline-light" href="/login">Вход</a></li>
<?php endif;?>
	</ul>
	</div>
</nav>
