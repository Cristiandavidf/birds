<center class="p-2">
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- mybirds head -->
<ins class="adsbygoogle"
     style="display:inline-block;width:728px;height:90px"
     data-ad-client="ca-pub-3734850630008787"
     data-ad-slot="7911613330"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
</center>