<center class="p-2">
        <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- home mybirds -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-3734850630008787"
     data-ad-slot="2275309128"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
</center>