<div class="clear"></div>
<div class="leftbar">
    <div class="menu2 divide">
	<i class="fa fa-bars"></i><span>Игровое меню</span>
    </div>
    <div class="menu__wrapper">
        <div class="topbar leftbar__topbar">
            <div class="topbar__bottom">
                <div class="topbar__balance">
                    <p>Баланс покупок <br/><b>{!BALANCE_B!}</b></p>
		<a class="btn btn-sm btn-success" href="/insert"><i class="fa fa-arrow-up"></i><span> Пополнить</span></a>
                </div>
                <div class="divide topbar__balance">
                    <p>Баланс для вывода<br/><b> {!BALANCE_P!} </b></p>
		<a class="btn btn-sm btn-danger" href="/withdrawals"><i class="fa fa-arrow-down"></i><span> Вывести</span></a>
                </div>
            </div>
	</div>


	<ul class="leftbar__menu">
		<li><a href="/profile" style="border: 0 !important;"><i class="fa fa-bars"></i><span>Мой профиль </span> </a></li>
		<li><a href="/shop"><i class="fa fa-twitter"></i><span>Покупка птиц</span></a></li>
		<li><a href="/store"><i class="fa fa-money"></i><span>Собрать прибыль</span></a></li>

		<li><a href="/daily"><i class="fa fa-gift"></i><span>Ежедневный бонус</span></a></li>
		<li><a href="/hours3"><i class="fa fa-gift"></i><span>3 часовой бонус</span></a></li>
		<li><a href="/account/serfing"><i class="fa fa-eye"></i><span>Серфинг сайтов</span></a></li>
		<li><a href="/liders"><i class="fa fa-rub"></i><span>Лидеры дня</span></a></li>
		<li><a href="/change"><i class="fa fa-exchange"></i><span>Обменник</span></a></li>
		<li><a href="/referrals"><i class="fa fa-users"></i><span>Мои рефералы</span></a></li>

		<li><a href="/settings"><i class="fa fa-gear"></i><span>Настройки</span></a></li>
		<li><a href="/output"><i class="fa fa-sign-out"></i><span>Выход</span></a></li>
	</ul>
	
	<style>
.contest a:hover{color: #ffe79d;}
</style>
<ul class="leftbar__menu text-white contest p-2 waves-effect waves-light" style="background: #ef5567 !important;"><a href="/contest"><center><h5>КОНКУРСЫ</h5><hr class="my-1"><h3><b>7000 РУБ</b></h3><h5>ПРИЗОВОЙ ФОНД.</h5></center></a>
</ul>
</div>
</div>