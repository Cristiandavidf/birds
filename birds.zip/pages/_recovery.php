<?PHP

$_OPTIMIZATION["title"] = "Восстановление пароля";

$_OPTIMIZATION["description"] = "Восстановление забытого пароля";

$_OPTIMIZATION["keywords"] = "Восстановление забытого пароля";



if(isset($_SESSION["user_id"])){ Header("Location: /account"); return; }



?>

	<!-- Get Started -->

<div class="title">
        <h3>ВОССТАНОВЛЕНИЕ ПАРОЛЯ</h3>
    </div>

<div class="container">
<div class="row">
	<div class="col-lg-4 col-md-3"></div>
	<div class="col-lg-4 col-md-6"><br/>
	<div class="card card-body"><h5>Введите email</h5><hr>
<?PHP



	if(isset($_POST["email"])){



	if (!empty($_POST['g-recaptcha-response'])) {

		

		$email = $func->IsMail($_POST["email"]);

		$time = time();

		$tdel = $time + 60*15;

		

			if($email !== false){

				

				$db->Query("DELETE FROM db_recovery WHERE date_del < '$time'");

				$db->Query("SELECT COUNT(*) FROM db_recovery WHERE ip = INET_ATON('".$func->UserIP."') OR email = '$email'");

				if($db->FetchRow() == 0){

				

					$db->Query("SELECT id, user, email, pass FROM db_users_a WHERE email = '$email'");

					if($db->NumRows() == 1){

					$db_q = $db->FetchArray();

					

					# Вносим запись в БД

					$db->Query("INSERT INTO db_recovery (email, ip, date_add, date_del) VALUES ('$email',INET_ATON('".$func->UserIP."'),'$time','$tdel')");

					

					# Отправляем пароль

					$sender = new isender;

					$sender -> RecoveryPassword($db_q["email"], $db_q["pass"], $db_q["email"]);

					

					echo "<center><font color = 'green'><b>Данные для входа отправлены на E-mail!</b></font></center>";

					?>

					</div>

					<div class="clr"></div>	

					<?PHP

					return; 

					

					}else echo "<center><font color = 'red'><b>Пользователь с таким E-mail не зарегистрирован!</b></font></center>";

				

				}else echo "<center><font color = 'red'><b>На Ваш E-mail или IP уже был отправлен пароль за последние 15 минут!</b></font></center>";

				

			}else echo "<center><font color = 'red'><b>E-mail указан неверно!</b></font></center>";

		

		}else echo "<center><font color = 'red'><b>Капча не пройдёна!</b></font></center>";

	

	}



?>



<form action="" method="post">
<div class="form-group login-form">
<input name="email" class="form-control" placeholder="Введите Email на него будет выслан пароль" type="text" size="25" maxlength="50" value="<?=(isset($_POST["email"])) ? $_POST["email"] : false; ?>"/>
</div>


	 <center style="height: 90px;position: relative;clear:both;" class="g-recaptcha" data-sitekey="<?=$config->recaptcha;?>"></center>

<center><input type="submit" value="Выслать пароль" class="btn btn-lg btn-info"></center></div>

</form>
</div>
		
</div>
<div class="col-lg-4 col-md-3"></div>
</div></div>
<br/><br/>
