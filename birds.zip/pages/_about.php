<?PHP
$_OPTIMIZATION["title"] = "О проекте";
$_OPTIMIZATION["description"] = "Маркетинг проекта";
$_OPTIMIZATION["keywords"] = "Немного о нас и о нашем проекте";

$db->Query("SELECT * FROM db_config WHERE id = '1' LIMIT 1");
$sonfig_site = $db->FetchArray();

$lvl1= ($sonfig_site["a_in_h"]*100)/$sonfig_site["amount_a_t"]/$sonfig_site["items_per_coin"]*24*30; // окупаемость
$lvl2= ($sonfig_site["b_in_h"]*100)/$sonfig_site["amount_b_t"]/$sonfig_site["items_per_coin"]*24*30; // окупаемость
$lvl3= ($sonfig_site["c_in_h"]*100)/$sonfig_site["amount_c_t"]/$sonfig_site["items_per_coin"]*24*30; // окупаемость
$lvl4= ($sonfig_site["d_in_h"]*100)/$sonfig_site["amount_d_t"]/$sonfig_site["items_per_coin"]*24*30; // окупаемость
$lvl5= ($sonfig_site["e_in_h"]*100)/$sonfig_site["amount_e_t"]/$sonfig_site["items_per_coin"]*24*30; // окупаемость
$lvl6= ($sonfig_site["f_in_h"]*100)/$sonfig_site["amount_f_t"]/$sonfig_site["items_per_coin"]*24*30; // окупаемость
$lvl7= ($sonfig_site["g_in_h"]*100)/$sonfig_site["amount_g_t"]/$sonfig_site["items_per_coin"]*24*30; // окупаемость
$lvl8= ($sonfig_site["h_in_h"]*100)/$sonfig_site["amount_h_t"]/$sonfig_site["items_per_coin"]*24*30; // окупаемость
$lvl9= ($sonfig_site["i_in_h"]*100)/$sonfig_site["amount_i_t"]/$sonfig_site["items_per_coin"]*24*30; // окупаемость

?>


<div class="title r-t">
	<h3 class=" font-weight-bold">О проекте <?=$config->SITE_NAME;?></h3>
</div>
<?PHP 
include("inc/_adsense_b.php"); 
?>
<!-- Projects section v.3 -->
<section class="container my-1">

  <!-- Section description -->
  <p class="card card-body text-center w-responsive mx-auto mb-5">Это современная экономическая стратегия, которая позволяет не только интересно проводить время, но и зарабатывать реальные деньги.
Став пользователем нашего проекта, вы сможете вести собственное дело – приобретать птиц, приносящие прибыль, или рекламировать свои проекты.
В нашей системе все функционнирует в автоматическом режиме, как оплата рекламы так и вывод заработанных средств.
Разработкой проекта занималась команда профессионалов, а это значит, что наш проект работает бесперебойно и доступен всегда!
Также пользователи могут быть уверены в сохранности своих вложений – высокий уровень безопасности позволяет нам это гарантировать.</p>

<div class="row wow fadeIn" data-wow-delay="0.4s" style="visibility: visible; animation-name: fadeIn; animation-delay: 0.4s;">

                    <!-- Grid column -->
                    <div class="col-md-4">

                        <!-- Grid row -->
                        <div class="row text-center pb-5">
                            <div class="col-md-12">
                                <i class="fa fa-home fa-3x purple-text pb-3"></i>
                                <h4 class="font-weight-bold">Маркетинг</h4>
                                <p class="grey-text">Вы будете зарабатывать от своих птиц 29% - 45% в месяц стабильно! И ЭТО НЕ ПРЕДЕЛ!</p>
                            </div>
                        </div>
                        <!-- Grid row -->

                        <!-- Grid row -->
                        <div class="row text-center pb-5">
                            <div class="col-md-12">
                                <i class="fa fa-gift fa-3x red-text pb-3"></i>
                                <h4 class="font-weight-bold">Подарки</h4>
                                <p class="grey-text">За регистрацию птица в подарок! Ежедевный бонус! Бонусы при пополнении.</p>
                            </div>
                        </div>
                        <!-- Grid row -->

                    </div>
                    <!-- Grid column -->


                    <!-- Grid column -->
                    <div class="col-md-4">

                        <!-- Grid row -->
                        <div class="row text-center pb-5">
                            <div class="col-md-12">
                                <i class="fa fa-link fa-3x text-info pb-3"></i>
                                <h4 class="font-weight-bold">Серфинг</h4>
                                <p class="grey-text">Вы можете зарабатывать просматривая ссылки, а также рекламировать свои ссылки.</p>
                            </div>
                        </div>
                        <!-- Grid row -->

                        <!-- Grid row -->
                        <div class="row text-center pb-5">
                            <div class="col-md-12">
                                <i class="fa fa-users fa-3x orange-text pb-3"></i>
                                <h4 class="font-weight-bold">Рефералка</h4>
                                <p class="grey-text">У нас 3-х уровневая реф программа 7-5-2%. +Птица за каждого реферала "Туки" ПОДАРОК!</p>
                            </div>
                        </div>
                        <!-- Grid row -->

                    </div>
                    <!-- Grid column -->


                    <!-- Grid column -->
                    <div class="col-md-4">

                        <!-- Grid row -->
                        <div class="row text-center pb-5">
                            <div class="col-md-12">
                                <i class="fa fa-money fa-3x green-text pb-3"></i>
                                <h4 class="font-weight-bold">Автовыплаты</h4>
                                <p class="grey-text">На нашем проекте можно выводить на платежные системы Payeer, Qiwi, Яндекс деньги.</p>
                            </div>
                        </div>
                        <!-- Grid row -->

                        <!-- Grid row -->
                        <div class="row text-center pb-5">
                            <div class="col-md-12">
                                <i class="fa fa-umbrella fa-3x blue-text pb-3"></i>
                                <h4 class="font-weight-bold">Без лимитов</h4>
                                <p class="grey-text">У нас нет ограничений на вывод, выводи сколько заработал! БАЛЛОВ НЕТ и КЕШ-ПОИНТОВ.</p>
                            </div>
                        </div>
                        <!-- Grid row -->

                    </div>
                    <!-- Grid column -->

                </div>


  </div>
  <!-- Grid row -->


</section>
<!-- Projects section v.3 -->


    <div class="container"> 
<?PHP 
include("inc/_adsense.php"); 
?>

    </div>
<br/>
<div class="container">

<div class="title text-center"><h3 class="">МАРКЕТИНГ ИГРЫ</h3><br/></div>
<div class="row text-center">


<div class="col-md-4"><br/><br/>
<div class="card mt-5" style="background: #fff; border-radius: 2em;">
<div class="card-body">
<img src="/img/items/1.png" style="max-width: 95%;margin-top: -120px;">
<h4 class="text-success" style="text-transform: uppercase;"><b><?=$sonfig_site["name_a"]; ?></b></h4>
<hr>
<i>Окупаемость: <b><?=sprintf("%.0f",$lvl1); ?>% в месяц</b><br>
Доход в месяц: <b><?=sprintf("%.2f",$sonfig_site["a_in_h"]*24*30/10000); ?> руб.</b><br>
Доход в день: <b><?=sprintf("%.2f",$sonfig_site["a_in_h"]*24/10000); ?> руб.</b></i><hr>
<b class="text-danger">Цена: <?=$sonfig_site["amount_a_t"]/100; ?> руб.</b>
</div>
</div>
</div><!-- lvl 1 -->

<div class="col-md-4"><br/><br/>
<div class="card mt-5" style="background: #fff; border-radius: 2em;">
<div class="card-body">
<img src="/img/items/2.png" style="max-width: 95%;margin-top: -120px;">
<h4 class="text-success" style="text-transform: uppercase;"><b><?=$sonfig_site["name_b"]; ?></b></h4>
<hr>
<i>Окупаемость: <b><?=sprintf("%.0f",$lvl2); ?>% в месяц</b><br>
Доход в месяц: <b><?=sprintf("%.2f",$sonfig_site["b_in_h"]*24*30/10000); ?> руб.</b><br>
Доход в день: <b><?=sprintf("%.2f",$sonfig_site["b_in_h"]*24/10000); ?> руб.</b></i><hr>
<b class="text-danger">Цена: <?=$sonfig_site["amount_b_t"]/100; ?> руб.</b>
</div>
</div>
</div><!-- lvl 2 -->

<div class="col-md-4"><br/><br/>
<div class="card mt-5" style="background: #fff; border-radius: 2em;">
<div class="card-body">
<img src="/img/items/3.png" style="max-width: 95%;margin-top: -120px;">
<h4 class="text-success" style="text-transform: uppercase;"><b><?=$sonfig_site["name_c"]; ?></b></h4>
<hr>
<i>Окупаемость: <b><?=sprintf("%.0f",$lvl3); ?>% в месяц</b><br>
Доход в месяц: <b><?=sprintf("%.2f",$sonfig_site["c_in_h"]*24*30/10000); ?> руб.</b><br>
Доход в день: <b><?=sprintf("%.2f",$sonfig_site["c_in_h"]*24/10000); ?> руб.</b></i><hr>
<b class="text-danger">Цена: <?=$sonfig_site["amount_c_t"]/100; ?> руб.</b>
</div>
</div>
</div><!-- lvl 3 -->

<div class="col-md-4"><br/><br/>
<div class="card mt-5" style="background: #fff; border-radius: 2em;">
<div class="card-body">
<img src="/img/items/4.png" style="max-width: 95%;margin-top: -120px;">
<h4 class="text-success" style="text-transform: uppercase;"><b><?=$sonfig_site["name_d"]; ?></b></h4>
<hr>
<i>Окупаемость: <b><?=sprintf("%.0f",$lvl4); ?>% в месяц</b><br>
Доход в месяц: <b><?=sprintf("%.2f",$sonfig_site["d_in_h"]*24*30/10000); ?> руб.</b><br>
Доход в день: <b><?=sprintf("%.2f",$sonfig_site["d_in_h"]*24/10000); ?> руб.</b></i><hr>
<b class="text-danger">Цена: <?=$sonfig_site["amount_d_t"]/100; ?> руб.</b>
</div>
</div>
</div><!-- lvl 4 -->

<div class="col-md-4"><br/><br/>
<div class="card mt-5" style="background: #fff; border-radius: 2em;">
<div class="card-body">
<img src="/img/items/5.png" style="max-width: 95%;margin-top: -120px;">
<h4 class="text-success" style="text-transform: uppercase;"><b><?=$sonfig_site["name_e"]; ?></b></h4>
<hr>
<i>Окупаемость: <b><?=sprintf("%.0f",$lvl5); ?>% в месяц</b><br>
Доход в месяц: <b><?=sprintf("%.2f",$sonfig_site["e_in_h"]*24*30/10000); ?> руб.</b><br>
Доход в день: <b><?=sprintf("%.2f",$sonfig_site["e_in_h"]*24/10000); ?> руб.</b></i><hr>
<b class="text-danger">Цена: <?=$sonfig_site["amount_e_t"]/100; ?> руб.</b>
</div>
</div>
</div><!-- lvl 5 -->


<div class="col-md-4"><br/><br/>
<div class="card mt-5" style="background: #fff; border-radius: 2em;">
<div class="card-body">
<img src="/img/items/6.png" style="max-width: 95%;margin-top: -120px;">
<h4 class="text-success" style="text-transform: uppercase;"><b><?=$sonfig_site["name_f"]; ?></b></h4>
<hr>
<i>Окупаемость: <b><?=sprintf("%.0f",$lvl6); ?>% в месяц</b><br>
Доход в месяц: <b><?=sprintf("%.2f",$sonfig_site["f_in_h"]*24*30/10000); ?> руб.</b><br>
Доход в день: <b><?=sprintf("%.2f",$sonfig_site["f_in_h"]*24/10000); ?> руб.</b></i><hr>
<b class="text-danger">Цена: <?=$sonfig_site["amount_f_t"]/100; ?> руб.</b>
</div>
</div>
</div><!-- lvl 6 -->


<div class="col-md-4"><br/><br/>
<div class="card mt-5" style="background: #fff; border-radius: 2em;">
<div class="card-body">
<img src="/img/items/7.png" style="max-width: 95%;margin-top: -120px;">
<h4 class="text-success" style="text-transform: uppercase;"><b><?=$sonfig_site["name_g"]; ?></b></h4>
<hr>
<i>Окупаемость: <b><?=sprintf("%.0f",$lvl7); ?>% в месяц</b><br>
Доход в месяц: <b><?=sprintf("%.2f",$sonfig_site["g_in_h"]*24*30/10000); ?> руб.</b><br>
Доход в день: <b><?=sprintf("%.2f",$sonfig_site["g_in_h"]*24/10000); ?> руб.</b></i><hr>
<b class="text-danger">Цена: <?=$sonfig_site["amount_g_t"]/100; ?> руб.</b>
</div>
</div>
</div><!-- lvl 7 -->


<div class="col-md-4"><br/><br/>
<div class="card mt-5" style="background: #fff; border-radius: 2em;">
<div class="card-body">
<img src="/img/items/8.png" style="max-width: 95%;margin-top: -120px;">
<h4 class="text-success" style="text-transform: uppercase;"><b><?=$sonfig_site["name_h"]; ?></b></h4>
<hr>
<i>Окупаемость: <b><?=sprintf("%.0f",$lvl8); ?>% в месяц</b><br>
Доход в месяц: <b><?=sprintf("%.2f",$sonfig_site["h_in_h"]*24*30/10000); ?> руб.</b><br>
Доход в день: <b><?=sprintf("%.2f",$sonfig_site["h_in_h"]*24/10000); ?> руб.</b></i><hr>
<b class="text-danger">Цена: <?=$sonfig_site["amount_h_t"]/100; ?> руб.</b>
</div>
</div>
</div><!-- lvl 8 -->


<div class="col-md-4"><br/><br/>
<div class="card mt-5" style="background: #fff; border-radius: 2em;">
<div class="card-body">
<img src="/img/items/9.png" style="max-width: 95%;margin-top: -120px;">
<h4 class="text-success" style="text-transform: uppercase;"><b><?=$sonfig_site["name_i"]; ?></b></h4>
<hr>
<i>Окупаемость: <b><?=sprintf("%.0f",$lvl9); ?>% в месяц</b><br>
Доход в месяц: <b><?=sprintf("%.2f",$sonfig_site["i_in_h"]*24*30/10000); ?> руб.</b><br>
Доход в день: <b><?=sprintf("%.2f",$sonfig_site["i_in_h"]*24/10000); ?> руб.</b></i><hr>
<b class="text-danger">Цена: <?=$sonfig_site["amount_i_t"]/100; ?> руб.</b>
</div>
</div>
</div><!-- lvl 9 -->


<div class="col-md-4">
</div>

<div class="col-md-4"><br/><br/>
<div class="card mt-5" style="background: #fff; border-radius: 2em;">
<div class="card-body">
<img src="/img/items/0.png" style="max-width: 95%;margin-top: -120px;">
<h4 class="text-success" style="text-transform: uppercase;"><b><?=$sonfig_site["name_j"]; ?></b></h4>
<hr>
<i>
Приносит в час: <b>+<?=sprintf("%.0f",$sonfig_site["j_in_h"]); ?> яиц</b></i><hr>
<b class="text-danger">За каждого реферала</b>
</div>
</div>
</div><!-- lvl 9 -->

<div class="col-md-4">
</div>

</div>
<!-- End Shop List -->
</div>



<center>
Проект честный и открытый, который поможет Вам приумножить свои средства.<br/>
У нас бесперебойные выплаты и честные условия - присоединяйтесь!.
</center><br/>
</div>
