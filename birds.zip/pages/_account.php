<div class="account">
<div class="clearfix"></div>
<?PHP include("inc/_user_menu.php"); ?>
<div class="content">

<div class="title">
<h3>{!TITLE!}</h3>
</div>
<div>
<?PHP

$_OPTIMIZATION["title"] = "Аккаунт";
$_OPTIMIZATION["description"] = "Аккаунт пользователя";
$_OPTIMIZATION["keywords"] = "Аккаунт, личный кабинет, пользователь";


# Блокировка сессии
if(!isset($_SESSION["user_id"])){ Header("Location: /"); return; }

if(isset($_GET["sel"])){
	$smenu = strval($_GET["sel"]);
			
	switch($smenu){
		
		case "404": include("pages/_404.php"); break; // Страница ошибки
		case "room": include("pages/account/_room.php"); break; // Лотерея
		case "referrals": include("pages/account/_referrals.php"); break; // Рефералы
		case "change": include("pages/account/_change.php"); break; // Обменный раздел
		case "withdrawals": include("pages/account/_withdrawals.php"); break; // Выплата пользователю
		case "insert": include("pages/account/_insert.php"); break; // Пополнение баланса
		case "settings": include("pages/account/_settings.php"); break; // Настройки
		case "daily": include("pages/account/_bonus.php"); break; // КАЖДЫЙ ДЕНЬ
		case "hours3": include("pages/account/_bonus2.php"); break; // КАЖДЫЙ ЧАС
		case "chat": include("pages/account/_chat.php"); break; // Чатовка
		case "liders": include("pages/account/_liders.php"); break; // Лидеры (накопительный банк)
		case "shop": include("pages/account/_shop.php"); break; // Покупка
		case "store": include("pages/account/_store.php"); break; // Сбор прибыли
		case "energy": include("pages/account/_energy.php"); break; // Раздел баллов (энергия)
case "serfing": include("pages/account/myserfing/_serfing.php"); break; // Серфинг
case "serfing_add": include("pages/account/myserfing/_serfing_add.php"); break; // Серфинг
case "serfing_cabinet": include("pages/account/myserfing/_serfing_cabinet.php"); break; // Серфинг
case "serfing_moder": include("pages/account/myserfing/_serfing_moder.php"); break; // Серфинг
case "serfing_account": include("pages/account/myserfing/_serfing_account.php"); break; // Серфинг
		case "output": @session_destroy(); Header("Location: /"); return; break; // Выход
				
	# Страница ошибки
	default: @include("pages/_404.php"); break;
			
	}
			
}else @include("pages/account/_user_account.php");

?>

</div>
</div>
<div class="clearfix"></div></div>