<?PHP
$_OPTIMIZATION["title"] = "Регистрация";
$_OPTIMIZATION["description"] = "Регистрация пользователя в системе";
$_OPTIMIZATION["keywords"] = "Регистрация нового участника в системе";

if(isset($_SESSION["user_id"])){ Header("Location: /profile"); return; }
?>

	<!-- Get Started -->


<div class="container">
<div class="row">
	<div class="col-lg-3 col-md-3"></div>
	<div class="col-lg-6 col-md-6"><br/>
	<div class="card-body mt-3"><div class="title">
        <h3>РЕГИСТРАЦИЯ В ПРОЕКТЕ</h3><br/><br/>
    </div>
<?PHP

$ddel = time() + 60*60*24;
$dadd = time();

# Случайная очистка статистики регистраций за 24 часа
$db->Query("DELETE FROM db_stats_r24 WHERE date_del < '$dadd'");

	# Регистрация
	if(isset($_POST["login"])){

	$login = $func->IsLogin($_POST["login"]);
	$pass = $func->IsPassword($_POST["pass"]);
	$rules = isset($_POST["rules"]) ? true : false;
	$time = time();
	$ip = $func->UserIP;
	$ipregs = $db->Query("SELECT * FROM `db_users_a` WHERE INET_NTOA(db_users_a.ip) = '$ip' ");
	$ipregs = $db->NumRows();
	
	if (!empty($_COOKIE['referer'])) $sate = $_COOKIE['referer'];
        $sait = parse_url($sate);
        $site = $sait['host'];
	
	$email = $func->IsMail($_POST["email"]);
	$referer_id = (isset($_COOKIE["i"]) AND intval($_COOKIE["i"]) > 0 AND intval($_COOKIE["i"]) < 1000000) ? intval($_COOKIE["i"]) : 1;
	$referer_name = "";
	
	if($referer_id != 1){
		$db->Query("SELECT user FROM db_users_a WHERE id = '$referer_id' LIMIT 1");
		if($db->NumRows() > 0){$referer_name = $db->FetchRow();}
		else{ $referer_id = 1; $referer_name = "Admin"; }
	}else{ $referer_id = 1; $referer_name = "Admin"; }

	if (!empty($_POST['g-recaptcha-response'])) {
	    
		if($rules){
			if($ipregs == 0) {

			if($email !== false){

			if($login !== false){

			if($pass == $_POST["pass"]){


			$db->Query("SELECT COUNT(*) FROM db_users_a WHERE user = '$login'");
			if($db->FetchRow() == 0){

			$db->Query("SELECT COUNT(*) FROM db_users_a WHERE email = '$email'");
			if($db->FetchRow() == 0){

		# Партнерская программа 3 уровня
		$db->Query("SELECT referer, referer_id FROM db_users_a WHERE id = '$referer_id' LIMIT 1");
		$stats_data = $db->FetchArray();
		$referer_name2=$stats_data["referer"];
		$referer_id2=$stats_data["referer_id"];

		$db->Query("SELECT referer, referer_id FROM db_users_a WHERE id = '$referer_id2' LIMIT 1");
		$stats_data3 = $db->FetchArray();
		$referer_name3=$stats_data3["referer"];
		$referer_id3=$stats_data3["referer_id"];
                        
		# Регаем пользователя
		$db->Query("INSERT INTO db_users_a (user, email, pass, referer, referer_id, referer_id2, referer_id3, date_reg, refsite, ip) 
		VALUES ('$login','{$email}','$pass','$referer_name','$referer_id','$referer_id2','$referer_id3','$time','$site',INET_ATON('$ip'))");
		$lid = $db->LastInsert();

		$db->Query("INSERT INTO db_users_b (id, user, last_sbor) VALUES ('$lid','$login', '".time()."')");

		# Начисление персонажа
		$citem = "a_t";
		$db->Query("UPDATE db_users_b SET $citem = $citem + 1, last_sbor = IF(last_sbor > 0, last_sbor, '".time()."') WHERE id = '$lid'");                  
		$life_time->AddItem($lid,$citem);

		# Вносим запись о покупке
		$db->Query("INSERT INTO db_stats_btree (user_id, user, tree_name, amount, date_add, date_del)
		VALUES ('$lid','$login','1-lvl-reg','0','".time()."','".(time()+60*60*24*15)."')");

		# Вносим запись в список регистраций за 24 часа
		$db->Query("INSERT INTO db_stats_r24 (user_id, date_reg, date_del) VALUES ('$lid','$dadd','$ddel')");

		# Вставляем статистику
		$db->Query("UPDATE db_stats SET all_users = all_users +1 WHERE id = '1'");



# +1 спиннер тому кто пригласил пользователя
   if (empty($referer_name)){

   //echo "";

   }

   else

   {

   $db->Query("SELECT referer, referer_id FROM db_users_a WHERE id = '$lid' ");

   $ref_bonus = $db->FetchArray();

   $user_name = $ref_bonus["referer"];

   $ref_id = $ref_bonus["referer_id"];

		# Начисление спиннера 
		$ref_bonus = "j_t";
		$db->Query("UPDATE db_users_b SET $ref_bonus = $ref_bonus + 1 WHERE id = '$ref_id'");                  
		$life_time->AddItem($ref_id,$ref_bonus);

   $db->Query("UPDATE db_users_b SET j_t = j_t +1 WHERE user = '$user_name' AND id = '$lid' ");

   }
// конец кода для бонуса рефералов

		echo "<center class='alert alert-success'>Вы успешно зарегистрировались. Используйте форму для входа в аккаунт.</center><BR /></div></div></div>";
header('Refresh: 3; URL=/login');
	?>

						<?PHP
						return;
							}else echo "<center><b><font color = 'red'>Указанный Email уже используется</font></b></center><BR />";
						}else echo "<center><b><font color = 'red'>Указанный логин уже используется</font></b></center><BR />";
					
				}else echo "<center><b><font color = 'red'>Ошибка. Пароль должен состоять из 6-символов и более</font></b></center><BR />";
			
			}else echo "<center><b><font color = 'red'>Логин заполнен неверно</font></b></center><BR />";

		}else echo "<center><font color = 'red'><b>Email имеет неверный формат</b></font></center>";

		}else echo "<center><b><font color = 'red'>Регистрация с этого IP уже производилась</font></b></center><BR />";
		
		}else echo "<center><b><font color = 'red'>Вы не подтвердили правила</font></b></center><BR />";
	
	}else echo "<center><font color = 'red'><b>Капча не пройдёна!</b></font></center>";

	}
	
?>

<form class="form" action="" style="margin: 0 auto;max-width: 450px;" method="post">
	<div class="form-group">
	<input class="form-control" id="login" placeholder="Придумайте логин" name="login" type="text" size="25" maxlength="10" value="">
	</div>

	<div class="form-group">
	<input class="form-control" id="email" placeholder="Введите email" name="email" type="text" size="25" maxlength="50" value="">
	</div>
	<div class="form-group">
	<input class="form-control" id="pwd" placeholder="Придумайте пароль" name="pass" type="password" size="25" maxlength="20">
	</div>

	<div class="form-group" style="display: none;">
	<div class="col-md-offset-3 col-md-9">
	<div class="checkbox">
                        <label><input name="rules" checked="" type="checkbox" /> <a href="/terms">Правила</a> принимаю.</label>
	</div>
	</div>
	</div>
	
	<div class="form-group">
	<center style="height: 90px;position: relative;clear:both;" class="g-recaptcha" data-sitekey="<?=$config->recaptcha;?>"></center>
	<center><input class="btn btn-block btn-lg btn-danger" name="registr" type="submit" value="Зарегистрироваться"></center>
	</div>
</form>
</div>
</div>
	<div class="col-lg-3 col-md-3"></div>
</div>
<br/><br/>
</div>
