<?PHP
$db->Query("SELECT * FROM db_stats WHERE id = '1' LIMIT 1");
$stats = $db->FetchArray();
?>

<div class="jumbotron jumbotron-fluid text-light text-center pb-5" style="margin-bottom: 0;">

<center>
	<img src="/img/birds.png" class="wow flipInX" style="max-width: 22%;opacity: 0.87;">
</center>

<h1 class="wow bounceInUp m-4"><b>Игра с выводом реальных денег</b></h1>
<a href="/signup" class="btn btn-danger wow shake">Начать играть</a>

</div>



<div class="stat text-center p-4">
<div class="row">
	<div class="col-md-3 wow fadeIn">
<div class="stat-block">
<img class="p-1" src="/img/s1.png" style="width: 64px;opacity: 0.95;" alt="1">
<h4><?=$stats["all_users"]; ?></h4>
<p>Пользователей</p>
</div>
	</div>
	<div class="col-md-3 wow fadeIn">
<div class="stat-block">
<img class="p-1" src="/img/s4.png" style="width: 64px;opacity: 0.95;" alt="3">
<h4><?=sprintf("%.2f",$stats["all_insert"]); ?></h4>
<p>Пополнено рублей</p>
</div>	</div>
	<div class="col-md-3 wow fadeIn">
<div class="stat-block">
<img class="p-1" src="/img/s3.png" style="width: 64px;opacity: 0.95;" alt="3">
<h4><?=sprintf("%.2f",$stats["all_payments"]); ?></h4>
<p>Выплачено рублей</p>
</div>
	</div>
	<div class="col-md-3 wow fadeIn">
<div class="stat-block">
<img class="p-1" src="/img/s2.png" style="width: 64px;opacity: 0.95;" alt="4">
<h4><?=intval(((time() - $config->SYSTEM_START_TIME) / 86400 ) +1); ?></h4>
<p>Работает дней</p>
</div>
	</div>
</div>
</div>

<div class="container">
    
<?PHP 
include("inc/_adsense.php"); 
?>



<div class="row">
<div class="col-lg-12" style="font-size: 120%;">
<center class="p-3">
<h3 class="card-title" style="font-weight: 600;">О НАШЕМ ПРОЕКТЕ</h3>
<hr>
<p><small><strong><?=$config->SITE_NAME;?></strong> - Это увлекательная онлайн игра с выводом реальных денег!
Покупайте птиц различного уровня и получайте стабильный доход. На выбор доступно 9-уровней птиц, каждая птица несет яйца круглосуточно, чем дороже птица тем выше заработок  и тем самым быстрее окупаемость!
Продуманная экономика, нет лимитов, баллов и кеш-поинтов, уникальная реферальная программа за каждого реферала будете получать доход каждый день, гарантия платежеспособности и массой других преимуществ. Мы делаем все, чтобы Ваше пребывание на нашем сайте было максимально комфортным!
Играя с удовольстием, Вы можете зарабатывать еще больше.</small></p>
</center>
</div>
	</div>

<br/>
<div class="row text-center" style="text-transform: uppercase;">
<div class="col-lg-4 p-3">
<h4 class="card p-2">

<center style="position: relative;"><span class="badge badge-warning" style="position: absolute;border-radius: 2em;top: -15px;left:-18px;padding-left: 9px;padding-right: 9px;"> 1 </span><img src="/img/a1.png" class="p-2" style="max-width: 128px;margin-top: -72px;"></center>
<b>Покупайте<br/>птиц</b></h4>
</div>

<div class="col-lg-4 pt-3">
<h4 class="card p-2">

<center style="position: relative;"><span class="badge badge-warning" style="position: absolute;border-radius: 2em;top: -15px;left:-18px;">2</span><img src="/img/a2.png" class="p-2" style="max-width: 128px;margin-top: -72px;"></center>
<b>Собирайте<br/>прибыль</b></h4>
</div>

<div class="col-lg-4 pt-3">
<h4 class="card p-2">
<center style="position: relative;"><span class="badge badge-warning" style="position: absolute;border-radius: 2em;top: -15px;left:-18px;">3</span><img src="/img/a3.png" class="p-2" style="max-width: 128px;margin-top: -72px;"></center>
<b>Получайте<br/>деньги</b></h4>
</div>

</div>
</div>

<div class="container title"><br/>
<div class="row about text-left">
<div class="col-md-8"><div class="about-info"><h4>Особенности проекта:</h4>
<h4 class="about-p"><span class="about-ico"><b>1</b></span> Подарок за регистрацию птица "1-го уровня".</h4>
<h4 class="about-p"><span class="about-ico"><b>2</b></span> Серфинг | Бонусы | Конкурсы и акции</h4>
<h4 class="about-p"><span class="about-ico"><b>3</b></span> Реферальная программа 7%-5%-2% на вывод!</h4>
<h4 class="about-p"><span class="about-ico"><b>4</b></span> Автоматические выплаты без ограничений!</h4>
<h4 class="about-p"><span class="about-ico"><b>5</b></span> Нет баллов и кеш-поинтв!</h4>
<h4 class="about-p"><span class="about-ico"><b>6</b></span> Мобильная версия игры </h4>
<h4 class="about-p"><span class="about-ico"><b>7</b></span> Тех-поддержка 24/7 </h4>
</div></div>
<div class="col-md-4 about-img" style="margin-left: -15px;">
</div>
</div>

</div>
<br/>


<div style="background: #f7f7f7;border-top: 8px double #fff;margin-bottom:-25px;">
<div class="container text-center"><br/>
<h3 class="card-title" style="font-weight: 600;">МАРКЕТИНГ ИГРЫ</h3>
<div class="row text-center wow shake">


<div class="col-md-4"><br/><br/>
<div class="card mt-5" style="background: #fff; border-radius: 2em;">
<div class="card-body">
<img src="/img/items/1.png" style="max-width: 95%;margin-top: -120px;">
<h4 class="text-success" style="text-transform: uppercase;"><b>Баки</b></h4>
<hr>
<i>Окупаемость: <b>29% в месяц</b><br>
Доход в месяц: <b>2.9 руб.</b></i><hr>
<b class="text-danger">Цена: 10 руб.</b>
</div>
</div>
</div><!-- lvl 1 -->

<div class="col-md-4"><br/><br/>
<div class="card mt-5" style="background: #fff; border-radius: 2em;">
<div class="card-body">
<img src="/img/items/2.png" style="max-width: 95%;margin-top: -120px;">
<h4 class="text-success" style="text-transform: uppercase;"><b>Ханс</b></h4>
<hr>
<i>Окупаемость: <b>31% в месяц</b><br>
Доход в месяц: <b>15.6 руб.</b></i><hr>
<b class="text-danger">Цена: 50 руб.</b>
</div>
</div>
</div><!-- lvl 2 -->

<div class="col-md-4"><br/><br/>
<div class="card mt-5" style="background: #fff; border-radius: 2em;">
<div class="card-body">
<img src="/img/items/3.png" style="max-width: 95%;margin-top: -120px;">
<h4 class="text-success" style="text-transform: uppercase;"><b>Марси</b></h4>
<hr>
<i>Окупаемость: <b>33% в месяц</b><br>
Доход в месяц: <b>33.1 руб.</b></i><hr>
<b class="text-danger">Цена: 100 руб.</b>
</div>
</div>
</div><!-- lvl 3 -->

<div class="col-md-4"><br/><br/>
<div class="card mt-5" style="background: #fff; border-radius: 2em;">
<div class="card-body">
<img src="/img/items/4.png" style="max-width: 95%;margin-top: -120px;">
<h4 class="text-success" style="text-transform: uppercase;"><b>Чаки</b></h4>
<hr>
<i>Окупаемость: <b>35% в месяц</b><br>
Доход в месяц: <b>86 руб.</b></i><hr>
<b class="text-danger">Цена: 250 руб.</b>
</div>
</div>
</div><!-- lvl 4 -->

<div class="col-md-4"><br/><br/>
<div class="card mt-5" style="background: #fff; border-radius: 2em;">
<div class="card-body">
<img src="/img/items/5.png" style="max-width: 95%;margin-top: -120px;">
<h4 class="text-success" style="text-transform: uppercase;"><b>Тутор</b></h4>
<hr>
<i>Окупаемость: <b>37% в месяц</b><br>
Доход в месяц: <b>184 руб.</b></i><hr>
<b class="text-danger">Цена: 500 руб.</b>
</div>
</div>
</div><!-- lvl 5 -->


<div class="col-md-4"><br/><br/>
<div class="card mt-5" style="background: #fff; border-radius: 2em;">
<div class="card-body">
<img src="/img/items/6.png" style="max-width: 95%;margin-top: -120px;">
<h4 class="text-success" style="text-transform: uppercase;"><b>Келли</b></h4>
<hr>
<i>Окупаемость: <b>39% в месяц</b><br>
Доход в месяц: <b>389 руб.</b></i><hr>
<b class="text-danger">Цена: 1000 руб.</b>
</div>
</div>
</div><!-- lvl 6 -->


<div class="col-md-4"><br/><br/>
<div class="card mt-5" style="background: #fff; border-radius: 2em;">
<div class="card-body">
<img src="/img/items/7.png" style="max-width: 95%;margin-top: -120px;">
<h4 class="text-success" style="text-transform: uppercase;"><b>Дан</b></h4>
<hr>
<i>Окупаемость: <b>41% в месяц</b><br>
Доход в месяц: <b>1224 руб.</b></i><hr>
<b class="text-danger">Цена: 3000 руб.</b>
</div>
</div>
</div><!-- lvl 7 -->


<div class="col-md-4"><br/><br/>
<div class="card mt-5" style="background: #fff; border-radius: 2em;">
<div class="card-body">
<img src="/img/items/8.png" style="max-width: 95%;margin-top: -120px;">
<h4 class="text-success" style="text-transform: uppercase;"><b>Рудди</b></h4>
<hr>
<i>Окупаемость: <b>43% в месяц</b><br>
Доход в месяц: <b>2592 руб.</b></i><hr>
<b class="text-danger">Цена: 6000 руб.</b>
</div>
</div>
</div><!-- lvl 8 -->


<div class="col-md-4"><br/><br/>
<div class="card mt-5" style="background: #fff; border-radius: 2em;">
<div class="card-body">
<img src="/img/items/9.png" style="max-width: 95%;margin-top: -120px;">
<h4 class="text-success" style="text-transform: uppercase;"><b>Ричи</b></h4>
<hr>
<i>Окупаемость: <b>45% в месяц</b><br>
Доход в месяц: <b>5364 руб.</b></i><hr>
<b class="text-danger">Цена: 12000 руб.</b>
</div>
</div>
</div><!-- lvl 9 -->




</div>
</div>

<?PHP 
include("inc/_adsense_b.php"); 
?>

<center><hr><img src="/img/payments.png" style="max-width: 70%;"></center>

<br/>
</div>



