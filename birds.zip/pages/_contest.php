<?PHP
$_OPTIMIZATION["title"] = "Конкурсы";
$_OPTIMIZATION["description"] = "Конкурс рефералов и конкурс инвесторов";
$_OPTIMIZATION["keywords"] = "Конкурс фф, конкурс рефералов, конкурс инвесторов";
?>

<div class="title">
       <h3>КОНКУРСЫ САЙТА</h3>
 <p>
За каждое действие вами или вашим рефералом в момент проведения конкурса начисляются <br/>баллы, <b>1 RUB = 1 балл.</b> Чем больше у Вас баллов, тем больше шанс победить в конкурсе. 
</p> 
    </div>
<?PHP 
include("inc/_adsense.php"); 
?>
<div class="container"><br/>
<div class="row stats">
	<div class="col-md-6">
	<div class="card">
	<div class="card-body">
<?PHP

# Список конкурсов
if(isset($_GET["list2"])){


	# Список пользователей
	$db->Query("SELECT * FROM db_invcompetition WHERE status > 0");
	if($db->NumRows() > 0){
	
	?>
	
	
	<?PHP
		while($data = $db->FetchArray()){
		
		?>

123
		<?PHP
		}

	}else echo "<center><b><font color = 'red'>Нет завершенных конкурсов</font></b></center><BR />";


?>

<?PHP

return;
}


$db->Query("SELECT * FROM db_invcompetition WHERE status = 0 LIMIT 1");
if($db->NumRows() == 1){
$comp = $db->FetchArray();	
	?>
<center>
<b style="font-family: 'Russo One', sans-serif;font-weight: normal;font-size: 22px;text-transform: uppercase;">Конкурс инвесторов <b style="color: #f73454;">№<?=$comp["id"]; ?></b></b><br/>
<b style="font-family: 'Russo One', sans-serif;font-weight: normal;font-size: 18px;text-transform: uppercase;" class="text-danger">Завершение конкурса: <?=date("d/m/Y в H:i", $comp["date_end"]); ?></b></center><hr>
<center class="card-body">
<img src="/img/prize1.png" style="max-width: 90%;"></center>

<div style="font-family: 'Russo One', sans-serif;font-weight: normal;font-size: 22px;margin-top: -55px;text-transform: uppercase;color: #8c0036;text-align: center;">Фонд: <?=$comp["1m"]+$comp["2m"]+$comp["3m"]+$comp["4m"]+$comp["5m"]; ?> Руб.</div>
<hr style="margin-bottom: 10px;">
<p style="text-align:center;"><small>
В конкурсе участвуют все пользователи проекта, выигрывает <br/>всего 5 участников, которые за время проведения конкурса пополнили свой баланс на наибольшую сумму.</small></p>

</div>
<?PHP
	
	# Список пользователей
	$db->Query("SELECT * FROM db_invcompetition_users WHERE points > '0' ORDER BY points DESC LIMIT 10");
	if($db->NumRows() > 0){
	
	?>
<table width="99%" class="table table-bordered" style="margin: 0;" align="center">
  <tr bgcolor="#efefef">
    <td align="center" colspan="4"><b>Таблица 10 лидеров</b></td>
  </tr>
  <tr bgcolor="#efefef">
    <td align="center" width="75" class="m-tb">Позиция</td>
    <td align="center" class="m-tb">Пользователь</td>
    <td align="center" class="m-tb">Баллов</td>
	<td align="center" class="m-tb">Приз</td>
  </tr>
	<?PHP
		$position = 1;
		while($data = $db->FetchArray()){
		
		?>
			<tr class="htt" >
				<td align="center" width="75"><?=$position; ?></td>
				<td align="center"><?=$data["user"]; ?></td>
				<td align="center"><?=sprintf("%.0f",$data["points"]); ?></td>
				<td align="center"><?=(intval($comp["{$position}m"]) > 0) ? $comp["{$position}m"]." Руб." : "-" ?></td>
		 	</tr>
		<?PHP
		$position++;
		}
	
	?>
</table>

	<?PHP
	
	}else echo "<center><b><font color = '#d20234'>Нет участников в конкурсе</font></b></center>";

}else echo "<center><br/><br/><br/><b><font color = '#d20234'>В данный момент конкурс инвесторов не проводится</font></b><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/></center>";

?>
	</div>
	</div>

	<div class="col-md-6">
	<div class="card">
	<div class="card-body">

<?PHP

# Список конкурсов
if(isset($_GET["list"])){


	# Список пользователей
	$db->Query("SELECT * FROM db_competition WHERE status > 0");
	if($db->NumRows() > 0){
	
	?>

	
	<?PHP
		while($data = $db->FetchArray()){
		
		?>

123


		<?PHP
		}

	}else echo "<div class='alert alert-danger'><b>Нет завершенных конкурсов</b></div>";


?>



<?PHP

return;
}


$db->Query("SELECT * FROM db_competition WHERE status = 0 LIMIT 1");
if($db->NumRows() == 1){
$comp = $db->FetchArray();	
	?>
<center>
<b style="font-family: 'Russo One', sans-serif;font-weight: normal;font-size: 22px;text-transform: uppercase;">Конкурс рефералов <b style="color: #f73454;">№<?=$comp["id"]; ?></b></b><br/>
<b style="font-family: 'Russo One', sans-serif;font-weight: normal;font-size: 18px;text-transform: uppercase;" class="text-primary">Завершение конкурса: <?=date("d/m/Y в H:i", $comp["date_end"]); ?></b></center><hr>
<center class="card-body">
<img src="/img/prize2.png" style="max-width: 90%;"></center>

<div style="font-family: 'Russo One', sans-serif;font-weight: normal;font-size: 22px;margin-top: -55px;text-transform: uppercase;color: #1a3884;text-align: center;">ФОНД: <?=$comp["1m"]+$comp["2m"]+$comp["3m"]+$comp["4m"]+$comp["5m"]; ?> Руб.</div>
<hr style="margin-bottom: 10px;">
<p style="text-align:center;"><small>
В конкурсе выигрывает тот у кого больше активные рефералы, которые пополнили свой баланс за время проведения конкурса на наибольшую сумму. Всего призовых мест 5.</small>
</p>
</div>
	<?PHP
	
	# Список пользователей
	$db->Query("SELECT * FROM db_competition_users ORDER BY points DESC LIMIT 10");
	if($db->NumRows() > 0){
	
	?>
<table width="99%" class="table table-bordered" style="margin: 0;" align="center">
  <tr bgcolor="#efefef">
    <td align="center" colspan="4"><b>Таблица 10 лидеров</b></td>
  </tr>
  <tr bgcolor="#efefef">
    <td align="center" width="75" class="m-tb">Позиция</td>
    <td align="center" class="m-tb">Пользователь</td>
    <td align="center" class="m-tb">Баллов</td>
	<td align="center" class="m-tb">Приз</td>
  </tr>
	<?PHP
		$position = 1;
		while($data = $db->FetchArray()){
		
		?>
			<tr class="htt" >
				<td align="center" width="75"><?=$position; ?></td>
				<td align="center"><?=$data["user"]; ?></td>
				<td align="center"><?=sprintf("%.0f",$data["points"]); ?></td>
				<td align="center"><?=(intval($comp["{$position}m"]) > 0) ? $comp["{$position}m"]." Руб." : "-" ?></td>
		 	</tr>
		<?PHP
		$position++;
		}
	
	?>
</table>
	<?PHP
	
	}else echo "<center><b><font color = '#d20234'>Нет участников в конкурсе</font></b></center>";

}else echo "<center><br/><br/><br/><b><font color = '#d20234'>В данный момент конкурс рефералов не проводится</font></b><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/></center>";

?>
	</div>
	</div>
    </div>
</div>
