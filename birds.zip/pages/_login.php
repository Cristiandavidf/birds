<!-- Get Started -->

<div class="container">
<div class="row">
	<div class="col-lg-3 col-md-3">


</div>
	<div class="col-lg-6 col-md-6"><br/>
	<div class="card-body m-3"><div class="title">
        <h3>Вход в игру</h3><br/><br/>
    </div>
<?PHP

$_OPTIMIZATION["title"] = "Вход в аккаунт";
$_OPTIMIZATION["description"] = "Авторизация пользователя в системе";
$_OPTIMIZATION["keywords"] = "Авторизация нового участника в системе";

if(isset($_SESSION["user_id"])){ Header("Location: /profile"); return; }

# Определение платежей по акции 'Накопительный банк'
$c_date = date("Ymd",time());
$c_date_begin = strtotime($c_date." 00:00:00");
$c_date_end = strtotime($c_date." 23:59:59");
$y_date = date("Ymd",time()-24*60*60);
$y_date_begin = strtotime($y_date." 00:00:00");
$y_date_end = strtotime($y_date." 23:59:59");


$db->Query("SELECT * FROM db_back WHERE date_add >='".$c_date_begin."' AND  date_add <='".$c_date_end."' ORDER BY id DESC LIMIT 1");
if($db->NumRows() == 0) {


$db->Query("SELECT sum(serebro) FROM db_insert_money WHERE date_add >='".$y_date_begin."' AND  date_add <='".$y_date_end."' AND money >= '1'" );
if($db->NumRows() == 0) $sum_c = 0;
else $sum_c = $db->FetchRow();
	
	
$db->Query("SELECT date_add as date_add, user as user, user_id as user_id, SUM(serebro) as sserebro  FROM db_insert_money WHERE date_add >='".$y_date_begin."' AND  date_add <='".$y_date_end."' GROUP BY user ORDER by sserebro DESC LIMIT 1");
$firstuser=$db->FetchArray();
$firstpercent=(1.5/100)*$sum_c;
$db->Query("UPDATE db_users_b SET money_b = money_b + '".$firstpercent."' WHERE id = '".$firstuser['user_id']."'");	


$db->Query("SELECT date_add as date_add, user as user, user_id as user_id, SUM(serebro) as sserebro  FROM db_insert_money WHERE date_add >='".$y_date_begin."' AND  date_add <='".$y_date_end."' GROUP BY user ORDER by sserebro DESC LIMIT 1,2");
$seconduser=$db->FetchArray();
$secondpercent=(1.0/100)*$sum_c;
$db->Query("UPDATE db_users_b SET money_b = money_b + '".$secondpercent."' WHERE id = '".$seconduser['user_id']."'");	


$db->Query("SELECT date_add as date_add, user as user, user_id as user_id, SUM(serebro) as sserebro  FROM db_insert_money WHERE date_add >='".$y_date_begin."' AND  date_add <='".$y_date_end."' GROUP BY user ORDER by sserebro DESC LIMIT 2,3");
$thirduser=$db->FetchArray();
$thirdpercent=(0.5/100)*$sum_c;
$db->Query("UPDATE db_users_b SET money_b = money_b + '".$thirdpercent."' WHERE id = '".$thirduser['user_id']."'");	

$db->Query("INSERT INTO db_back (`id`,`user_id`,`bank`,`sum`,`date_add`) VALUES(NULL,'".$firstuser['user_id']."','".$sum_c."','".$firstpercent."','".time()."'),(NULL,'".$seconduser['user_id']."','".$sum_c."','".$secondpercent."','".time()."'), (NULL,'".$thirduser['user_id']."','".$sum_c."','".$thirdpercent."','".time()."')");

}

	if(isset($_POST["log_email"])){
	
	if (!empty($_POST['g-recaptcha-response'])) {


	$lmail = $func->IsMail($_POST["log_email"]);
	$login = htmlspecialchars($func->IsLogin($_POST["log_email"])); 
	
		if($lmail or $login !== false){

		
			$db->Query("SELECT id, user, pass, referer_id, banned FROM db_users_a WHERE email = '$lmail' OR user = '$login'");
			if($db->NumRows() == 1){
			
			$log_data = $db->FetchArray();
			
				if(strtolower($log_data["pass"]) == strtolower($_POST["pass"])){
				
					if($log_data["banned"] == 0){
						
						# Считаем рефералов
						$db->Query("SELECT COUNT(*) FROM db_users_a WHERE referer_id = '".$log_data["id"]."'");
						$refs = $db->FetchRow();
						
						$db->Query("UPDATE db_users_a SET referals = '$refs', date_login = '".time()."', ip = INET_ATON('".$func->UserIP."') WHERE id = '".$log_data["id"]."'");
						
						$_SESSION["user_id"] = $log_data["id"];
						$_SESSION["user"] = $log_data["user"];
						$_SESSION["referer_id"] = $log_data["referer_id"];
						Header("Location: /profile");
						
					}else echo "<center><div class='alert-warning'>Аккаунт заблокирован</div></center><BR />";
				
				}else echo "<center><div class='alert-warning'>Неверные данные</div></center><BR />";
			
			}else echo "<center><div class='alert alert-danger'>E-mail или Логин не зарегистрирован</div></center><BR />";
			
		}else echo "<center><div class='alert alert-danger'>Недопустимый формат E-mail</div></center><BR />";
	
	}else echo "<center><div class='alert alert-danger'>Капча не пройдёна!</div></center><br/>";

}

?>
<form action="" style="margin: 0 auto;max-width: 450px;" method="post">
	<div class="form-group login-form">
		<input style="" name="log_email" placeholder="E-mail или логин" type="text" maxlength="35" class="form-control">
		<input style="margin-top: 5px;" name="pass" placeholder="Пароль" type="password" maxlength="35" class="form-control">
	 <center style="height: 90px;position: relative;clear:both;" class="g-recaptcha" data-sitekey="<?=$config->recaptcha;?>"></center>
	<center><input type="submit" value="Войти" class="btn btn-success btn-lg" style="margin: 5px 0; width: 100%;"></center>
	</div>
</form>
</div><center><p>Забыли пароль? <a class="text-info" href="/recovery">Восстановить тут</a>.</p></center>

</div>
		
<div class="col-lg-3 col-md-3"></div>
</div>
</div>
<br/><br/><br/>