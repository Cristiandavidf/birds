<?PHP
$_OPTIMIZATION["title"] = "Статистика";
$_OPTIMIZATION["description"] = "Статистика выплаты, регистрации, пополнения, лидеры.";
$_OPTIMIZATION["keywords"] = "Статистика, последняя статистика игры с выводом денег платящие игры экономические фермы";
?>
<?PHP
# Статистика сайта
$db->Query("SELECT * FROM db_stats WHERE id = '1' LIMIT 1");
$stats = $db->FetchArray();

# Статистика регистраций за 24 часа
$db->Query("SELECT COUNT(*) FROM db_stats_r24");
$stats_new = $db->FetchArray();
?>
<style>
.stat-block {border-radius: 2em;padding: 10px 0;}
.stat-block:hover {background: rgba(175,160,155,0.1);border-radius: 1em;padding: 10px 0;}
.stat-block p{padding: 0 6px;}
.stat-block h4{display: inline-block;}
</style>
<div class="stat pb-3 pt-3 text-center">

        <div class="container">
            <div class="row clearfix wow bounceInUp">
<div class="col-md-4">
<div class="stat-block mb-2">
<img src="/img/s1.png" style="width: 64px;opacity: 0.9;" alt="1"><br/>
<h4><?=$stats["all_users"]; ?></h4>
<p>Пользователей</p>
</div>
</div>

<div class="col-md-4">
<div class="stat-block mb-2">
<img src="/img/s5.png" style="width: 64px;opacity: 0.9;" alt="2"><br/>
<h4><? echo $stats_new[0]; ?></h4>
<p>Новых за 24 часа</p>
</div>
</div>

<div class="col-md-4">
<div class="stat-block mb-2">
<img src="/img/s2.png" style="width: 64px;opacity: 0.9;" alt="3"><br/>
<h4><?=intval(((time() - $config->SYSTEM_START_TIME) / 86400 ) +1); ?></h4>
<p>Проекту дней</p>
</div>
</div>

<div class="col-md-4">
<div class="stat-block mb-2">
<img src="/img/s3.png" style="width: 64px;opacity: 0.9;" alt="4"><br/>
<h4><?=sprintf("%.2f",$stats["all_insert"]); ?></h4>
<p>Пополнено рублей</p>
</div>
</div>

<div class="col-md-4">
<div class="stat-block mb-2">
<img src="/img/s6.png" style="width: 64px;opacity: 0.9;" alt="5"><br/>
<h4><?=sprintf("%.2f",$stats["all_insert"]-$stats["all_payments"]); ?></h4>
<p>Резерв игры</p>
</div>
</div>

<div class="col-md-4">
<div class="stat-block mb-2">
<img src="/img/s4.png" style="width: 64px;opacity: 0.9;" alt="6"><br/>
<h4><?=sprintf("%.2f",$stats["all_payments"]); ?></h4>
<p>Выплачено рублей</p>
</div>
</div>

		</div>
	</div>
</div>

<!-- Tab panes -->
<div class="container">

<br/>
	<div class="row stats">
	<div class="col-md-6">
	<div class="alert"><h5>Крайние 10 пополнений</h5>
		<table width="100%" class="table table-bordered">
			<thead><th>Логин</th><th>Сумма</th><th>Дата</th></thead>
		<tbody>
<?PHP	
$db->Query("SELECT * FROM db_insert_money ORDER BY date_add DESC LIMIT 10");
	while($data2 = $db->FetchArray()){
?>
	<tr>
		<td><?=$data2["user"]; ?></td>
		<td><?=sprintf("%.2f",$data2["money"]); ?> руб.</td>
		<td><?=date("d/m/Y H:i",$data2["date_add"]); ?></td>
	</tr>
	<?PHP
	}
?>
			</tbody>
		</table></div>
	</div><!-- Inserts -->


	<div class="col-md-6">
	<div class="alert"><h5>Крайние 10 выплат</h5>
		<table width="100%" class="table table-bordered">
			<thead><th>Логин</th><th>Сумма</th><th>Дата</th></thead>
			<tbody>
<?PHP

$db->Query("SELECT * FROM db_payment ORDER BY date_add DESC LIMIT 10");
	while($data1 = $db->FetchArray()){
	
		
	?>
	<tr>
		<td><?=$data1["user"]; ?></td>
		<td><?=sprintf("%.2f",$data1["sum"]); ?>  руб.</td>
		<td><?=date("d/m/Y H:i",$data1["date_add"]); ?></td>
	</tr>
	<?PHP
	}
?>
			</tbody>
		</table></div>
	</div><!-- Payments -->



	<div class="col-md-6">
	<div class="alert"><h5>Крайние 10 регистраций</h5>
		<table width="100%" class="table table-bordered">
			<thead><th>Логин</th><th>Пригласил</th><th>Регистрация</th></thead>
			<tbody>

	<?PHP
$db->Query("SELECT * FROM db_users_a ORDER BY date_reg DESC LIMIT 10");
	while($data = $db->FetchArray()){
?>
<tr align="center">
		<td><?=$data["user"]; ?></td>
		<td><?=$data["referer"]; ?></td>
		<td><?=date("d/m/Y H:i",$data["date_reg"]); ?></td>
	</tr>
	<?PHP
	}
?>
			</tbody>
		</table></div>
	</div><!-- Registration -->

	<div class="col-md-6">
	<div class="alert"><h5>Лидеры по рефералам</h5>
		<table width="100%" class="table table-bordered">
			<thead><th>Логин</th><th>Рефералов</th><th>Регистрация</th></thead>
			<tbody>

<?php
	$db->Query("SELECT * FROM `db_users_a` ORDER BY referals DESC LIMIT 10 ");
	while($data = $db->FetchArray()){
	?>
<tr align="center">
		<td><?=$data["user"]; ?></td>
		<td><?=$data["referals"]; ?> чел.</td>
		<td><?=date("d.m.Y H:i",$data["date_reg"]); ?></td>
	</tr>
	<?PHP
	}
?>
			</tbody>
		</table></div>
	</div><!-- Referals -->




	<div class="col-md-6">
	<div class="alert"><h5>Лидеры по пополнениям</h5>
		<table width="100%" class="table table-bordered">
			<thead><th>Логин</th><th>Сумма</th><th>Регистрация</th></thead>
			<tbody>

<?php
	$db->Query("SELECT * FROM `db_users_b`,`db_users_a` WHERE db_users_b.id = db_users_a.id ORDER BY db_users_b.insert_sum DESC LIMIT 10 ");
	while($data = $db->FetchArray()){
	?>
<tr align="center">
		<td><?=$data["user"]; ?></td>
		<td><?=sprintf("%.2f",$data["insert_sum"]); ?> руб.</td>
		<td><?=date("d.m.Y H:i",$data["date_reg"]); ?></td>
	</tr>
	<?PHP
	}
?>
			</tbody>
		</table></div>
	</div><!-- top inv -->

	<div class="col-md-6">
	<div class="alert"><h5>Лидеры по заработку</h5>
		<table width="100%" class="table table-bordered">
			<thead><th>Логин</th><th>Сумма</th><th>Регистрация</th></thead>
			<tbody>

<?php
	$db->Query("SELECT * FROM `db_users_b`,`db_users_a` WHERE db_users_b.id = db_users_a.id ORDER BY db_users_b.payment_sum DESC LIMIT 10 ");
	while($data = $db->FetchArray()){
	?>
<tr align="center">
		<td><?=$data["user"]; ?></td>
		<td><?=sprintf("%.2f",$data["payment_sum"]); ?> руб.</td>
		<td><?=date("d.m.Y H:i",$data["date_reg"]); ?></td>
	</tr>
	<?PHP
	}
?>
			</tbody>
		</table></div>
	</div><!-- top payouts -->
</div>

</div>