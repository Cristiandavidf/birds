<?PHP
error_reporting(E_ALL ^ E_NOTICE);
$_OPTIMIZATION["title"] = "Отзывы о проекте";
$_OPTIMIZATION["description"] = "Список последних отзывов";
$_OPTIMIZATION["keywords"] = "Отзывы о проекте";
?>
<div class="container">
<div class="title">
	<h3>Отзывы о проекте</h3>
</div>
<?PHP 
include("inc/_adsense.php"); 
?>
<center>
<p>Читайте отзывы или оставьте свой отзыв о нашем проекте! <br/>
Чтобы оставить отзыв сумма пополнений на вашем балансе должна более 10 рублей. <br/>
Бонусом за любой отзыв является случайное <b>вознаграждение от 100 до 200 монет</b> для покупок. <br/>
Если в отзыве есть скриншот выплаты начисляется <b>вознаграждение от 200 до 300 монет</b> для покупок. <br/>Максимум можно оставить только 1 отзыв.
</p></center>

<div class="p-3">

<?php
$usid = $_SESSION["user_id"];
$usname = $_SESSION["user"];
$db->Query("SELECT * FROM db_users_b WHERE id = '$usid' LIMIT 1");
	$user_data = $db->FetchArray();
	$user_name=$user_data["user"];
	$user_insert=intval($user_data["insert_sum"]);
	
$db->Query("SELECT * FROM db_otziv WHERE user_id = '$usid'");
$col = $db->NumRows();

//Add otziv
if(isset($_POST['asd'])) {

$text = $db->RealEscape(htmlspecialchars($_POST['content'], ENT_QUOTES, 'windows-1251'));//Фильтрация
$neg = intval($_POST['neg']);//Фильтрация
$img = $db->RealEscape(htmlspecialchars($_POST['img'], ENT_QUOTES, 'windows-1251'));//Фильтрация

$date = time();
	if($col >= 1) {
		echo '<font color="red"><center>Вы уже добавляли отзыв! Спасибо!</center></font>';
	} elseif (!isset($_SESSION["user"])) {
		echo '<font color="red"><center>Для добавления отзыва необходимо пройти авторизацию!</center></font>';
	} elseif(strlen($text) < 20 or $text == "") {
		echo '<font color="red"><center>Минимальная длинна отзыва 20 символов!</center></font>';
	} else {
$as = $db->Query("INSERT INTO db_otziv (login, user_id, date, text, neg, img) VALUES ('$usname', '$usid', '$date', '$text', '$neg', '$img')"); //Добавляем отзыв
			if (strlen($text) > 100 and $img == "") {
				$present=rand(100,200);
			}
			if ($img != "" and strlen($text) > 100) {
				$present=rand(200,500);
			}


		if(strlen($text) > 100) {
			//$present=rand(100,300);
			$db->Query("UPDATE db_users_b SET money_b = money_b + $present WHERE id = '$usid'"); // + Кредиты за отзыв
		}
	}
		if($as) echo "<font color=\"green\"><center>Ваш отзыв успешно добавлен и вам начисленно $present монет!</center></font>";
}

//Delete Otziv
if(isset($_POST["delotz"]) AND isset($_POST["del_id"]))
{
	$id=intval($_POST["del_id"]);
	if(isset($_SESSION["admin"]))
	{
		$db->Query("DELETE FROM db_otziv WHERE user_id = {$id};");
		echo('<tr><td align="center" colspan="6">Отзыв успешно удалён!</td></tr>');
	}
}




$db->Query("SELECT * FROM db_otziv");
if($db->NumRows() > 0) {

//вывод отзывов в цикле)

$num = 10;
$page = $_GET['page'];
$result00 = $db->Query("SELECT COUNT(*) FROM db_otziv");
$temp = $db->FetchArray($result00);
$posts = $temp[0];
$total = (($posts - 1) / $num) + 1;
$total =  intval($total);
$page = intval($page);
if(empty($page) or $page < 0) $page = 1;
if($page > $total) $page = $total;
$start = $page * $num - $num;		
		


$db->Query("SELECT * FROM db_otziv ORDER BY id DESC LIMIT $start, $num");

while($otziv = $db->FetchArray()) {

$id_otziv = $otziv['id'];

$by_user_id = $otziv['user_id'];

if(isset($_SESSION["admin"]))
		{
			$admlink="<form action=\"\" method=\"post\">
			<input type=\"hidden\" name=\"del_id\" value=\"$by_user_id\">
			<input type=\"submit\" name=\"delotz\" value=\"Удалить\" />
			</form>";
		}
$date = date("d.m.Y H:i",intval($otziv["date"]));
echo '<div class="card  card-body border-1 border-light"><h5 class="card-title text-dark">Отзыв от пользователя: <b>'.$otziv['login'].'</b> <span class="pull-right"> '.$date.' '.$admlink.'</span></h5><div>'.$otziv['text'].'<br/>';
if ($otziv['img'] != '') {
echo '<center><hr>Пользователь прикрепил скриншот: <a href="'.$otziv['img'].'" target="_blank">посмотреть</a></center>';
}
echo '</div></div>';
}


// Проверяем нужны ли стрелки назад
if ($page != 1) $pervpage = '<a href="/otziv/1">Первая</a> | <a href='. ($page - 1) .'>Предыдущая</a> | ';
// Проверяем нужны ли стрелки вперед
if ($page != $total) $nextpage = ' | <a href="/otziv/'. ($page + 1) .'">Следующая</a> | <a href="/otziv/' .$total. '">Последняя</a>';

// Находим две ближайшие станицы с обоих краев, если они есть
if($page - 5 > 0) $page5left = ' <a href="/otziv/'. ($page - 5) .'">'. ($page - 5) .'</a> | ';
if($page - 4 > 0) $page4left = ' <a href="/otziv/'. ($page - 4) .'">'. ($page - 4) .'</a> | ';
if($page - 3 > 0) $page3left = ' <a href="/otziv/'. ($page - 3) .'">'. ($page - 3) .'</a> | ';
if($page - 2 > 0) $page2left = ' <a href="/otziv/'. ($page - 2) .'">'. ($page - 2) .'</a> | ';
if($page - 1 > 0) $page1left = '<a href="/otziv/'. ($page - 1) .'">'. ($page - 1) .'</a> | ';

if($page + 5 <= $total) $page5right = ' | <a href="/otziv/'. ($page + 5) .'">'. ($page + 5) .'</a>';
if($page + 4 <= $total) $page4right = ' | <a href="/otziv/'. ($page + 4) .'">'. ($page + 4) .'</a>';
if($page + 3 <= $total) $page3right = ' | <a href="/otziv/'. ($page + 3) .'">'. ($page + 3) .'</a>';
if($page + 2 <= $total) $page2right = ' | <a href="/otziv/'. ($page + 2) .'">'. ($page + 2) .'</a>';
if($page + 1 <= $total) $page1right = ' | <a href="/otziv/'. ($page + 1) .'">'. ($page + 1) .'</a>';

// Вывод меню если страниц больше одной

if ($total > 1)
{
Error_Reporting(E_ALL & ~E_NOTICE);
echo "<div class=\"pstrnav\">";
echo $pervpage.$page5left.$page4left.$page3left.$page2left.$page1left.'<b>'.$page.'</b>'.$page1right.$page2right.$page3right.$page4right.$page5right.$nextpage;
echo "</div>";
}
} else {
echo '<tr><td align="center" colspan="6"><font color="green"><center>Отзывов еще не было!</center></font></td></tr>';
}
?>
<?php
if(!isset($_SESSION["user"])) {
	echo '<tr><td align="center" colspan="6"><font color="red"><center>Чтобы оставить свой отзыв, необходимо войти в систему!</center></font></td></tr>';
} elseif ($user_insert < 10 or $col >= 1){
echo('<tr><td align="center" colspan="6"><font color="red"><center>Вы уже оставляли отзыв, либо сумма пополнений игрового счёта меньше 10 рублей!</center></font></td></tr>');
} else {


?>
<form method="post" action="" class="card card-body" style="max-width: 900px;"><h4>Оставьте свой отзыв! Для нас это очень важно!</h4><hr>
	<div class="form-group">Ваш отзыв:
	<textarea class="form-control" name="content" rows="3" style="width:96%;"></textarea>
	</div>
	<div class="form-group">
  	<input type="hidden" name="asd" >
	Скрин выплаты(не обязательно): <input class="form-control" type="text" name="img" value="" style="width:96%;">
  	<input class="btn btn-success btn-lg" type="submit" value="Написать отзыв">
	</div>
	</form>
	<? } ?>
</div>
</div>

<hr class="my-2">

