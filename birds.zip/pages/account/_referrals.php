<?PHP
$_OPTIMIZATION["title"] = "Партнерская программа";
$user_id = $_SESSION["user_id"];
$uname = $_SESSION["user"];
$db->Query("SELECT COUNT(*) FROM db_users_a WHERE referer_id = '$user_id'");
$refs = $db->FetchRow(); // Считаем рефералов 1 уровня
$db->Query("SELECT COUNT(*) FROM db_users_a WHERE referer_id2 = '$user_id'");
$refs2 = $db->FetchRow(); // Считаем рефералов 2 уровня

$db->Query("SELECT * FROM db_users_a, db_users_b WHERE db_users_a.id = db_users_b.id AND db_users_a.id = '$user_id'");
$prof_data = $db->FetchArray();

# Статистика дохода от рефералов2 уровня
$db->Query("SELECT doxod2 FROM db_users_a WHERE referer_id2 = '$user_id'");
$doxod_refs2 = $db->FetchArray();
$doxod_refs2['doxod2'];

?>
<?PHP 
include("inc/_adsense.php"); 
?>
<center style="font-size: 120%;">
Приглашайте своих друзей и получайте доход от их пополнений на счет для вывода!<br/>
<span>А также за каждого реферала птица подарок "ТУКИ". В час приносит +6 яиц</span><br/>
<span class="text-info">+7% за 1-й уровень <b>|</b> +5% за 2-й уровень  <b>|</b> +2% за 3-й уровень.</span>
</center>
<br/><br/>

<div class="row" style="margin: -2px -15px;">

<div class="col-lg-6 text-center">
<div class="card card-body">
<center style="margin-top: -45px;">
<div class="btn btn-lg rounded bg-success text-white p-2"><span class="fa fa-rub" style="font-size: 130%;"></span></div>
</center>
<h5 class="text-success" style="font-weight: 500;"><b><?=sprintf("%.2f",$prof_data["from_referals"]/100); ?> РУБ.</b></h5>
<small>Реферальных доход</small>
</div>
</div>

<div class="col-lg-6 text-center">
<div class="card card-body">
<center style="margin-top: -45px;">
<div class="btn btn-lg rounded bg-warning text-white p-2"><span class="fa fa-users" style="font-size: 130%;"></span></div>
</center>
<h5 class="text-warning" style="font-weight: 500;"><b><?=$refs; ?> ЧЕЛ.</b></h5>
<small>Ваши рефералы</small>
</div>
</div>


</div>


<div class="row">

<div class="col-xl-2"></div>
<div class="col-xl-8">

	<h5>Реферальная ссылка: </h5>
<div class="input-group">

	<input type="text" onclick="this.select()" class="form-control" style="margin:0;font-size: 22px;" value="https://<?=$_SERVER['HTTP_HOST']; ?>/?i=<?=$_SESSION["user_id"]; ?>"> 
	<div class="input-group-prepend mt-0">
	<button type="button" class="btn btn-success btn-lg mt-0" style="color: #fff;" data-toggle="collapse" data-target="#demo">
GIF Баннеры
</button>
	</div></div>
</div>

</div><br/>

<div id="demo" class="collapse">

<div class="row">
	<div class="col-md-8">
<div class="card">
	<div class="card-body"><h5 class="card-title">Размер баннера: <b>468х60</b></h5>
<img src="/img/promo/468.gif">
<div class="pt-2"><input style="margin: 2px 0 0 0;" type="text" onclick="this.select()" class="form-control" value="https://<?=$_SERVER['HTTP_HOST']; ?>/img/promo/468.gif"></div>
</div></div>
<br/>

<div class="card">

	<div class="card-body"><h5 class="card-title">Размер баннера: <b>728х90</b></h5>
<img src="/img/promo/728.gif" style="width: 100%;">
<div class="pt-2"><input style="margin: 2px 0 0 0;" type="text" onclick="this.select()" class="form-control" value="https://<?=$_SERVER['HTTP_HOST']; ?>/img/promo/728.gif"></div>
</div>
<br/>
	</div>
	</div>

	<div class="col-md-4">
<div class="card">

	<div class="card-body"><h5 class="card-title">Размер баннера: <b>200х300</b></h5>
<img src="/img/promo/200.gif">
<div class="pt-2"><input style="margin: 2px 0 0 0;" type="text" onclick="this.select()" class="form-control" value="https://<?=$_SERVER['HTTP_HOST']; ?>/img/promo/200.gif"></div>
</div>
	</div>

	</div>
</div>
</div>



<!-- Tab panes -->
<div class="stats">
<h5>Список ваших рефералов</h5>
	<table cellpadding="5" cellspacing="0" align="center" width="100%" class="table table-striped">
<thead bgcolor="#efefef">
	<th style="padding: 5px;text-align: center;">Логин</th>
	<th style="padding: 5px;text-align: center;">Доход</th>
	<th style="padding: 5px;text-align: center;">Рефералов</th>
	<th style="padding: 5px;text-align: center;">Источник</th>
	<th style="padding: 5px;text-align: center;">Дата регистрации</th>
</thead>
<?PHP
  $all_money = 0;
  $db->Query("SELECT db_users_a.user, db_users_a.date_reg, db_users_a.referals, db_users_a.email, db_users_a.refsite, db_users_b.to_referer FROM db_users_a, db_users_b 
  WHERE db_users_a.id = db_users_b.id AND db_users_a.referer_id = '$user_id' ORDER BY to_referer DESC limit 500");
  
	if($db->NumRows() > 0){
  
  		while($ref = $db->FetchArray()){
		
		?>
<tr align="center">
		<td><b><?=$ref["user"]; ?></b></td>
		<td><?=sprintf("%.2f",$ref["to_referer"]/100); ?> руб.</td>
		<td><?=$ref["referals"]; ?></td>
		<td><?=$ref["refsite"]; ?></td>
		<td><?=date("d.m.Y H:i",$ref["date_reg"]); ?></td>
	</tr>
		<?PHP
		$all_money += $ref["to_referer"];
		}
  
	}else echo '<tr><td align="center" colspan="5">У вас нет рефералов 1-го уровня</td></tr>'
  ?>
</table>
</div>

<div style="clear:both;">
</div>