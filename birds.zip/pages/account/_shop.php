<?PHP
$_OPTIMIZATION["title"] = "Покупка птиц";
$usid = $_SESSION["user_id"];
$refid = $_SESSION["referer_id"];
$usname = $_SESSION["user"];

$db->Query("SELECT * FROM db_users_b WHERE id = '$usid' LIMIT 1");
$user_data = $db->FetchArray();

$db->Query("SELECT * FROM db_config WHERE id = '1' LIMIT 1");
$sonfig_site = $db->FetchArray();

?>

<p class="  text-center" style="font-size: 110%;">
Здесь Вы можете покупать птицы различного уровня, на выбор 9-уровней птиц.<br/>
После покупки птицы будут нести яйца которые необходимо продавать в разделе склад. <br/>
Вы можете покупать неограниченное количество птиц, чем дороже тем больше Ваш заработок! <br/>
<b class="text-danger">Перед покупкой новых птичек, необходимо <a class="text-info" href="/store">СОБРАТЬ ВЫРУЧКУ</a> которая накопилась!</b>
</p>

<?PHP 
include("inc/_adsense.php"); 
?><br/>
<div class="p-2">
<?php

# Покупка нового дерева
if(isset($_POST["item"])){

$array_items = array(1 => "a_t", 2 => "b_t", 3 => "c_t", 4 => "d_t", 5 => "e_t", 6 => "f_t", 7 => "g_t", 8 => "h_t", 9 => "i_t", 10 => "j_t");
$array_name = array(1 => "LVL-1", 2 => "LVL-2", 3 => "LVL-3", 4 => "LVL-4", 5 => "LVL-5", 6 => "LVL-6", 7 => "LVL-7", 8 => "LVL-8", 9 => "LVL-9", 10 => "LVL-10");
$item = intval($_POST["item"]);
$citem = $array_items[$item];

	if(strlen($citem) >= 3){
		
		# Проверяем средства пользователя
		$need_money = $sonfig_site["amount_".$citem];
		if($need_money <= $user_data["money_b"]){
			
			if($user_data["last_sbor"] == 0 OR $user_data["last_sbor"] > ( time() - 60*10) ){
				
				$to_referer = $need_money * 0.01;


			# Добавляем строения и списываем деньги
			$db->Query("UPDATE db_users_b SET money_b = money_b - $need_money, $citem = $citem + 1,  
			last_sbor = IF(last_sbor > 0, last_sbor, '".time()."') WHERE id = '$usid'");

			# Даем энергию пользователю 30% от стоимости
			$energy = $need_money * 0.003;
			$db->Query("UPDATE db_users_b SET pay_points = pay_points + '$energy' WHERE id = '$usid'");
            
			# Вносим запись о покупке
			$db->Query("INSERT INTO db_stats_btree (user_id, user, tree_name, amount, date_add, date_del) 
			VALUES ('$usid','$usname','".$array_name[$item]."','$need_money','".time()."','".(time()+60*60*24*15)."')");
			$life_time->AddItem($usid,$citem);

			echo "<div class='alert alert-success'><b>Вы успешно купили!</b></div>";

			$db->Query("SELECT * FROM db_users_b WHERE id = '$usid' LIMIT 1");
			$user_data = $db->FetchArray();

		}else echo "<center><div class='alert alert-danger'>Перед покупкой, следует собрать прибыль</div></center><BR />";
		
	}else echo "<div class='alert alert-danger'><b>Недостаточно монет для покупок</b></div>";

}

}

# Окупаемость в процентах
$lvl1= ($sonfig_site["a_in_h"]*100)/$sonfig_site["amount_a_t"]/$sonfig_site["items_per_coin"]*24*30;
$lvl2= ($sonfig_site["b_in_h"]*100)/$sonfig_site["amount_b_t"]/$sonfig_site["items_per_coin"]*24*30;
$lvl3= ($sonfig_site["c_in_h"]*100)/$sonfig_site["amount_c_t"]/$sonfig_site["items_per_coin"]*24*30;
$lvl4= ($sonfig_site["d_in_h"]*100)/$sonfig_site["amount_d_t"]/$sonfig_site["items_per_coin"]*24*30;
$lvl5= ($sonfig_site["e_in_h"]*100)/$sonfig_site["amount_e_t"]/$sonfig_site["items_per_coin"]*24*30;
$lvl6= ($sonfig_site["f_in_h"]*100)/$sonfig_site["amount_f_t"]/$sonfig_site["items_per_coin"]*24*30;
$lvl7= ($sonfig_site["g_in_h"]*100)/$sonfig_site["amount_g_t"]/$sonfig_site["items_per_coin"]*24*30;
$lvl8= ($sonfig_site["h_in_h"]*100)/$sonfig_site["amount_h_t"]/$sonfig_site["items_per_coin"]*24*30;
$lvl9= ($sonfig_site["i_in_h"]*100)/$sonfig_site["amount_i_t"]/$sonfig_site["items_per_coin"]*24*30;
$lvl0= ($sonfig_site["j_in_h"]*100)/$sonfig_site["amount_j_t"]/$sonfig_site["items_per_coin"]*24*30;

?>
<div>
<div class="row">

<div class="col-xl-4 col-lg-6"><br/><br/>
<div class="card mt-5" style="background: #fff; border-radius: 1em;">
<div class="card-body pb-0">
<center>
<img src="/img/items/1.png" style="max-width: 95%;margin-top: -120px;">
<h4 style="text-transform: uppercase;"><b><?=$sonfig_site["name_a"]; ?></b> </h4>
</center>
<hr>
<p>Продуктивность яиц <span class="pull-right text-success"><b><?=$sonfig_site["a_in_h"]; ?> / час</b></span></p>
<p>Доход в день <span class="pull-right text-success"><b><?=sprintf("%.2f",$sonfig_site["a_in_h"]*24/10000); ?></b> <small class="fa fa-rub" style="font-size: 80%;"></small></span></p>
<p>Доход в месяц <span class="pull-right text-success"><b> <?=sprintf("%.2f",$sonfig_site["a_in_h"]*24*30/10000); ?></b> <small class="fa fa-rub" style="font-size: 80%;"></small>  <span title="Окупаемость в месяц" class="text-warning">/ <?=sprintf("%.0f",$lvl1); ?>%</span></span></p>
<p>Куплено <span class="pull-right text-success"><b><?=$user_data["a_t"]; ?> птиц</b></span></p>

<hr class="m-0 p-0">
</div>
<center>
<form action="" method="post" style="padding: 5px;margin:0;">
<input type="hidden" name="item" value="1" />
<input type="submit" value="Купить за <?=$sonfig_site["amount_a_t"]; ?> монет" class="btn btn-danger">
</form></center>
</div>
</div><!-- lvl 1 -->

<div class="col-xl-4 col-lg-6"><br/><br/>
<div class="card mt-5" style="background: #fff; border-radius: 1em;">
<div class="card-body pb-0">
<center>
<img src="/img/items/2.png" style="max-width: 95%;margin-top: -120px;">
<h4 style="text-transform: uppercase;"><b><?=$sonfig_site["name_b"]; ?></b> </h4>
</center>
<hr>
<p>Продуктивность яиц <span class="pull-right text-success"><b><?=$sonfig_site["b_in_h"]; ?> / час</b></span></p>
<p>Доход в день <span class="pull-right text-success"><b><?=sprintf("%.2f",$sonfig_site["b_in_h"]*24/10000); ?></b> <small class="fa fa-rub" style="font-size: 80%;"></small></span></p>
<p>Доход в месяц <span class="pull-right text-success"><b> <?=sprintf("%.2f",$sonfig_site["b_in_h"]*24*30/10000); ?></b> <small class="fa fa-rub" style="font-size: 80%;"></small>  <span title="Окупаемость в месяц" class="text-warning">/ <?=sprintf("%.0f",$lvl2); ?>%</span></span></p>
<p>Куплено <span class="pull-right text-success"><b><?=$user_data["b_t"]; ?> птиц</b></span></p>

<hr class="m-0 p-0">
</div>
<center>
<form action="" method="post" style="padding: 5px;margin:0;">
<input type="hidden" name="item" value="2" />
<input type="submit" value="Купить за <?=$sonfig_site["amount_b_t"]; ?> монет" class="btn btn-danger">
</form></center>
</div>
</div><!-- lvl 2 -->


<div class="col-xl-4 col-lg-6"><br/><br/>
<div class="card mt-5" style="background: #fff; border-radius: 1em;">
<div class="card-body pb-0">
<center>
<img src="/img/items/3.png" style="max-width: 95%;margin-top: -120px;">
<h4 style="text-transform: uppercase;"><b><?=$sonfig_site["name_c"]; ?></b> </h4>
</center>
<hr>
<p>Продуктивность яиц <span class="pull-right text-success"><b><?=$sonfig_site["c_in_h"]; ?> / час</b></span></p>
<p>Доход в день <span class="pull-right text-success"><b><?=sprintf("%.2f",$sonfig_site["c_in_h"]*24/10000); ?></b> <small class="fa fa-rub" style="font-size: 80%;"></small></span></p>
<p>Доход в месяц <span class="pull-right text-success"><b> <?=sprintf("%.2f",$sonfig_site["c_in_h"]*24*30/10000); ?></b> <small class="fa fa-rub" style="font-size: 80%;"></small>  <span title="Окупаемость в месяц" class="text-warning">/ <?=sprintf("%.0f",$lvl3); ?>%</span></span></p>
<p>Куплено <span class="pull-right text-success"><b><?=$user_data["c_t"]; ?> птиц</b></span></p>

<hr class="m-0 p-0">
</div>
<center>
<form action="" method="post" style="padding: 5px;margin:0;">
<input type="hidden" name="item" value="3" />
<input type="submit" value="Купить за <?=$sonfig_site["amount_c_t"]; ?> монет" class="btn btn-danger">
</form></center>
</div>
</div><!-- lvl 3 -->


<div class="col-xl-4 col-lg-6"><br/><br/>
<div class="card mt-5" style="background: #fff; border-radius: 1em;">
<div class="card-body pb-0">
<center>
<img src="/img/items/4.png" style="max-width: 95%;margin-top: -120px;">
<h4 style="text-transform: uppercase;"><b><?=$sonfig_site["name_d"]; ?></b> </h4>
</center>
<hr>
<p>Продуктивность яиц <span class="pull-right text-success"><b><?=$sonfig_site["d_in_h"]; ?> / час</b></span></p>
<p>Доход в день <span class="pull-right text-success"><b><?=sprintf("%.2f",$sonfig_site["d_in_h"]*24/10000); ?></b> <small class="fa fa-rub" style="font-size: 80%;"></small></span></p>
<p>Доход в месяц <span class="pull-right text-success"><b> <?=sprintf("%.2f",$sonfig_site["d_in_h"]*24*30/10000); ?></b> <small class="fa fa-rub" style="font-size: 80%;"></small>  <span title="Окупаемость в месяц" class="text-warning">/ <?=sprintf("%.0f",$lvl4); ?>%</span></span></p>
<p>Куплено <span class="pull-right text-success"><b><?=$user_data["d_t"]; ?> птиц</b></span></p>

<hr class="m-0 p-0">
</div>
<center>
<form action="" method="post" style="padding: 5px;margin:0;">
<input type="hidden" name="item" value="4" />
<input type="submit" value="Купить за <?=$sonfig_site["amount_d_t"]; ?> монет" class="btn btn-danger">
</form></center>
</div>
</div><!-- lvl 4 -->


<div class="col-xl-4 col-lg-6"><br/><br/>
<div class="card mt-5" style="background: #fff; border-radius: 1em;">
<div class="card-body pb-0">
<center>
<img src="/img/items/5.png" style="max-width: 95%;margin-top: -120px;">
<h4 style="text-transform: uppercase;"><b><?=$sonfig_site["name_e"]; ?></b> </h4>
</center>
<hr>
<p>Продуктивность яиц <span class="pull-right text-success"><b><?=$sonfig_site["e_in_h"]; ?> / час</b></span></p>
<p>Доход в день <span class="pull-right text-success"><b><?=sprintf("%.2f",$sonfig_site["e_in_h"]*24/10000); ?></b> <small class="fa fa-rub" style="font-size: 80%;"></small></span></p>
<p>Доход в месяц <span class="pull-right text-success"><b> <?=sprintf("%.2f",$sonfig_site["e_in_h"]*24*30/10000); ?></b> <small class="fa fa-rub" style="font-size: 80%;"></small>  <span title="Окупаемость в месяц" class="text-warning">/ <?=sprintf("%.0f",$lvl5); ?>%</span></span></p>
<p>Куплено <span class="pull-right text-success"><b><?=$user_data["e_t"]; ?> птиц</b></span></p>

<hr class="m-0 p-0">
</div>
<center>
<form action="" method="post" style="padding: 5px;margin:0;">
<input type="hidden" name="item" value="5" />
<input type="submit" value="Купить за <?=$sonfig_site["amount_e_t"]; ?> монет" class="btn btn-danger">
</form></center>
</div>
</div><!-- lvl 5 -->


<div class="col-xl-4 col-lg-6"><br/><br/>
<div class="card mt-5" style="background: #fff; border-radius: 1em;">
<div class="card-body pb-0">
<center>
<img src="/img/items/6.png" style="max-width: 95%;margin-top: -120px;">
<h4 style="text-transform: uppercase;"><b><?=$sonfig_site["name_f"]; ?></b> </h4>
</center>
<hr>
<p>Продуктивность яиц <span class="pull-right text-success"><b><?=$sonfig_site["f_in_h"]; ?> / час</b></span></p>
<p>Доход в день <span class="pull-right text-success"><b><?=sprintf("%.2f",$sonfig_site["f_in_h"]*24/10000); ?></b> <small class="fa fa-rub" style="font-size: 80%;"></small></span></p>
<p>Доход в месяц <span class="pull-right text-success"><b> <?=sprintf("%.2f",$sonfig_site["f_in_h"]*24*30/10000); ?></b> <small class="fa fa-rub" style="font-size: 80%;"></small>  <span title="Окупаемость в месяц" class="text-warning">/ <?=sprintf("%.0f",$lvl6); ?>%</span></span></p>
<p>Куплено <span class="pull-right text-success"><b><?=$user_data["f_t"]; ?> птиц</b></span></p>

<hr class="m-0 p-0">
</div>
<center>
<form action="" method="post" style="padding: 5px;margin:0;">
<input type="hidden" name="item" value="6" />
<input type="submit" value="Купить за <?=$sonfig_site["amount_f_t"]; ?> монет" class="btn btn-danger">
</form></center>
</div>
</div><!-- lvl 6 -->


<div class="col-xl-4 col-lg-6"><br/><br/>
<div class="card mt-5" style="background: #fff; border-radius: 1em;">
<div class="card-body pb-0">
<center>
<img src="/img/items/7.png" style="max-width: 95%;margin-top: -120px;">
<h4 style="text-transform: uppercase;"><b><?=$sonfig_site["name_g"]; ?></b> </h4>
</center>
<hr>
<p>Продуктивность яиц <span class="pull-right text-success"><b><?=$sonfig_site["g_in_h"]; ?> / час</b></span></p>
<p>Доход в день <span class="pull-right text-success"><b><?=sprintf("%.2f",$sonfig_site["g_in_h"]*24/10000); ?></b> <small class="fa fa-rub" style="font-size: 80%;"></small></span></p>
<p>Доход в месяц <span class="pull-right text-success"><b> <?=sprintf("%.2f",$sonfig_site["g_in_h"]*24*30/10000); ?></b> <small class="fa fa-rub" style="font-size: 80%;"></small>  <span title="Окупаемость в месяц" class="text-warning">/ <?=sprintf("%.0f",$lvl7); ?>%</span></span></p>
<p>Куплено <span class="pull-right text-success"><b><?=$user_data["g_t"]; ?> птиц</b></span></p>

<hr class="m-0 p-0">
</div>
<center>
<form action="" method="post" style="padding: 5px;margin:0;">
<input type="hidden" name="item" value="7" />
<input type="submit" value="Купить за <?=$sonfig_site["amount_g_t"]; ?> монет" class="btn btn-danger">
</form></center>
</div>
</div><!-- lvl 7 -->


<div class="col-xl-4 col-lg-6"><br/><br/>
<div class="card mt-5" style="background: #fff; border-radius: 1em;">
<div class="card-body pb-0">
<center>
<img src="/img/items/8.png" style="max-width: 95%;margin-top: -120px;">
<h4 style="text-transform: uppercase;"><b><?=$sonfig_site["name_h"]; ?></b> </h4>
</center>
<hr>
<p>Продуктивность яиц <span class="pull-right text-success"><b><?=$sonfig_site["h_in_h"]; ?> / час</b></span></p>
<p>Доход в день <span class="pull-right text-success"><b><?=sprintf("%.2f",$sonfig_site["h_in_h"]*24/10000); ?></b> <small class="fa fa-rub" style="font-size: 80%;"></small></span></p>
<p>Доход в месяц <span class="pull-right text-success"><b> <?=sprintf("%.2f",$sonfig_site["h_in_h"]*24*30/10000); ?></b> <small class="fa fa-rub" style="font-size: 80%;"></small>  <span title="Окупаемость в месяц" class="text-warning">/ <?=sprintf("%.0f",$lvl8); ?>%</span></span></p>
<p>Куплено <span class="pull-right text-success"><b><?=$user_data["h_t"]; ?> птиц</b></span></p>

<hr class="m-0 p-0">
</div>
<center>
<form action="" method="post" style="padding: 5px;margin:0;">
<input type="hidden" name="item" value="8" />
<input type="submit" value="Купить за <?=$sonfig_site["amount_h_t"]; ?> монет" class="btn btn-danger">
</form></center>
</div>
</div><!-- lvl 8 -->


<div class="col-xl-4 col-lg-6"><br/><br/>
<div class="card mt-5" style="background: #fff; border-radius: 1em;">
<div class="card-body pb-0">
<center>
<img src="/img/items/9.png" style="max-width: 95%;margin-top: -120px;">
<h4 style="text-transform: uppercase;"><b><?=$sonfig_site["name_i"]; ?></b> </h4>
</center>
<hr>
<p>Продуктивность яиц <span class="pull-right text-success"><b><?=$sonfig_site["i_in_h"]; ?> / час</b></span></p>
<p>Доход в день <span class="pull-right text-success"><b><?=sprintf("%.2f",$sonfig_site["i_in_h"]*24/10000); ?></b> <small class="fa fa-rub" style="font-size: 80%;"></small></span></p>
<p>Доход в месяц <span class="pull-right text-success"><b> <?=sprintf("%.2f",$sonfig_site["i_in_h"]*24*30/10000); ?></b> <small class="fa fa-rub" style="font-size: 80%;"></small>  <span title="Окупаемость в месяц" class="text-warning">/ <?=sprintf("%.0f",$lvl9); ?>%</span></span></p>
<p>Куплено <span class="pull-right text-success"><b><?=$user_data["i_t"]; ?> птиц</b></span></p>

<hr class="m-0 p-0">
</div>
<center>
<form action="" method="post" style="padding: 5px;margin:0;">
<input type="hidden" name="item" value="9" />
<input type="submit" value="Купить за <?=$sonfig_site["amount_i_t"]; ?> монет" class="btn btn-danger">
</form></center>
</div>
</div><!-- lvl 9 -->

</div>
</div>
<!-- End Shop List -->
</div>