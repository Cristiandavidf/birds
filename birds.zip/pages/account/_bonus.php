<?PHP
$_OPTIMIZATION["title"] = "Ежедневный бонус";
$usid = $_SESSION["user_id"];
$uname = $_SESSION["user"];

# Бонус выдача
$db->Query("SELECT insert_sum FROM db_users_b WHERE id = '{$usid}' LIMIT 1");
$user_data = $db->FetchArray();
$dep = $user_data["insert_sum"];

# Бонус уровни по кликам
	if($dep <= 99) {$daybon = 5;}
		elseif ($dep >= 100 and $dep < 299) {$daybon = rand(5, 20);}
		elseif ($dep >= 300 and $dep < 499) {$daybon = rand(10, 50);}
		elseif ($dep >= 500 and $dep < 1499) {$daybon = rand(20, 150);}
		elseif ($dep >= 1500 and $dep < 4999) {$daybon = rand(50, 400);}
		elseif ($dep >= 5000 and $dep < 9999) {$daybon = rand(200, 800);}
	elseif ($dep >= 10000) {$daybon = 1000;
	}


# Настройки бонусов
$bonus_min = $daybon;
$bonus_max = $daybon;

?>
<center class="mb-2" style="font-size: 120%;">
Бонус выдается каждые 24 часа. <BR />
Сумма бонуса генерируется случайно от <font class="text-success"><b>5</b></font> до <font class="text-success" data-toggle="collapse" data-target="#demo" style="cursor: pointer;"><b><u>1000</u></b></font> монет.<br/>
Бонус зависит от суммы пополнения чем больше пополнено тем выше бонус.<br/>
<font class="text-primary" data-toggle="collapse" data-target="#demo" style="cursor: pointer;"><b><u> <i class="fa fa-question-circle" aria-hidden="true"></i> Таблица уровней бонуса: </u></b></font>

<div id="demo" class="collapse">
<small><hr>
Сумма пополнения меньше 100 руб. = <b>бонус 5 монет.</b><br/>
Сумма пополнения 100 - 299 руб. = <b>бонус от 5 до 20 монет.</b><br/>
Сумма пополнения 300 - 499 руб. = <b>бонус от 10 до 50 монет.</b><br/>
Сумма пополнения 500 - 1499 руб. = <b>бонус от 20 до 150 монет.</b><br/>
Сумма пополнения 1500 - 4999 руб. = <b>бонус от 50 до 400 монет.</b><br/>
Сумма пополнения 5000 - 9999 руб. = <b>бонус от 200 до 800 монет.</b><br/>
Сумма пополнения свыше 10000 руб. = <b>бонус 1000 монет.</b><br/>
</small>
</div>

<br/><br/>

<b style="font-size: 22px;">После перехода по баннеру можно получить бонус</b>


</center>

<?PHP
$ddel = time() + 60*60*24;
$dadd = time();
$db->Query("SELECT COUNT(*) FROM db_bonus WHERE user_id = '$usid' AND date_del > '$dadd'");

$hide_form = false;

	if($db->FetchRow() == 0){
	
		# Выдача бонуса
		if(isset($_POST["bonus"])){
		
			$sumrad = rand($bonus_min, rand($bonus_min, $bonus_max) );
			$sum=$sumrad;
			
			# Зачилсяем юзверю
			$db->Query("UPDATE db_users_b SET money_b = money_b + '$sum' WHERE id = '$usid'");
			
			# Вносим запись в список бонусов
			$db->Query("INSERT INTO db_bonus (user, user_id, sum, date_add, date_del) VALUES ('$uname','$usid','$sum','$dadd','$ddel')");
			
			# Случайная очистка устаревших записей
			$db->Query("DELETE FROM db_bonus WHERE date_del < '$dadd'");
			
			echo "<div class='alert alert-success'>На Ваш счет для покупок зачислен бонус в размере {$sum} монет</div>";
			
			$hide_form = true;
			
		}
			
			# Показывать или нет форму
			if(!$hide_form){
?>
<center>
<div id="hidden_link" onclick="document.all.hidden_link1.style.display='block';" style="width: 468px;display:yes">
Здесь баннеры
</div>
<div id="hidden_link1" onclick="document.all.hidden_link2.style.display='block';" style="display:none"><br/>
<form action="" method="post"><input type="submit" name="bonus" value="Получить бонус" class="btn btn-lg btn-success"></form></div>
</center><br/>
<?PHP 

			}

	}else {
	   $db->Query("SELECT * FROM db_bonus WHERE user_id = '$usid' AND date_del > '$dadd'");
$u_data = $db->FetchArray();
$time = $u_data['date_del'] - $dadd;
$hours = floor($time/3600);
floor($minutes =($time/3600 - $hours)*60);
$seconds = ceil(($minutes - floor($minutes))*60);
$min=ceil($minutes)-1;
	   ?>

<center class="alert alert-success" style="font-size: 18px;"><b id="bonus">Следующий бонус будет доступен через: <?=json_encode($hours);echo ' ч.  ';echo json_encode($min);echo ' мин.  '; echo json_encode($seconds);echo ' сек.  ';?></b><script>setInterval(function(){
$("#bonus").load("# #bonus"); }, 1000); </script></center><br/>
        <?php
	}
?>

	<div class="stats">
<h5 style="text-align:center">
Последние 20 бонусов
</h5>
<table class="table table-bordered" cellpadding='3' cellspacing='0' align='center' width="97%">  
<thead>
	<th><b>ID</b></th>
	<th><b>Пользователь</b></th>
	<th><b>Сумма</b></th>
	<th><b>Дата</b></th>
</thead>
  <?PHP
  
  $db->Query("SELECT * FROM db_bonus ORDER BY id DESC LIMIT 20");
  
	if($db->NumRows() > 0){
  
  		while($bon = $db->FetchArray()){
		
		?>
		
	<tr>
    		<td align="center"><?=$bon["id"]; ?></td>
    		<td align="center"><?=$bon["user"]; ?></td>
    		<td align="center"><?=$bon["sum"]; ?></td>
		<td align="center"><?=date("d.m.Y в H:i:s",$bon["date_add"]); ?></td>
  		</tr>
		<?PHP
		
		}
  
	}else echo '<tr><td align="center" colspan="5">Нет записей</td></tr>'
  ?>

</table>

</div>