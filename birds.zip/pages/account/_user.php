 <?
$_OPTIMIZATION["title"] = "Стена пользователя";

 $usname = $_SESSION["user"];
 $usid = $_SESSION["user_id"];
 $date = time();
 
 if(isset($_GET['name'])) {
 $name = htmlspecialchars($_GET['name']);
 $q = $db->Query("SELECT * FROM db_users_a WHERE user = '$name'");
 $us_inf = $db->FetchArray($q);
 $us = $us_inf['id'];
 $db->Query("SELECT * FROM db_users_b WHERE user = '$name'");
 $dat = $db->FetchArray();
 
 ?>
<style>
.user_wall .pull-right {
 font-weight: bold;
}
</style>

<div class="row">
<div class="col-md-4">
<?
if(empty($us_inf['ava'])) {
echo '<center><img class="img-thumbnail" src="/img/avatar/c50.gif"></center>';
}else{
echo '<center><img class="img-thumbnail" src="/'.$us_inf['ava'].'"></center>';
}
?>
<br/>

</div>

<div class="col-md-8 user_wall">
<div class="card bg-light">
	<div class="card-heading" style="padding: 5px 15px;">Информация о пользователе:</div>
	<div class="card-body">
Логин: <span class="pull-right"><?=$name; ?></span><br/>
Регистрация: <span class="pull-right"><?=date('d-m-Y', $us_inf['date_reg']); ?></span><br/>
Последний визит: <span class="pull-right"><?=date('d-m-Y', $us_inf['date_login']); ?></span><br/>
Просмотрено рекламы: <span class="pull-right"><?=intval($dat['pay_points']); ?> раз</span><br/>
Рекламировал на сумму: <span class="pull-right"><?=intval($dat['insert_sum']); ?> руб.</span><br/>
Заработал денег: <span class="pull-right"><?=intval($dat['payment_sum']); ?> руб.</span><br/>
Кто пригласил(REFERER): <span class="pull-right"><b><a href="<?=$us_inf['referer']; ?>"><?=$us_inf['referer']; ?></a></b></span><br/>
Принес рефереру: <span class="pull-right"><?=intval($dat['to_referer']/100); ?> руб.</span><br/>
Кол-во рефералов: <span class="pull-right"><?=$us_inf["referals"]; ?> чел.</span><br/>
Заработал на рефералах: <span class="pull-right"><?=intval($dat['from_referals']/100); ?> руб.</span><br/>
	</div>
</div>
</div>
</div>



</center>


<? } else {?>

<div class="alert bg-light">	
Стена пользователя, дает возможность наблюдать за его активностью на проекте.
Надеемся, что это поможет вам не прогадать с человеком и отблагодарить реферала на проекте вашей активностью.<br>
</div>	

<? } ?>