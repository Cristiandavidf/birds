<?PHP
$_OPTIMIZATION["title"] = "Обменник";
$usid = $_SESSION["user_id"];
$usname = $_SESSION["user"];

$db->Query("SELECT * FROM db_users_b WHERE id = '$usid' LIMIT 1");
$user_data = $db->FetchArray();

$db->Query("SELECT * FROM db_config WHERE id = '1' LIMIT 1");
$sonfig_site = $db->FetchArray();
?>  

<center><p>Обмен игровой валюты с "Баланс для вывода" на "Баланс для покупок". +<?=$sonfig_site["percent_swap"]; ?>%.</p></center>


<?PHP

if(isset($_POST["sum"])){

$sum = intval($_POST["sum"]);

	if($sum >= 1000){
	
		if($user_data["money_p"] >= $sum){
		
		$add_sum = ($sonfig_site["percent_swap"] > 0) ? ( ($sonfig_site["percent_swap"] / 100) * $sum) + $sum : $sum;
		
		$ta = time();
		$td = $ta + 60*60*24*15;
		
		$db->Query("UPDATE db_users_b SET money_b = money_b + $add_sum, money_p = money_p - $sum WHERE id = '$usid'");
		$db->Query("INSERT INTO db_swap_ser (user_id, user, amount_b, amount_p, date_add, date_del) VALUES ('$usid','$usname','$add_sum','$sum','$ta','$td')");
		
		echo "<center class='alert alert-success'>Обмен произведен</center>";
		
		}else echo "<center class='alert alert-warning'>Недостаточно монет для обмена</center>";
	
	}else echo "<center class='alert alert-danger'>Мин. Сумма для обмена 1000 монет</center>";

}

?>
<center>
<div class="card text-center" style="max-width: 370px;">
<div class="card-body">
<form action="" method="post">
	<div class="input-group">
	<div class="input-group-prepend">
	<span class="input-group-text" style="min-width: 165px;">Отдаете монеты</span>
	</div>
<input type="text" name="sum" id="sum" value="1000" onkeyup="GetSumPer();" style="width: 70px;margin:0;font-size: 22px;" class="form-control"/>
	</div>
<hr>
<h5 class="card-title">Получаете:</h5>
<h2><span class="text-danger"><span id="res_sum" name="res">0.00</span></span><br/>монет</h2>
<input type="hidden" name="per" id="percent" value="<?=$sonfig_site["percent_swap"]; ?>" disabled="disabled"/>


<center>
	<input class="btn btn-success btn-lg" style="text-align: left;" type="submit" name="swap" value="Обменять"/>
</center></div>
</form>
</div>
</center>

<script language="javascript">GetSumPer();</script>
<br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>