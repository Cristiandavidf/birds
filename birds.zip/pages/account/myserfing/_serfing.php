<?php

define('TIME', time());
header("Content-Type: text/html; charset=utf-8");

$_OPTIMIZATION["title"] = "Просмотр рекламы";
$usid = $_SESSION["user_id"];
$usname = $_SESSION["user"];

$db->Query("SELECT * FROM db_users_a WHERE id = '".$_SESSION['user_id']."'");
$users_info = $db->FetchArray();

$db->Query("SELECT * FROM db_users_b WHERE id = '".$_SESSION['user_id']."'");
$users_info2 = $db->FetchArray();

    if (isset($_GET['delete']))
    {
        $id = (int)$_GET['delete'];

        #if (isset($_SESSION['admin']))
        if ($config->serfIdAdmin() == $_SESSION["user_id"])
        {
            $db->query("SELECT `money`, `user_name` FROM `db_serfing` WHERE id = '".$id."' LIMIT 1");

            $result = $db->FetchArray();

            $db->query("UPDATE db_users_b SET money_b = money_b + '".$result['money']."' WHERE user = '".$result['user_name']."'");

            $db->query("DELETE FROM db_serfing WHERE id = '".$id."'");
            #$db->query("DELETE FROM db_serfing_view WHERE ident = '".$id."'");
        }
    }
?>

    <?include("serf_menu.php");?>

<center>
<?php
if ($users_info2["insert_sum"] >= 9.99){
?>
<b>Администрация не отвечает за рекламные ссылки размещенные в серфинге.</b> 
<?php
}

else{ ?>
<b class="text-danger">Пополните баланс на сумму более  10 рублей, оплата за просмотр сайтов будет 2 раза больше!</b> 
<?php
} 
?>
</center><br/>

<div class="list-group">

<style>
.surfblockopen{background-color: #d0F0e0;border-color: #D0D0D0;color: #808080;opacity:0.3;display:none;}
.panel-success {border-width: 2px;}
</style>
	<script>
function showFrame(div, link) {
  window.open('/account/serfing/view/'+link, '_blank');
  $(div).parent().parent().parent().parent().addClass("surfblockopen");
}
</script>


<?php
    $db->query("SELECT ident, time_add FROM db_serfing_view WHERE user_id = '$usid' AND time_add + INTERVAL 24*60*60 SECOND > NOW()");

    while ($row_view = $db->FetchArray())
    {
        $visits[$row_view['ident']] = $row_view;
    }

    $db->Query("SELECT * FROM db_serfing WHERE `money` >= `price` and `status` = '2' ORDER BY high DESC, wind DESC, money DESC, time_add DESC");
    if ($db->NumRows())
    {
        while ($row = $db->FetchArray())
        {

            if (isset($visits[$row['id']])) continue;

            if ($row['speed'] > 1)
            {
                if (mt_rand(1, $row['speed']) != 1) continue;
            }

            $high = ($row['high']) ? 'bg-warning' : 'bg-light';

			if($users_info2['insert_sum'] <= 9.99) {
				 $sum_user = number_format($row['price'] - $row['price'] * (30/100), 2); //оплата пользователю
				 $pay_user = number_format(($sum_user / 2), 2);
			} else {
			 $pay_user = number_format($row['price'] - $row['price'] * (30/100), 2); //оплата пользователю	
			}

            if ($row['id'] == 2) {
?>

<div href="" class="serf list-group-item <?=$high; ?>">
<div class="row" id="<?=$row['id']; ?>">
<div class="col-sm-12">
<h4><img src="https://www.google.com/s2/favicons?domain=<?=$row['url']; ?>"> <a onclick="showFrame(this, '<?php echo $row['id']; ?>');" class="serf-title" title="Начать просмотр сайта"><?=$row['title']; ?></a></h4>
<h6><span class="text-danger"><i class="fa fa-clock-o"></i> Время просмотра: <?=$row['timer']; ?> сек.</span>
<span class="text-success"><i class="fa fa-money"></i> Оплата: <?=$pay_user; ?> SATOSHI</span>
<?=($row['wind'] == 1) ? '<span class="text-info"><i class="fa fa-window-maximize"></i> Активное окно</span>' : '';?>
<span class="pull-right">Осталось <?php echo (int)($row['money']/$row['price']); ?> просмотров</span>
</h6></div>
</div>
</div>
<?php

            }else{

?>
<div id="tr<?=$row['id']; ?>" class="serf">
<div class="row" id="<?=$row['id']; ?>">
<div class="col-sm-10 normalm">
<h4><img src="https://www.google.com/s2/favicons?domain=<?=$row['url']; ?>"> <a href="#" onclick="showFrame(this, '<?php echo $row['id']; ?>');" class="serf-title" title="Начать просмотр сайта"><?=$row['title']; ?> </a> </h4>
<h6><i><span class="text-danger"><i class="fa fa-clock-o"></i> Время просмотра: <?=$row['timer']; ?> сек.</span>
<?=($row['wind'] == 1) ? '<span class="text-info"><i class="fa fa-tv"></i> Активное окно</span>' : '';?>

<span class="pull-right" style="padding-right: 0;">Осталось <?php echo (int)($row['money']/$row['price']); ?> просмотров
</span>
</i></h6></div>
<div class="col-sm-2 <?=$high; ?>">
<h2 class="serf-cent"><i class="fa fa-money"></i> <?=$pay_user; ?></h2>
</div>
<?php if ($config->serfIdAdmin() == $_SESSION["user_id"]) { ?><div class="col-sm-12 alert-info">
<span class="text-primary"><i class="fa fa-info"></i> Реклама: <?=$row['id']; ?>, Рекламодатель: <?=$row['user_name']; ?> | <?=$row['url']; ?> 
</span>
<a class="badge btn-danger" href="/account/serfing/delete/<?=$row['id']; ?>" title="Удалить ссылку и вернуть деньги"><i class="fa fa-close"></i></a> 
</div><?php } ?>

</div>
</div>
<?php
            }
        }
    }
    else
    {
        echo "<center><h3>Нет ссылок для просмотра</h3></center>";
    }
?>
<br/><br/>
<hr>
<center class="p-1">
 
</center>
</div>