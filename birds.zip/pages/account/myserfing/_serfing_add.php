<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

define('TIME', time());


define('SERF_PRICE', 4); //минимальная стоимость просмотра
define('SERF_PRICE_TIMER', 0.0); //стоимость таймера
define('SERF_PRICE_MOVE', 0.0); //стоимость последующего перехода на сайт
define('SERF_PRICE_WIND', 2.0); //стоимость просмотра в активном окне
define('SERF_PRICE_HIGH', 2.0); //стоимость выделения ссылки
define('SERF_PRICE_TARGET', 0.0); //стоимость таргетинга


header("Content-Type: text/html; charset=utf-8");
$_OPTIMIZATION["title"] = "Добавить рекламу в серфинг";
$msg = '';

$db->Query("SELECT * FROM db_users_b WHERE id = '".$_SESSION['user_id']."'");
$users_info = $db->FetchArray();
?>
<link rel="stylesheet" href="/style/main.css" type="text/css" />
<?php

//Данные для формы (по умолчанию)
$title = '';
$desc = '';
$url = 'https://';
$timer = 20;
$move = 0;
$wind = 0;
$high = 0;
$speed = 1;
$rating = 1;

$advedit = isset($_GET['advedit']) ? (int)$_GET['advedit'] : false; 

$user_name = $_SESSION['user'];

if (!$advedit && isset($_POST['ask_editcode'])) { $advedit = (int)$_POST['ask_editcode']; }


if ($advedit)
{  
    #if (isset($_SESSION['admin'])) 
    if ($config->serfIdAdmin() == $usid)
    {
        $db->query("SELECT * FROM `db_serfing` WHERE id = '".$advedit."' LIMIT 1");
    } 
    else
    { 
        $db->query("SELECT * FROM `db_serfing` WHERE `id` = '$advedit' AND `user_name` = '$user_name' LIMIT 1");
    }
      
    if ($db->NumRows())
    {
        $result = $db->FetchArray();    
        
        //Подставляем данные из БД для формы редактирования
        $title = $result['title'] ? $result['title'] : '';
        $desc = $result['desc'] ? $result['desc'] : '';
        $url = $result['url'] ? $result['url'] : '';   
        $timer = $result['timer'] ? $result['timer'] : 20;
        $move = $result['move'] ? $result['move'] : 0;
        $wind = $result['wind'] ? $result['wind'] : 0;
        $high = $result['high'] ? $result['high'] : 0;
        $speed = $result['speed'] ? $result['speed'] : 1;
        $rating = $result['rating'] ? $result['rating'] : 1; # Тариф
        $status = $result['status'];
    } 
    else 
    {
        #exit(1);
        $show = true;
    }
} 


if (isset($_POST['title']))
{
    //Заголовок ссылки
    $title = filter_var(mb_substr(trim($_POST['title']), 0, 98), FILTER_SANITIZE_STRING);
    
    //Краткое описание ссылки
    $desc = mb_substr(trim(""),0 ,98);

    // Тариф
    $rating = isset($_POST['type']) ? trim($_POST['type']) : '1';
    
    //URL сайта
 //   $url = isset($_POST['url']) ? trim($_POST['url']) : '';  
$url = filter_var(mb_substr(trim($_POST['url']),0 ,555), FILTER_SANITIZE_STRING);
    if (!filter_var($url, FILTER_VALIDATE_URL)) { echo '<span class="msgbox-error">Неверный адрес сайта</span>'; return; }

    //Если не заполнены основные поля
    if ($title == '' || $url == '') { echo '<span class="msgbox-error">Заполнены не все поля</span>'; return; }

    if (isset($_POST['type'])) {
        $type = (int)$_POST['type'];

        if ($type == 1) {
            # Первый тариф
            
            //Время просмотра ссылки
            $timer = 1;
            $timer_arr = array('1' => 20, '2' => 30, '3' => 40);
            if (!isset($timer_arr[$timer])) { echo '<span class="msgbox-error">Ошибка данных1</span>'; return; }
            
            //Последующий переход на сайт
            $move = 1;
            if ($move > 1 || $move < 0) { echo '<span class="msgbox-error">Ошибка данных2</span>'; return; }

            // Просмот в активном окне
            $wind = 0;
            if ($wind > 1 || $wind < 0) { echo '<span class="msgbox-error">Ошибка данных3</span>'; return; }
            
            //Выделить ссылку
            $high = 0;
            if ($high > 1 || $high < 0) { echo '<span class="msgbox-error">Ошибка данных4</span>'; return; }

        }elseif ($type == 2) {
            # Второй тариф
            
            //Время просмотра ссылки
            $timer = 2;
            $timer_arr = array('1' => 20, '2' => 30, '3' => 40);
            if (!isset($timer_arr[$timer])) { echo '<span class="msgbox-error">Ошибка данных</span>'; return; }
            
            //Последующий переход на сайт
            $move = 1;
            if ($move > 1 || $move < 0) { echo '<span class="msgbox-error">Ошибка данных</span>'; return; }

            // Просмот в активном окне
            $wind = 0;
            if ($wind > 1 || $wind < 0) { echo '<span class="msgbox-error">Ошибка данных</span>'; return; }
            
            //Выделить ссылку
            $high = 1;
            if ($high > 1 || $high < 0) { echo '<span class="msgbox-error">Ошибка данных</span>'; return; }

        }elseif ($type == 3) {
            # Третий тариф
            
            //Время просмотра ссылки
            $timer = 3;
            $timer_arr = array('1' => 20, '2' => 30, '3' => 40);
            if (!isset($timer_arr[$timer])) { echo '<span class="msgbox-error">Ошибка данных</span>'; return; }
            
            //Последующий переход на сайт
            $move = 1;
            if ($move > 1 || $move < 0) { echo '<span class="msgbox-error">Ошибка данных</span>'; return; }

            // Просмот в активном окне
            $wind = 1;
            if ($wind > 1 || $wind < 0) { echo '<span class="msgbox-error">Ошибка данных</span>'; return; }
            
            //Выделить ссылку
            $high = 1;
            if ($high > 1 || $high < 0) { echo '<span class="msgbox-error">Ошибка данных</span>'; return; }

        }else{
            echo "Error Type!";
        }
    }
    
    
    //Расчёт стоимости просмотра
    $price = SERF_PRICE; 
    
    if ($move == 1) {$price += SERF_PRICE_MOVE; }

    if ($wind == 1) {$price += SERF_PRICE_WIND; }
    
    if ($high == 1) { $price += SERF_PRICE_HIGH; }
    
    if ($timer == 30) { $price += SERF_PRICE_TIMER; } 
    else if ($timer == 40) { $price += (SERF_PRICE_TIMER * 2); } 
    else if ($timer == 50) { $price += (SERF_PRICE_TIMER * 3); } 
    else if ($timer == 60) { $price += (SERF_PRICE_TIMER * 4); }
   
   
    $price = number_format($price, 2, '.', '');
    
    if ($advedit) 
    {  
        #if (!isset($_SESSION['admin']))
        if ($config->serfIdAdmin() !== $usid)
        {
            if ($result['title'] != $title || $result['desc'] != $desc || $result['url'] != $url)
            {
                #$status = 0; 
                $status = '3';     
            }
        }  
   
        $db->query("UPDATE db_serfing SET `title` = '".$title."', `desc` = '".$desc."', `url` = '".$url."', `timer` = '".$timer."', `move` = '".$move."', `high` = '".$high."', `speed` = '".$speed."', `country` = '0', `rating` = '".$rating."', `wind` = '".$wind."', `price` = '".$price."', `status` = '".$status."' WHERE id = '".$advedit."'");
    
        #if (isset($_SESSION['admin']))
        if ($config->serfIdAdmin() == $usid) 
        {
            header('Location: /account/serfing/moder'); 
        } 
        else
        {
            header('Location: /account/serfing/cabinet'); 
        }
    
        exit();
    }
    else
    { 
        #if (isset($_SESSION['admin']))
        if ($config->serfIdAdmin() == $usid)
        {
            $status = '3';
        }
        else
        {
            #$status = '0';
            $status = '3';
        }
   
        $db->query("INSERT INTO db_serfing
            (
            `user_name`,
            `time_add`,	    
            `title`,
            `desc`,
            `url`,         
            `timer`,
            `move`,
            `high`,
            `speed`,	  
            `country`,
            `rating`,
            `wind`,
            `price`,
            `status`
            )
            VALUES
            (
                '".$_SESSION['user']."',
                '".TIME."',
                '".$title."',
                '".$desc."',
                '".$url."', 
                '".$timer."',
                '".$move."', 
                '".$high."',
                '".$speed."',	  
                '0',
                '".$rating."', 
                '".$wind."',
                '".$price."',
                '".$status."'
            )");
      
        //echo '<span class="msgbox-success">Ссылка добавлена</span>';
      
        header('Location: /account/serfing/cabinet'); exit();
    }  
} 

//end:

if ($rating == '1') {
    $selected1 = "selected";
    $selected2 = "";
    $selected3 = "";  
}elseif ($rating == '2') {
    $selected1 = "";
    $selected2 = "selected";
    $selected3 = ""; 
}elseif ($rating == '3') {
    $selected1 = "";
    $selected2 = "";
    $selected3 = "selected"; 
}else{
    $selected1 = "";
    $selected2 = "";
    $selected3 = ""; 
}

?>
<script>
function SbmForm() {
    if (document.forms['surforder'].title.value == '') {
        alert('Вы не указали заголовок ссылки');
        document.forms['surforder'].title.focus();
        return false;
    }

    if (document.forms['surforder'].rule.value == '') {
        alert('Вы не согласились с правилами');
        document.forms['surforder'].rule.focus();
        return false;
    }

    // if (document.forms['surforder'].ask_desc.value == '') {
    //     alert('Вы не указали краткое описание ссылки');
    //     document.forms['surforder'].ask_desc.focus();
    //     return false;
    // }
    if ((document.forms['surforder'].url.value == '')|(document.forms['surforder'].url.value == 'http://')) {
        alert('Вы не указали URL-адрес ссылки');
        document.forms['surforder'].url.focus();
        return false;
    }
    
    document.forms['surforder'].submit();
    return true;
}
 
function PlanChange(frm)
{  
 
    lprice = serf_price;
    if (frm.ask_move.value == 1) {
        lprice += serf_price_move;
    }
    if (frm.ask_wind.value == 1) {
        lprice += serf_price_wind;
    }
    if (frm.ask_high.value == 1) {
        lprice += serf_price_high;
    }
    if (frm.ask_timer.value == 30) {
        lprice += serf_price_timer;
    } else
    if (frm.ask_timer.value == 40) {
        lprice += (serf_price_timer * 2);
    } else
    if (frm.ask_timer.value == 50) {
        lprice += (serf_price_timer * 3);
    } else
    if (frm.ask_timer.value == 60) {
        lprice += (serf_price_timer * 4);
    }

    frm.linkprice.value = number_format(lprice, 2, '.', '');
    
    //money = lprice * $('input[name=ask_kolvo]').val();
    
    //frm.money.value = number_format(money, 2, '.', '');
}

function number_format(number, decimals, dec_point, thousands_sep) {
    var i, j, kw, kd, km;
    if (isNaN(decimals = Math.abs(decimals))) {
        decimals = 2;
    }
    if (dec_point == undefined) {
        dec_point = ",";
    }
    if (thousands_sep == undefined) {
        thousands_sep = ".";
    }
    i = parseInt(number = (+number || 0).toFixed(decimals)) + "";
    if ((j = i.length) > 3) {
        j = j % 3;
    } else {
        j = 0;
    }
    km = (j ? i.substr(0, j) + thousands_sep : "");
    kw = i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + thousands_sep);
    kd = (decimals ? dec_point + Math.abs(number - i).toFixed(decimals).replace(/-/, 0).slice(2) : "");
    return km + kw + kd;
}
 
function showhide(bid) {
    if (document.getElementById('cattitle'+bid).className == 'cattitle-open')
        document.getElementById('cattitle'+bid).className = 'cattitle-close'; else
        document.getElementById('cattitle'+bid).className = 'cattitle-open';
    $('#catblock'+bid).slideToggle('fast');
}


    var serf_price = <?php echo SERF_PRICE; ?>;
    var serf_price_timer = <?php echo SERF_PRICE_TIMER; ?>;
    var serf_price_move = <?php echo SERF_PRICE_MOVE; ?>;
    var serf_price_wind = <?php echo SERF_PRICE_WIND; ?>;
    var serf_price_high = <?php echo SERF_PRICE_HIGH; ?>;
    var serf_price_target = <?php echo SERF_PRICE_TARGET; ?>;
    function ClearForm()
    {
        //document.forms['surforder'].ask_timer.value = <?php echo $timer; ?>;
        //document.forms['surforder'].ask_move.value = <?php echo $move; ?>;
        //document.forms['surforder'].ask_wind.value = <?php echo $wind; ?>;
        //document.forms['surforder'].ask_high.value = <?php echo $high; ?>;

        //document.forms['surforder'].ask_speed.value = <?php echo $speed; ?>;  
        //document.getElementById("ask_speed").value = "<?=$speed;?>"; 
        //PlanChange(document.forms['surforder']);
    }
    
    $(document).ready(function() { ClearForm(); });
        
</script> 

<div class="silver-bk">

<?include("serf_menu.php");?>

<style type="text/css">
.m-r-15 {
    margin-right: 15px !important;
}
.text-danger {
    color: #f03154;
}
.text-primary {
    color: #5cb45b;
}
.text-danger {
    color: #f03154;
}
@media (max-width: 1380px) and (min-width: 1330px)
.addsurf_h5 {
    padding-left: 10px;
    font-size: 14px;
}
.addsurf_h5 {
    text-align: left;
    font-size: 15px;
    font-weight: 100;
    padding-left: 60px;
}

.form-group {
    margin-bottom: 10px;
}
label {
    display: inline-block;
    max-width: 100%;
    margin-bottom: 5px;
    font-weight: 700;
}
.form-control {
    -moz-border-radius: 2px;
    -moz-box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.1);
    -webkit-border-radius: 2px;
    -webkit-box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.1);
    box-shadow: none;
    color: rgba(0, 0, 0, 0.6);
    font-size: 14px;
}
.form-control {
    display: block;
    width: 100%;
    padding: 6px 12px;
    font-size: 14px;
    line-height: 1.42857143;
    color: #456;
    background-color: #fff;
    background-image: none;
    -webkit-box-shadow: inset 0 1px 1px rgba(0,0,0,.075);
    box-shadow: inset 0 1px 1px rgba(0,0,0,.075);
    -webkit-transition: border-color ease-in-out .15s,-webkit-box-shadow ease-in-out .15s;
    -o-transition: border-color ease-in-out .15s,box-shadow ease-in-out .15s;
    transition: border-color ease-in-out .15s,box-shadow ease-in-out .15s;
}
:after, :before {
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    box-sizing: border-box;
}
.waves-effect {
    position: relative;
    cursor: pointer;
    display: inline-block;
    overflow: hidden;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    -webkit-tap-highlight-color: transparent;
    vertical-align: middle;
    z-index: 1;
    will-change: opacity, transform;
    -webkit-transition: all 0.3s ease-out;
    -moz-transition: all 0.3s ease-out;
    -o-transition: all 0.3s ease-out;
    -ms-transition: all 0.3s ease-out;
    transition: all 0.3s ease-out;
}
@media (max-width: 1799px) and (min-width: 1199px)
.addsurf_priceform {
    float: none;
    display: block;
}
.addsurf_priceform {
    float: right;
    display: inline;
    padding-top: 8px;
    font-weight: bold;
}
.in {
    background-color: #70cbff;
}
#in1, #in2, #in3  {
    border: 4px double #3f4b59;border-radius: 0px;
}
.list-group-item div {
float: right;
}
.list-group-item {
padding: 5px 10px 3px;
}
.list-group .active{
border-color: #3f4b59;
background-color: #3f4b59 !important;
}
</style>

<?php 
if (isset($show) == false) {
?>
<div class="row">
	<div class="col-sm-4">
            <div id="in1" class="in">
<ul class="list-group">
<li class="list-group-item"><h5 class="m-t-0 m-b-10 profilemst addsurf_topzag"><i class="fa fa-car text-danger m-r-15"></i><b>Тариф "Эконом"</b></h5></li>
<li class="list-group-item"><i class="fa fa-cube"></i> Переход после просмотра: <div class="text-primary">ДА</div></li>
<li class="list-group-item"><i class="fa fa-eye"></i> Просмотр в активном окне: <div class="text-danger">НЕТ</div></li>
<li class="list-group-item"><i class="fa fa-bug"></i> Защита от автокликеров: <div class="text-primary">ДА</div></li>
<li class="list-group-item"><i class="fa fa-clock-o"></i> Просмотр сайта: <div>20 секунд</div></li>
<li class="list-group-item"><i class="fa fa-bolt"></i> Выделение в списке: <div class="text-danger">НЕТ</div></li>
<li class="list-group-item active"><b>Цена за 1000 просмотров: 40 руб.</b></li>
</ul>
            </div>
	</div>

	<div class="col-sm-4">
            <div id="in2">
<ul class="list-group">
<li class="list-group-item"><h5 class="m-t-0 m-b-10 profilemst addsurf_topzag"><i class="fa fa-plane text-danger m-r-15"></i><b>Тариф "Обычный"</b></h5></li>
<li class="list-group-item"><i class="fa fa-cube"></i> Переход после просмотра: <div class="text-primary">ДА</div></li>
<li class="list-group-item"><i class="fa fa-eye"></i> Просмотр в активном окне: <div class="text-danger">НЕТ</div></li>
<li class="list-group-item"><i class="fa fa-bug"></i> Защита от автокликеров: <div class="text-primary">ДА</div></li>
<li class="list-group-item"><i class="fa fa-clock-o"></i> Просмотр сайта: <div>30 секунд</div></li>
<li class="list-group-item"><i class="fa fa-bolt"></i> Выделение в списке:  <div class="text-primary">ДА</div></li>
<li class="list-group-item active"><b>Цена за 1000 просмотров: 60 руб.</b></li>
</ul>
 	</div>
	</div>

	<div class="col-sm-4">
            <div id="in3">
<ul class="list-group">
<li class="list-group-item"><h5 class="m-t-0 m-b-10 profilemst addsurf_topzag"><i class="fa fa-rocket text-danger m-r-15"></i><b>Тариф "Премиум"</b></h5></li>
<li class="list-group-item"><i class="fa fa-cube"></i> Переход после просмотра: <div class="text-primary">ДА</div></li>
<li class="list-group-item"><i class="fa fa-eye"></i> Просмотр в активном окне: <div class="text-primary">ДА</div></li>
<li class="list-group-item"><i class="fa fa-bug"></i> Защита от автокликеров: <div class="text-primary">ДА</div></li>
<li class="list-group-item"><i class="fa fa-clock-o"></i> Просмотр сайта: <div>40 секунд</div></li>
<li class="list-group-item"><i class="fa fa-bolt"></i> Выделение в списке:  <div class="text-primary">ДА</div></li>
<li class="list-group-item active"><b>Цена за 1000 просмотров: 80 руб.</b></li>
</ul>
            </div>
	</div>
</div><br/>

<div class="card">

<h4 class="card-header bg-light">Добавление сайта в сёрфинг</h4>
<div class="card-body">
<!-- <form action="./addsurfing?hex=4ab7149726ce24df6f9900381236f809&add" method="post"> -->
<form name="surforder" id="myform" method="post" action="/account/serfing/add" onsubmit="return SbmForm(); return false;">
    <input type="hidden" name="ask_editcode" value="<?=$advedit?>" />
    <div class="form-group">
        <label>Заголовок рекламного блока:</label>
        <div><input name="title" type="text" maxlength="55" class="form-control" value="<?=$title?>" placeholder="Например: Отличный сайт, смотреть всем!" required></div>
    </div>
    <div class="form-group">
        <label>URL сайта:</label>
        <div><input name="url" type="url" class="form-control" value="<?=$url?>" placeholder="Например: https://yandex.ru" value="" required></div>
    </div>
    <div class="form-group">
        <label>Выберите тариф для показа:</label>
        <select name="type" id="tarif" class="form-control">
            <option value="1" <?=$selected1;?>>Тариф "Эконом"</option>
            <option value="2" <?=$selected2;?>>Тариф "Обычный"</option>
            <option value="3" <?=$selected3;?>>Тариф "Премиум"</option>
        </select>
    </div>
    <div class="checkbox checkbox-primary" style="display: none;">
        <input name="rule" value="1" id="checkbox222" type="checkbox" checked="checked" required>
        <!-- data-toggle="modal" data-target="#addsurfmodalrules" -->
        <label for="checkbox222"> Я согласен(на) с <a target="_blank" href="/rules">правилами размещения</a> рекламы на сайте. </label>
    </div>
    <div class="addsurf_fbtn">
        <?php
        if ($advedit)
        {
          ?>                             
            <!-- <span class="button-green" title="Принять изменения" onclick="SbmForm();">Сохранить</span> -->
            <button type="button" onclick="SbmForm();" class="btn btn-primary waves-effect waves-light">Сохранить</button>
          <?php
        } 
        else
        {
          ?>                            
            <!-- <span class="button-green" title="Разместить рекламу" onclick="SbmForm();">Добавить</span> -->
            <button type="button" onclick="SbmForm();" class="btn btn-primary waves-effect waves-light">Добавить сайт в сёрфинг</button>
          <?php
        } 
        ?>

        <div class="addsurf_priceform">Цена за 1000 просмотров: <span id="price">40</span> руб.</div>
    </div>
</form>
</div>
</div>


<script type='text/javascript'>

    $(document).ready(function() {

        var val = '<?=$rating?>';
        if (val == 1) {
            price = 40;
            $("#in1").addClass("in");
            $("#in2").removeClass("in");
            $("#in3").removeClass("in");

        }else if (val == 2) {
            price = 60;
            $("#in2").addClass("in");
            $("#in1").removeClass("in");
            $("#in3").removeClass("in");
        }else if (val == 3) {
            price = 80;
            $("#in3").addClass("in");
            $("#in2").removeClass("in");
            $("#in1").removeClass("in");
        }else{
            price = "Error!";
        }

    });

$('select[name=type]').change(function() { 
    var val = $(this).val();
    if (val == 1) {
        price = 40;
        $("#in1").addClass("in");
        $("#in2").removeClass("in");
        $("#in3").removeClass("in");

    }else if (val == 2) {
        price = 60;
        $("#in2").addClass("in");
        $("#in1").removeClass("in");
        $("#in3").removeClass("in");
    }else if (val == 3) {
        price = 80;
        $("#in3").addClass("in");
        $("#in2").removeClass("in");
        $("#in1").removeClass("in");
    }else{
        price = "Error!";
    }
    $("#price").text(price);
    

});

</script>

<div id="entermsg"><?php if (!empty($msg)) { echo $msg; } ?></div>

</div>

<?php 
}else{
?>

<center><h2>Сайта с таким ID нет в серфинге или Вы пытаетесь отредактировать не свой заказ!</h2></center>

</div>
<?php
}
?>