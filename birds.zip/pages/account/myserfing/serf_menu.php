<!-- Get Started -->
<center align="center">
    <a href="/account/serfing" class="btn btn-success" >Серфинг</a>
    <a href="/account/serfing/add" class="btn btn-success">Разместить ссылку</a>
    <a href="/account/serfing/cabinet" class="btn btn-success">Мои ссылки</a>
</center><br/>
<center class="p-1">
</center><br/>