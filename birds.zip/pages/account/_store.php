<?PHP

$_OPTIMIZATION["title"] = "Сбор прибыли";
$usid = $_SESSION["user_id"];
$usname = $_SESSION["user"];

$db->Query("SELECT * FROM db_users_b WHERE id = '$usid' LIMIT 1");
$user_data = $db->FetchArray();

$db->Query("SELECT * FROM db_config WHERE id = '1' LIMIT 1");
$config_site = $db->FetchArray();

$zar1 = $user_data["all_time_a"];
$zar2 = $user_data["all_time_b"];
$zar3 = $user_data["all_time_c"];
$zar4 = $user_data["all_time_d"];
$zar5 = $user_data["all_time_e"];
$zar6 = $user_data["all_time_f"];
$zar7 = $user_data["all_time_g"];
$zar8 = $user_data["all_time_h"];
$zar9 = $user_data["all_time_i"];
$zar0 = $user_data["all_time_j"];

$sum_ins = $user_data['insert_sum']+10;

$all_zar = sprintf("%.0f",$zar1+$zar2+$zar3+$zar4+$zar5+$zar6+$zar7+$zar8+$zar9+$zar0);
$sumzar =  sprintf("%.0f",$all_zar/100/$sum_ins); // процент прибавляется с каждым сбором, уменьшается с пополнением баланса

?>
<?PHP 
include("inc/_adsense.php"); 
?>
<div class="text-center" style="font-size: 120%;">
В этом разделе прибыль, можно обменять яйца и получить деньги <br/> вся прибыль 
 зачисляется на игровой счет для вывода <b><?=$config_site["percent_sell"]; ?>%</b>. монеты можно выводить <br/>
на свой реальный кошелек, либо  обменять на счет покупок и улучшить ваш заработок.</b> <br/>



<b><font data-toggle="collapse" data-target="#demo" style="cursor: pointer;"><i class="fa fa-question-circle text-info" title="Нажмите чтобы узнать..." aria-hidden="true"></i> Курс обмена</font>:  <span class="text-warning"><?=sprintf("%.0f",$config_site["items_per_coin"]) ?> яиц = 1 монета</span> | <span class="text-warning">100 монет = 1 руб.</span></b><br/> 

<div id="demo" class="m-2 card card-body collapse">
<b>Ваша активность:</b>
<small>
Сумма вашего пополнения (депозит): <b><?=$user_data['insert_sum'];?> руб.</b><br/>
Вы продали за все время всего: <b><?=$all_zar;?> яиц.</b><br/>
Прибавка к стоимости яиц (профит): <b>+<?=$sumzar;?>%</b><br/>
Ваш курс обмена: <b>+<?=sprintf("%.0f",$config_site["items_per_coin"])+$sumzar;?> яиц = 1 монета.</b><br/>
<hr>
Курс обмена можно уменьшить пополнив игровой баланс на необходимую сумму.
<hr>
Плавающий курс продажи яиц работает по следующей формуле:<br/>
<b>Курс обмена + (кол-во проданных яиц / курс обмена / (депозит + заглушка) = профит) = Итого.</b><br/>
<b class="text-danger">Наглядный пример: <?=sprintf("%.0f",$config_site["items_per_coin"]) ?> + (<?=$all_zar;?>/<?=sprintf("%.0f",$config_site["items_per_coin"]) ?>/(<?=sprintf("%.0f",+$user_data['insert_sum']) ?>+10) = <?=$sumzar;?>) = <?=sprintf("%.0f",$config_site["items_per_coin"])+$sumzar; ?></b>
</small>
</div>
</div>
<br/>
<center>
<table>
<tr>
<td>
<center class="card"><div class="card-body p-1"><b class="card-title mb-0"><?=$config_site["name_a"]; ?></b><br/><img src="/img/items/1.png" style="width: 80%;"></div><h5><div class="badge badge-info"><?=$user_data["a_t"]; ?> птиц</div></h5></center>
</td>
<td>
<center class="card"><div class="card-body p-1"><b class="card-title mb-0"><?=$config_site["name_b"]; ?></b><br/><img src="/img/items/2.png" style="width: 80%;"></div><h5><div class="badge badge-info"><?=$user_data["b_t"]; ?> птиц</div></h5></center>
</td>
<td>
<center class="card"><div class="card-body p-1"><b class="card-title mb-0"><?=$config_site["name_c"]; ?></b><br/><img src="/img/items/3.png" style="width: 80%;"></div><h5><div class="badge badge-info"><?=$user_data["c_t"]; ?> птиц</div></h5></center>
</td>
<td>
<center class="card"><div class="card-body p-1"><b class="card-title mb-0"><?=$config_site["name_d"]; ?></b><br/><img src="/img/items/4.png" style="width: 80%;"></div><h5><div class="badge badge-info"><?=$user_data["d_t"]; ?> птиц</div></h5></center>
</td>
<td>
<center class="card"><div class="card-body p-1"><b class="card-title mb-0"><?=$config_site["name_e"]; ?></b><br/><img src="/img/items/5.png" style="width: 80%;"></div><h5><div class="badge badge-info"><?=$user_data["e_t"]; ?> птиц</div></h5></center>
</td>
</tr>

<tr>
<td>
<center class="card"><div class="card-body p-1"><b class="card-title mb-0"><?=$config_site["name_f"]; ?></b><br/><img src="/img/items/6.png" style="width: 80%;"></div><h5><div class="badge badge-info"><?=$user_data["f_t"]; ?> птиц</div></h5></center>
</td>
<td>
<center class="card"><div class="card-body p-1"><b class="card-title mb-0"><?=$config_site["name_g"]; ?></b><br/><img src="/img/items/7.png" style="width: 80%;"></div><h5><div class="badge badge-info"><?=$user_data["g_t"]; ?> птиц</div></h5></center>
</td>
<td>
<center class="card"><div class="card-body p-1"><b class="card-title mb-0"><?=$config_site["name_h"]; ?></b><br/><img src="/img/items/8.png" style="width: 80%;"></div><h5><div class="badge badge-info"><?=$user_data["h_t"]; ?> птиц</div></h5></center>
</td>
<td>
<center class="card"><div class="card-body p-1"><b class="card-title mb-0"><?=$config_site["name_i"]; ?></b><br/><img src="/img/items/9.png" style="width: 80%;"></div><h5><div class="badge badge-info"><?=$user_data["i_t"]; ?> птиц</div></h5></center>
</td>
<td>
<center class="card"><div class="card-body p-1"><b class="card-title mb-0"><?=$config_site["name_j"]; ?></b><br/><img src="/img/items/0.png" style="width: 80%;"></div><h5><div class="badge badge-info"><?=$user_data["j_t"]; ?> птиц</div></h5></center>
</td>
</tr>

</table>
</center>
<center>
<hr style="max-width: 40%;">
</center>

<div class="row">

<div class="col-md-12">
<div style="margin-top: -1px;">
<?PHP

	if(isset($_POST["sbor"])){
	
		if($user_data["last_sbor"] < (time() - 600) ){
		
			$lvl1_s = $func->SumCalc($config_site["a_in_h"], $user_data["a_t"], $user_data["last_sbor"]);
			$lvl2_s = $func->SumCalc($config_site["b_in_h"], $user_data["b_t"], $user_data["last_sbor"]);
			$lvl3_s = $func->SumCalc($config_site["c_in_h"], $user_data["c_t"], $user_data["last_sbor"]);
			$lvl4_s = $func->SumCalc($config_site["d_in_h"], $user_data["d_t"], $user_data["last_sbor"]);
			$lvl5_s = $func->SumCalc($config_site["e_in_h"], $user_data["e_t"], $user_data["last_sbor"]);
			$lvl6_s = $func->SumCalc($config_site["f_in_h"], $user_data["f_t"], $user_data["last_sbor"]);
			$lvl7_s = $func->SumCalc($config_site["g_in_h"], $user_data["g_t"], $user_data["last_sbor"]);
			$lvl8_s = $func->SumCalc($config_site["h_in_h"], $user_data["h_t"], $user_data["last_sbor"]);
			$lvl9_s = $func->SumCalc($config_site["i_in_h"], $user_data["i_t"], $user_data["last_sbor"]);
			$lvl0_s = $func->SumCalc($config_site["j_in_h"], $user_data["j_t"], $user_data["last_sbor"]);
			
			$db->Query("UPDATE db_users_b SET 
			a_b = a_b + '$lvl1_s', 
			b_b = b_b + '$lvl2_s', 
			c_b = c_b + '$lvl3_s', 
			d_b = d_b + '$lvl4_s', 
			e_b = e_b + '$lvl5_s', 
			f_b = f_b + '$lvl6_s', 
			g_b = g_b + '$lvl7_s', 
			h_b = h_b + '$lvl8_s', 
			i_b = i_b + '$lvl9_s', 
			j_b = j_b + '$lvl0_s', 
			all_time_a = all_time_a + '$lvl1_s',
			all_time_b = all_time_b + '$lvl2_s',
			all_time_c = all_time_c + '$lvl3_s',
			all_time_d = all_time_d + '$lvl4_s',
			all_time_e = all_time_e + '$lvl5_s',
			all_time_f = all_time_f + '$lvl6_s',
			all_time_g = all_time_g + '$lvl7_s',
			all_time_h = all_time_h + '$lvl8_s',
			all_time_i = all_time_i + '$lvl9_s',
			all_time_j = all_time_j + '$lvl0_s',
			last_sbor = '".time()."' 
			WHERE id = '$usid' LIMIT 1");
			
			
			$db->Query("SELECT * FROM db_users_b WHERE id = '$usid' LIMIT 1");
			$user_data = $db->FetchArray();


$all_items = $user_data["a_b"] + $user_data["b_b"] + $user_data["c_b"] + $user_data["d_b"] + $user_data["e_b"] + $user_data["f_b"] + $user_data["g_b"] + $user_data["h_b"] + $user_data["i_b"] + $user_data["j_b"];

	if($all_items > 0){
			
		$money_add = $func->SellItems($all_items, $config_site["items_per_coin"]+$sumzar);

		$lvl1_b = $user_data["a_b"];
		$lvl2_b = $user_data["b_b"];
		$lvl3_b = $user_data["c_b"];
		$lvl4_b = $user_data["d_b"];
		$lvl5_b = $user_data["e_b"];
		$lvl6_b = $user_data["f_b"];
		$lvl7_b = $user_data["g_b"];
		$lvl8_b = $user_data["h_b"];
		$lvl9_b = $user_data["i_b"];
		$lvl0_b = $user_data["j_b"];
		
		
		$money_b = ( (100 - $config_site["percent_sell"]) / 100) * $money_add;
		$money_p = ( ($config_site["percent_sell"]) / 100) * $money_add;

		# Обновляем юзверя
		$db->Query("UPDATE db_users_b SET money_b = money_b + '$money_b', money_p = money_p + '$money_p', a_b = 0, b_b = 0, c_b = 0, d_b = 0, e_b = 0, f_b = 0, g_b = 0, h_b = 0, i_b = 0, j_b = 0  
		WHERE id = '$usid'");
		
		$da = time();
		$dd = $da + 60*60*24*15;
		
		# Вставляем запись в статистику
		$db->Query("INSERT INTO db_sell_items (user, user_id, a_s, b_s, c_s, d_s, e_s, f_s, g_s, h_s, i_s, j_s, amount, all_sell, date_add, date_del) VALUES 
		('$usname','$usid','$lvl1_b','$lvl2_b','$lvl3_b','$lvl4_b','$lvl5_b','$lvl6_b','$lvl7_b','$lvl8_b','$lvl9_b','$lvl0_b','$money_add','$all_items','$da','$dd')");
		
		echo "<center><div class='alert alert-success'>Собрано {$money_add} монет.</div></center>";
		
		$db->Query("SELECT * FROM db_users_b WHERE id = '$usid' LIMIT 1");
		$user_data = $db->FetchArray();
		
	}else echo "<center><div class='alert alert-danger'>Нечего собрать.</div></center>";

		}else echo "<center><div class='alert alert-danger'>10 минут не прошло!</div></center>";
	
	}


$AM = $user_data["a_t"]*$config_site["a_in_h"];
$BM = $user_data["b_t"]*$config_site["b_in_h"];
$CM = $user_data["c_t"]*$config_site["c_in_h"];
$DM = $user_data["d_t"]*$config_site["d_in_h"];
$EM = $user_data["e_t"]*$config_site["e_in_h"];
$FM = $user_data["f_t"]*$config_site["f_in_h"];
$GM = $user_data["g_t"]*$config_site["g_in_h"];
$HM = $user_data["h_t"]*$config_site["h_in_h"];
$IM = $user_data["i_t"]*$config_site["i_in_h"];
$JM = $user_data["j_t"]*$config_site["j_in_h"];
$MINING=sprintf("%.0f",$AM+$BM+$CM+$DM+$EM+$FM+$GM+$HM+$IM+$JM); 

$time = $user_data['last_sbor'];
?>

<script>
function mySbor() {
d0 = new Date('<?=date("d M Y H:i:s +3",$time);?>');
d1 = new Date();
dt = (d1.getTime() - d0.getTime()) / (1000*60*60);
var num = dt*<?=sprintf("%.0f",$MINING);?>;
document.getElementById("okay").innerHTML = num.toFixed(3);
}
setInterval(mySbor, 100); //ставим выполнение данной функции каждую Мсекунду
</script>
<h2 class="text-center">
<b class="store_km">Произведено: <font class="text-warning"><span id="okay"></span> яиц</font></b><br/>
<b class="store_km" style="font-size: 18px;">Производительность: <?=sprintf("%.0f",$MINING);?> яиц в час</b>
</h2>

<form action="" method="post" style="position: relative;">
<center><input type="submit" name="sbor" value="Собрать прибыль" class="btn btn-lg btn-danger"></center>
</form><br/>


</div></div>
</div>



<?php


$kyr1 = $user_data["a_t"]*$config_site["a_in_h"];
$kyr2 = $user_data["b_t"]*$config_site["b_in_h"];
$kyr3 = $user_data["c_t"]*$config_site["c_in_h"];
$kyr4 = $user_data["d_t"]*$config_site["d_in_h"];
$kyr5 = $user_data["e_t"]*$config_site["e_in_h"];
$kyr6 = $user_data["f_t"]*$config_site["f_in_h"];
$kyr7 = $user_data["g_t"]*$config_site["g_in_h"];
$kyr8 = $user_data["h_t"]*$config_site["h_in_h"];
$kyr9 = $user_data["i_t"]*$config_site["i_in_h"];
$kyr0 = $user_data["j_t"]*$config_site["j_in_h"];
 
$kyrcall = $kyr1+$kyr2+$kyr3+$kyr4+$kyr5+$kyr6+$kyr7+$kyr8+$kyr9+$kyr0;
$dohod =$kyrcall / 100;

?>
<style>
.trf > .col-md-3 {padding:10px 10px 5px;}
</style>

<div class="row trf" style="margin: 0px;padding: 0px 5px 0;">
<div class="col-md-3 text-center">
<div class="card card-body">
<h5 class="purple-text" style="font-weight: 500;"><b><?php echo sprintf("%.3f",$dohod/($config_site["items_per_coin"]+$sumzar));?> РУБ.</b></h5><hr style="margin:0;">Доход / час
</div>
</div>

<div class="col-md-3 text-center">
<div class="card card-body">
<h5 class="pink-text" style="font-weight: 500;"><b><?php echo sprintf("%.2f",$dohod/($config_site["items_per_coin"]+$sumzar)*24);?> РУБ.</b></h5><hr style="margin:0;"> Доход / день:
</div>
</div>

<div class="col-md-3 text-center">
<div class="card card-body">
<h5 class="red-text" style="font-weight: 500;"><b><?php echo sprintf("%.2f",$dohod/($config_site["items_per_coin"]+$sumzar)*24*7);?> РУБ.</b></h5><hr style="margin:0;"> Доход / неделя:
</div>
</div>

<div class="col-md-3 text-center">
<div class="card card-body">
<h5 class="indigo-text" style="font-weight: 500;"><b><?php echo sprintf("%.2f",$dohod/($config_site["items_per_coin"]+$sumzar)*24*30);?> РУБ.</b></h5><hr style="margin:0;"> Доход / месяц:
</div>
</div>

</div>

<?PHP 
include("inc/_adsense_b.php"); 
?>
