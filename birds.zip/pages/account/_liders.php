<?PHP
$_OPTIMIZATION["title"] = "Лидеры дня";
$usid = $_SESSION["user_id"];
$uname = $_SESSION["user"];

$um = 11;

$db->Query("SELECT * FROM db_config WHERE id = '1'");
$data_c = $db->FetchArray();
$db->FreeMemory();

# Определение платежей по акции 'Накопительный банк'
$c_date = date("Ymd",time());
$c_date_begin = strtotime($c_date." 00:00:00");
$c_date_end = strtotime($c_date." 23:59:59");

$db->Query("SELECT sum(serebro) FROM db_insert_money WHERE date_add >='".$c_date_begin."' AND  date_add <='".$c_date_end."' AND money >= '1'" );
if($db->NumRows() == 0) $sum_c = 0;
else $sum_c = $db->FetchRow();

if($sum_c == '') $sum_c = 0;
?>

<?PHP 
include("inc/_adsense.php"); 
?>
<br/>
<center style="font-size: 120%;">
Ежедневный конкурс инвесторов, все поступления суммируются в общий банк в течение дня. <br/>
Призовыми являются только три места. Они делят <font style="color:#e22;"><b>3%</b></font> от банка между собой следующим образом:<br/>
<b>1-место - выигрыш: 1.5%, 2-место - выигрыш: 1%, 3-место - выигрыш: 0.5% на покупки.</b>
</center>





<div class="alert">

<?PHP

$c_date = date("Ymd",time());
$c_date_begin = strtotime($c_date." 00:00:00");
$c_date_end = strtotime($c_date." 23:59:59");
$y_date = date("Ymd",time()-24*60*60);
$y_date_begin = strtotime($y_date." 00:00:00");
$y_date_end = strtotime($y_date." 23:59:59");

# Определение платежей по акции 'Накопительный банк'
$c_date = date("Ymd",time());
$c_date_begin = strtotime($c_date." 00:00:00");
$c_date_end = strtotime($c_date." 23:59:59");
$now = time();
$zavershenie = $c_date_end - $now;
$hours = floor($zavershenie/3600);
floor($minutes =($zavershenie/3600 - $hours)*60);
$seconds = ceil(($minutes - floor($minutes))*60);
$min=ceil($minutes)-1;

?>

<center class="m-2 p-3 bg-warning" style="border: 6px double #fff;">
<h2 class="text-center" style="color: #5f2d44;text-transform: uppercase;"><b>Сумма текущего банка <b style="color: #fff;"><?=$sum_c?></b> монет.</b></h2><hr class="my-1">
<h4 class="pb-0">Розыгрыш состоится через: <font style="color: #fff;font-weight: bold;"><span id="my_timer"><?=$hours;?>:<?=$min;?>:<?=$seconds;?> ч.</span></font></h4>
</center>
<br/>


<div class="alert stats">
<center><h5 style="margin-bottom: 5px;">УЧАСТНИКИ СЕГОДНЯШНЕГО РОЗЫГРЫША</h5></center>
<div class="table-responsive-md">
<table class='table table-bordered table-striped' align='center' width="99%">
  <tr>
	<td align="center" class="m-tb">Пользователь</td>
	<td align="center" class="m-tb">Пополнение</td>
	<td align="center" class="m-tb">Позиция</td>
	<td align="center" class="m-tb">Выигрыш</td>
  </tr>

<?php
$db->Query("SELECT user, SUM(serebro) AS serebro FROM db_insert_money WHERE date_add >='".$c_date_begin."' AND  date_add <='".$c_date_end."' GROUP BY user ORDER BY serebro DESC LIMIT 10");

if($db->NumRows() > 0){
	$i=1;
while($bon = $db->FetchArray()){
	
?>

		
	<tr class="htt">
    		<td align="center"><?=$bon["user"]; ?></td>
    		<td align="center"><?=$bon["serebro"]; ?></td>
    		<td align="center"><?=$i; ?></td>
		<td align="center"><?PHP if ($i==1) echo $sum_c*0.025; else if ($i==2) echo $sum_c*0.015; else if ($i==3) echo $sum_c*0.01; else echo "0";?></td>
  	</tr>


	<?PHP
		$i++;
		}

  
	}else echo '<tr><td align="center" colspan="5">Нет записей</td></tr>'
  ?>

</table>
</div>
</div>

<?PHP 
include("inc/_adsense_b.php"); 
?>

<div class="alert stats table-responsive-md">
<center>
	<h5 style="margin-bottom: 5px;">РЕЗУЛЬТАТЫ ПРЕДЫДУЩИХ <b>5</b> РОЗЫГРЫШЕЙ</h5>
</center>

<table class='table table-bordered table-striped' align='center' width="99%">
<tr>
	<td align="center" class="m-tb">ID</td>
	<td align="center" class="m-tb">Дата</td>	
	<td align="center" class="m-tb">Пользователь</td>
	<td align="center" class="m-tb">Банк</td>
	<td align="center" class="m-tb">Приз</td>
</tr>

<?PHP
$db->Query("SELECT a.id as id, a.sum as sum, a.bank as bank, a.date_add as date_add, b.user as user FROM db_back a LEFT OUTER JOIN db_users_a b ON b.id = a.user_id ORDER BY a.id DESC LIMIT 15");


if($db->NumRows() > 0) {
	$count = 0;
	
	while($bon = $db->FetchArray()) {
		if($count%2 == 0) {
?>
		<tr class="htt">
    		<td align="center"><?=$bon["id"]; ?></td>
    		<td align="center"><?=date("d.m.Y",$bon["date_add"]); ?></td>			
    		<td align="center"><?=$bon["user"]; ?></td>
    		<td align="center"><?=$bon["bank"]; ?></td>
		<td align="center"><?=$bon["sum"]; ?></td>
  		</tr>

<?PHP
		} else {
?>

	<tr class="htt">
    		<td align="center"><?=$bon["id"]; ?></td>
    		<td align="center"><?=date("d.m.Y",$bon["date_add"]); ?></td>			
    		<td align="center"><?=$bon["user"]; ?></td>
    		<td align="center"><?=$bon["bank"]; ?></td>
		<td align="center"><?=$bon["sum"]; ?></td>
  	</tr>

<?PHP
		}
		
		$count ++;
	}
} else echo '<tr><td align="center" colspan=5>Нет записей</td></tr>'

?>

</table>

	</div>
</div>
