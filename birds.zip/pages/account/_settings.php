<?PHP
$_OPTIMIZATION["title"] = "Настройки";
$usid = $_SESSION["user_id"];
$db->Query("SELECT * FROM db_users_a WHERE id = '$usid'");
$user_data = $db->FetchArray();
?>

<div class="row">


<div class="col-md-6">
<div class="card">
<h5 class="card-header">Смена пароля</h5>
<div class="card-body">
<?PHP

	if(isset($_POST["old"])){
 
  $old = $func->IsPassword($_POST["old"]);
  $new = $func->IsPassword($_POST["new"]);

   if($old !== false AND strtolower($old) == strtolower($user_data["pass"])){
   
    if($new !== false){
    
     if( strtolower ($new) == strtolower ($_POST["re_new"])){
     
      $db->Query("UPDATE db_users_a SET pass = '$new' WHERE id = '$usid'");
        		
        $db->Query("SELECT * FROM db_users_a WHERE id = '$usid'");
        $user_data = $db->FetchArray();
        
        # Отправляем пароль
		$sender = new isender;
		$sender -> SetNewPassword($user_data["email"], $user_data["pass"], $user_data["email"]);
                
                echo "<div class='alert alert-success'>Пароль изменен! Данные отправлены на Ваш E-mail!</div>";
     
     }else echo "<div class='alert alert-warning'>Пароль и повтор пароля не совпадают!</div>";
    
    }else echo "<div class='alert alert-danger'>Новый пароль имеет неверный формат!</div>";
   
   }else echo "<div class='alert alert-danger'>Старый пароль заполнен неверно!</div>";
  
 }

?>

<form action="" method="post" >

<div class="form-group">
	<label>Старый пароль:</label>
	<input type="password" placeholder="Введите старый пароль" name="old" class="form-control">
</div>

<div class="form-group">
	<label>Новый пароль:</label>
	<input type="password" placeholder="Новый от 6 до 20 символов" name="new" class="form-control">
</div>
    
<div class="form-group">
	<label>Повтор пароля:</label>
	<input type="password" placeholder="Повторите пароль" name="re_new" class="form-control">
</div>


	<center><input type="submit" value="Изменить данные" class="btn btn-success"></center>
</form>

</div>
</div>
</div>



<div class="col-md-6">
<div class="card">
<h5 class="card-header">Платежный пароль</h5>
<div class="card-body">
<?php
	if(isset($_POST["plat_pass"])){
	
		function plat_passs($plat_passs){
		if(!preg_match("/^[0-9]{4}$/", $plat_passs)) return false;
		     return $plat_passs;
		}
		$plat_passs = plat_passs($_POST["plat_pass"]);
		$plat = $plat_passs;
		

				if($plat_passs !== false){
									
						$db->Query("UPDATE db_users_a SET plat_pass = '$plat' WHERE id = '$usid'");
						
		
                                                echo "<div class='alert alert-success'>Платежный пароль установлен!</div>";
									
		}else echo "<div class='alert alert-danger'>Платежный пароль имеет неверный формат!</div>";

	}

?>

<?php
if($user_data['plat_pass'] != 0) {
	

	
	echo "<div class='alert alert-success'>Платежный пароль уже установлен!</div>";
}

else {
?>
<div style="max-width: 400px;margin: 0 auto;">
<form action="" method="post">
<div class="form-group">
    <label>Платежный пароль (обязательно):</label>
    <input type="text" maxlength="4" class="form-control" name="plat_pass" />
</div>
<center><input type="submit" value="Установить" class="btn btn-success btn-lg"/></center>
</form></div>
<br/>
<center>
    
</center>
<div class="alert alert-info">Платежный пароль должен состоять только из цифр и не длиннее 4-х символов!</div>

<?php } ?>

<?php

if(isset($_POST["email"])){
    
# Отправляем пароль
$sender = new isender;
$sender -> SetPayPass($user_data["email"], $user_data["plat_pass"], $user_data["email"]);

        echo "<center><div class='alert alert-success'>Данные отправлены на ваш E-mail</div></center>"; 
 }
   echo "<form action='' method='post'><input name='email' type='hidden' size='10' maxlength='10'/><center><input type='submit' value='Напомнить платежный пароль' class='btn btn-success'></center></form>";

?>
</div>
</div>
</div>


<div class="col-md-6">
<div class="card">
<h5 class="card-header">Привязка кошелька</h5>
<div class="card-body">
<?PHP
function ViewPurse($purse){
		
		if( substr($purse,0,1) != "P" ) return false;
		if( !preg_match("/^[0-9]{7,10}$/", substr($purse,1)) ) return false;	
		return $purse;
}

if(isset($_POST["payeer"])){
	
	$purse = ViewPurse($_POST["purse"]);
		if($purse !== false){
			
            $db->Query("SELECT COUNT(*) FROM db_users_a WHERE payeer = '$purse'");
			if($db->FetchRow() == 0){
	
                $db->Query("UPDATE db_users_a SET payeer = '$purse' WHERE id = '$usid'");
						
		echo "<div class='alert alert-success'>Кошелек Payeer привязан!</div>";
									
		}else echo "<div class='alert alert-danger'>Данный кошелек уже используется!</div>";

	}else echo "<div class='alert alert-danger'>Кошелек имеет неверный формат!</div>";

}
?>	

<?php
if($user_data['payeer'] != '0') {

$kosh = $user_data['payeer'];

	echo "<div class='alert alert-success'>Кошелек уже привязан! ({$kosh})</div>";
	
}else{
	
?>
<div style="max-width: 400px;margin: 0 auto;">
<form action="" method="post">
<div class="form-group">
    <label>Кошелек PAYEER (P1234567890):</label>
    <input type="text" maxlength="11" class="form-control" name="purse" />
</div>
<center><input type="submit" value="Привязать" name="payeer" class="btn btn-success"/></center>
</form></div>
<br/>
<center>
    
</center>
<div class="alert alert-info">Нет кошелька PAYEER? Заведите его <a href="https://payeer.com/01286794" target="_blank"><b>ЗДЕСЬ</b></a>!</div>

<?php } ?>

</div>
</div>
</div>


</div><br/><br/>