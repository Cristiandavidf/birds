<?PHP
$_OPTIMIZATION["title"] = "Мой аккаунт";
$user_id = $_SESSION["user_id"];
$db->Query("SELECT * FROM db_users_a, db_users_b WHERE db_users_a.id = db_users_b.id AND db_users_a.id = '$user_id'");
$prof_data = $db->FetchArray();

# Статистика дохода от рефералов 3 уровня
$db->Query("SELECT doxod2 FROM db_users_a WHERE referer_id2 = '$user_id'");
$doxod_refs2 = $db->FetchArray();
$doxod_refs2['doxod2'];

$db->Query("SELECT doxod2,doxod3 FROM db_users_a WHERE referer_id3 = '$user_id'");
$doxod_refs3 = $db->FetchArray();
$doxod_refs3['doxod3'];

$zarab_na_refax = $prof_data["from_referals"] + $doxod_refs2['doxod2'] + $doxod_refs3['doxod3']/100;

# Показывает профит в процентах
$sumzar = ($prof_data['payment_sum']*100)/$prof_data['insert_sum'];
?>
<?PHP 
include("inc/_adsense.php"); 
?>



<br/><br/>

<div class="row" style="margin: -2px -15px;">
<div class="col-lg-3 text-center">
<div class="card card-body">
<center style="margin-top: -45px;">
<div class="btn btn-lg rounded bg-success text-white p-2"><span class="fa fa-arrow-up" style="font-size: 130%;"></span></div>
</center>
<h5 class="text-success" style="font-weight: 500;"><b><?=$prof_data["insert_sum"]; ?> РУБ.</b></h5>
<small>ПОПОЛНЕНО</small>
</div>
</div>

<div class="col-lg-3 text-center">
<div class="card card-body">
<center style="margin-top: -45px;">
<div class="btn btn-lg bg-danger rounded text-white p-2"><span class="fa fa-arrow-down" style="font-size: 130%;"></span></div>
</center>
<h5 class="text-danger" style="font-weight: 500;"><b><?=sprintf("%.2f",$prof_data["payment_sum"]); ?> РУБ.</b></h5>
<small>ВЫПЛАЧЕНО</small>
</div>
</div>

<div class="col-lg-3 text-center">
<div class="card card-body">
<center style="margin-top: -45px;">
<div class="btn btn-lg bg-warning rounded text-white p-2"><span class="fa fa-users" style="font-size: 130%;"></span></div>
</center>
<h5 class="text-warning" style="font-weight: 500;"><b><?=sprintf("%.2f",$zarab_na_refax/100); ?> РУБ.</b></h5>
<small>РЕФ-ДОХОД</small>
</div>
</div>

<div class="col-lg-3 text-center">
<div class="card card-body">
<center style="margin-top: -45px;">
<div class="btn btn-lg bg-primary rounded text-white p-2"><span class="fa fa-bank" style="font-size: 130%;"></span></div>
</center>
<h5 class="text-primary" style="font-weight: 500;"><b><?=sprintf("%.0f",$sumzar); ?>%</b></h5>
<small>ПРОФИТ</small>
</div>
</div>


</div>

<div class="card card-body"><h4 class="card-title">Информация по вашему аккаунту</h4>

<div class="row" style="margin-left: -17px;margin-right: -17px;">
<div class="col-lg-12 col-xl-6"><ul class="list-group bg-light m-2">
    <li class="list-group-item">Баланс для покупок <span class="pull-right"><b><?=sprintf("%.0f",$prof_data["money_b"]); ?> монет</b></span></li>
    <li class="list-group-item">Баланс на вывод <span class="pull-right"><b><?=sprintf("%.0f",$prof_data["money_p"]); ?> монет</b></span></li>
    <li class="list-group-item">Пополнено <span class="pull-right text-primary"><b><a href="/insert"><?=$prof_data["insert_sum"]; ?> руб.</a></b></span></li>
    <li class="list-group-item">Выплачено всего <span class="pull-right text-primary"><b><a href="/withdrawals"><?=$prof_data["payment_sum"]; ?> руб.</a></b></span></li>
    <li class="list-group-item">Доход от рефералов <span class="pull-right"><b><a href="/referrals"><?=sprintf("%.2f",$zarab_na_refax/100); ?> руб.</a></b></span></li>
    <li class="list-group-item">Ваших рефералов <span class="pull-right"><b><?=$prof_data["referals"]; ?> чел.</b></span></li>
  </ul></div><!-- Статистика -->

<div class="col-lg-12 col-xl-6"><ul class="list-group bg-light m-2">
    <li class="list-group-item">Ваш ID <span class="pull-right"><b><?=$prof_data["id"]; ?></b></span></li>
    <li class="list-group-item">Ваш логин <span class="pull-right"><b><?=$prof_data["user"]; ?></b></span></li>
    <li class="list-group-item">Email <span class="pull-right"><b><?=$prof_data["email"]; ?></b></span></li>
    <li class="list-group-item">Дата регистрации <span class="pull-right"><b><?=date("d/m/Y в H:i",$prof_data["date_reg"]); ?></b></span></li>
    <li class="list-group-item">Кто пригласил(REFERER) <span class="pull-right"><b><?=$prof_data["referer"]; ?></b></span></li>
  </ul></div><!-- Данные -->
</div>

</div>




<div class="mt-3 card card-body bg-light"><h4><b>Ваша партнерская ссылка:</b> <input type="text" onclick="this.select()" class="text-primary" style="margin-top: 0;background: none !important;font-size: 110%;border:0;display:inline-block !important;min-width: 390px;" value="https://<?=$_SERVER['HTTP_HOST']; ?>/?i=<?=$_SESSION["user_id"]; ?>"> </h4><hr>
<p>Приглашайте рефералов и получайте от их пополнений 7%, 5%, 2% на баланс для вывода!<br/>
А также за каждого реферала получаете птицу которая будет приносить 6 яиц в час.</p>
</div>
<br/>
<?PHP 
include("inc/_adsense_b.php"); 
?>