<?PHP
$_OPTIMIZATION["title"] = "Пополнить баланс";
$usid = $_SESSION["user_id"];
$usname = $_SESSION["user"];

$db->Query("SELECT * FROM db_config WHERE id = '1' LIMIT 1");
$sonfig_site = $db->FetchArray();

/*
if($_SESSION["user_id"] != 1){
echo "<center><b><font color = red>Технические работы</font></b></center>";
return;
}
*/

# Free-kassa
$fk_merchant_id = $config->free_id; //merchant_id
$fk_merchant_key = $config->free_key; //Секретное слово

/// db_payeer_insert
if(isset($_POST["sum"])){

$sum = round(floatval($_POST["sum"]),2);


# Заносим в БД
$db->Query("INSERT INTO db_payeer_insert (user_id, user, sum, date_add) VALUES ('".$_SESSION["user_id"]."','".$_SESSION["user"]."','$sum','".time()."')");

$desc = base64_encode($_SERVER["HTTP_HOST"]." - USER ".$_SESSION["user"]);
$m_shop = $config->shopID;
$m_orderid = $db->LastInsert();
$m_amount = number_format($sum, 2, ".", "");
$m_curr = "RUB";
$m_desc = $desc;
$m_key = $config->secretW;

$arHash = array(
 $m_shop,
 $m_orderid,
 $m_amount,
 $m_curr,
 $m_desc,
 $m_key
);
$sign = strtoupper(hash('sha256', implode(":", $arHash)));

?>
<center>
<form method="GET" action="//payeer.com/api/merchant/m.php"><br/><br/><br/>
	<input type="hidden" name="m_shop" value="<?=$config->shopID; ?>">
	<input type="hidden" name="m_orderid" value="<?=$m_orderid; ?>">
	<input type="hidden" name="m_amount" value="<?=number_format($sum, 2, ".", "")?>">
	<input type="hidden" name="m_curr" value="RUB">
	<input type="hidden" name="m_desc" value="<?=$desc; ?>">
	<input type="hidden" name="m_sign" value="<?=$sign; ?>">
	<input type="submit" name="m_process" value="Перейти и оплатить" class="btn btn-success btn-lg" />
</form><br/><br/><br/><hr><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>
</center>
<?PHP

return;
}
?>

<script type="text/javascript">
var min = 1;
var ser_pr = 100;
function calculate(st_q) {
	
	var sum_insert = parseFloat(st_q);
	$('#res_sum').html( (sum_insert * ser_pr).toFixed(0) );

	var re = /[^0-9\.]/gi;
    var url = window.location.href;
    var desc = '<?=$usid;?>';
    var sum = $('#sum').val();
    if (re.test(sum)) {
        sum = sum.replace(re, '');
        $('#oa').val(sum);
    }
    if (sum < min) {
        $('#error').html('Минимальная сумма пополнения - 1 рублей! ');
		$('#submit').attr("disabled", "disabled");
        return false;
    } else {
        $('#error').html('');
    }

    $.get('/free-kassa-data.php?prepare_once=1&l='+desc+'&oa='+sum, function(data) {
         var re_anwer = /<hash>([0-9a-z]+)<\/hash>/gi;
         $('#s').val(re_anwer.exec(data)[1]);
         $('#submit').removeAttr("disabled");
    });
}
	
</script>
<?PHP 
include("inc/_adsense.php"); 
?>

<center><h4>Бонусы при пополнении игрового баланса:</h4>
<p><small>У вас есть уникальная возможность забрать выгодный бонус за первое пополнение и последующие.</small></p>
<div class="row text-center" style="font-size: 120%;">
	<div class="col-lg-3 col-md-6">
	<div class="card">
<h1 class="bg-danger text-white" style="border: 4px double #fff;"><b>+<?=$sonfig_site["bon_0"]*100; ?>%</b></h1>
<small class="pb-3 pt-2">При первом пополнении</small>
	</div>
	</div>

	<div class="col-lg-3 col-md-6">
	<div class="card">
<h1 class="bg-success text-white" style="border: 4px double #fff;"><b>+<?=$sonfig_site["bon_3"]*100; ?>%</b></h1>
<small class="pb-3 pt-2">При пополнении от <?=$sonfig_site["sum_3"]+0.01; ?>Р</small>
	</div>
	</div>

	<div class="col-lg-3 col-md-6">
	<div class="card">
<h1 class="bg-success text-white" style="border: 4px double #fff;"><b>+<?=$sonfig_site["bon_2"]*100; ?>%</b></h1>
<small class="pb-3 pt-2">При пополнении от <?=$sonfig_site["sum_2"]+0.01; ?>Р</small>
	</div>
	</div>

	<div class="col-lg-3 col-md-6">
	<div class="card">
<h1 class="bg-success text-white" style="border: 4px double #fff;"><b>+<?=$sonfig_site["bon_1"]*100; ?>%</b></h1>
<small class="pb-3 pt-2">При пополнении от <?=$sonfig_site["sum_1"]+0.01; ?>Р</small>
	</div>
	</div>
</div>
</center>

<center>
<div id="error3"></div>
<div class="row">
<div class="col-md-6">
<div class="card"><div class="card-body">
<img src="/img/payeer.png" style="height: 80px;">
<form method="POST" action="" style="width: 300px;">
    <input type="hidden" name="m" value="<?=$fk_merchant_id?>">
		<label>Пополнить на сумму:</label>
<div class="input-group">
		<input type="text" value="10" name="sum" size="7" id="psevdo" onchange="calculate(this.value)" onkeyup="calculate(this.value)" onfocusout="calculate(this.value)" onactivate="calculate(this.value)" ondeactivate="calculate(this.value)" class="form-control" style="margin-top: 0;">
	<div class="input-group-prepend">
	<span class="input-group-text">RUB</span>
	</div>
</div><br/>
    <input type="submit" id="submit" value="Пополнить баланс" class="btn btn-success btn-lg">
</form></div>

<div class="card-footer"><b>Доступно:</b>
Payeer, AdvCash, Visa, MasterCard, Maestro, Mir, Bitcoin, MTS, Beeline, Tele2, Megafon, Альфабанк, Связной и Евросеть.
</div>

</div>
</div>

<div class="col-md-6">
<div class="card"><div class="card-body">
<img src="/img/free.png" style="height: 80px;">

<form method=GET action="http://www.free-kassa.ru/merchant/cash.php" style="width: 300px;">
    <input type="hidden" name="m" value="<?=$fk_merchant_id?>">
<label>Пополнить на сумму:</label>
<div class="input-group">
  <input type="text" name="oa" id="sum" value="10" size="7" id="oa" onchange="calculate(this.value)" onkeyup="calculate(this.value)" onfocusout="calculate(this.value)" onactivate="calculate(this.value)" ondeactivate="calculate(this.value)" class="form-control" style="margin-top: 0;">
	<div class="input-group-prepend">
	<span class="input-group-text">RUB</span>
	</div>
</div>
	<input type="hidden" name="s" id="s" value="0">
	<input type="hidden" name="us_id" id="us_id" value="<?=$usid;?>">
    <br>
    <input type="hidden" name="o" id="desc" value="<?=$usid;?>" />
    <input type="submit" id="submit" value="Пополнить баланс" class="btn btn-success btn-lg">
</form>
</div>
<div class="card-footer"><b>Доступно:</b>
Яндекс.Деньги, Qiwi, Visa, PerfectMoney, Операторы связи, Bitcoin, Monero, Litecoin, Ethereum, Dogecoin и другие криптовалюты..
</div>
</div>
</div>
</div>

</center>
<center>
<div class="mt-2 mb-1" style="text-transform:uppercase;font-size: 26px;">Вы получите: <span style="color: #e33;font-weight: bold;" id="res_sum">1000</span> монет <b>+БОНУС</b>.</div>
<p class="bg-warning p-2 text-white">Курс игровой валюты: <b>100 монет = 1 RUB</b></p>

<hr>

<p> Ввод средств позволяет автоматически пополнить игровой баланс с помощью различных платежных <br/>
систем:<b> Payeer, QIWI, Яндекс, Bitcoin, Advcash, OKPAY, МТС, Мегафон, Билайн, Банковских карт</b> и т.д. </p>
</center>

<script type="text/javascript">
calculate(10);
</script>

