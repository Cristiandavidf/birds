<?PHP
$_OPTIMIZATION["title"] = " Заказ выплаты";
$user_id = $_SESSION["user_id"];
$usname = $_SESSION["user"];

$db->Query("SELECT * FROM db_users_b WHERE id = '$user_id' LIMIT 1");
$user_data = $db->FetchArray();

$db->Query("SELECT * FROM db_users_a WHERE id = '$usid' LIMIT 1");
$user_date = $db->FetchArray();

$db->Query("SELECT * FROM db_config WHERE id = '1' LIMIT 1");
$config_site = $db->FetchArray();

$status_array = array( 0 => "Проверяется", 1 => "Выплачивается", 2 => "Отменена", 3 => "Выплачено");

# Минималка серебром
$minPay = 100;

# Максималка серебром
$maxPay = 150000;

/*if($user_id != '1'){
	echo '<center><b><font color = "red">Ведутся технические работы</font></b></center><BR />';
	return;
}*/

?>
<?PHP 
include("inc/_adsense.php"); 
?><br/>
<?php

$interval = 24; // 24 - интервал времени в часах
$max_sum = 2500;// 100 - максимальная сумма, за указанный интервал времени $interval
$time = time() - 60*60*$interval;
$db->Query("SELECT SUM(sum) FROM db_payment WHERE user_id = '$user_id' AND date_add > '$time'");
$sum = $db->FetchRow();
if($sum > $max_sum){?> 

<p class="alert alert-warning">Максимальная сумма выплаты в сутки для вас составляет: <?=$max_sum;?> руб.<br>
За прошедшие <?=$interval ;?> часа Вам выплачено <span class="badge badge-success"><?=$sum;?></span> руб.<br>
Лимит составляет для вывода 10% от суммы пополнения в день!<br/>
Следующая выплата будет доступна завтра! Либо пополните баланс и лимит будет увеличен.</p>
<?PHP
return;
}
?>
<?PHP

$ddel = time() + 60*60*8;
$dadd = time();

# Заносим выплату
if(isset($_POST['swap'])){ // проверка: была ли отправлена форма


		$plat = intval($_POST["plat"]);

 if($plat == $user_date["plat_pass"]){

	if(!empty($_POST['purse'])){
		$ps = Array(
		'Payeer'=>'1136053',
		'QIWI'=>'26808',
		'ЯндексДеньги'=>'57378077',
		'Билайн'=>'24898938',
		'Мегафон'=>'24899391',
		'МТС'=>'24899291',
		'ТЕЛЕ2'=>'95877310',
		'VISA' =>'117146509',
		'MASTERCARD' =>'57644634',
		'MAESTRO' =>'57766314'
		);
		$ps = $ps[$_POST['ps']];
		if(!empty($ps)){
			if($_POST['ps'] == 'Payeer'){
				function ViewPurse($purse){
					if( substr($purse,0,1) != "P" ) return false;
					if( !preg_match("#^[0-9]{7,11}$#", substr($purse,1)) ) return false;	
					return $purse;
				}
			}
			if($_POST['ps'] == 'ЯндексДеньги'){
				function ViewPurse($purse){
					if( !preg_match("#^41001[0-9]{7,10}$#",$purse) ) return false;
					return $purse;
				}
				$minPay = '1000';
			}
			if($_POST['ps'] == 'QIWI'){
				function ViewPurse($purse){
					if( !preg_match("#^\+(91|994|82|372|375|374|44|998|972|66|90|81|1|507|7|77|380|371|370|996|9955|992|373|84)[0-9]{6,14}$#",$purse) ) return false;
					return $purse;
				}
				$minPay = '1000';
			}
			if(isset($_POST['phone']) && $_POST['ps'] != 'QIWI'){
				function ViewPurse($purse){
					if( !preg_match("#^[\+]{1}[7]{1}[9]{1}[\d]{9}$#",$purse) ) return false;
					return $purse;
				}
				$minPay = '1000';
			}
			
			if($_POST['ps'] == 'VISA'){
				function ViewPurse($purse){
					if(!preg_match("#^([45]{1}[\d]{15}|[6]{1}[\d]{17})$#",$purse)) return false;
					return $purse;
				}
			}
			if($_POST['ps'] == 'MASTERCARD'){
				function ViewPurse($purse){
					if( !preg_match("#^([45]{1}[\d]{15}|[6]{1}[\d]{17})$#",$purse) ) return false;
					return $purse;
				}
				
			}
			if($_POST['ps'] == 'MAESTRO'){
				function ViewPurse($purse){
					if( !preg_match("#^([45]{1}[\d]{15}|[6]{1}[\d]{15,17})$#",$purse) ) return false;
					return $purse;
				}
				
			}
			if(isset($_POST['card'])){
				$minPay = '950';
				function ViewPerson($person){
					if( !preg_match("#^([a-zA-ZА-Яабвгдеёжзийклмнопрстуфхцчшщьыъэюя\.\-\' ]+)$#",$person) ) return false;
					return $person;
				}
				$person = ViewPerson($_POST['person']);
			}

# Проверка на дату выплаты
$db->Query("SELECT COUNT(*) FROM db_payment WHERE user_id = '$usid' AND date_add > '$dadd'");

 if($db->FetchRow() == 0){

			$purse = ViewPurse($_POST['purse']);
			if($purse != false){
			if((!empty($person) AND $person != false) OR !isset($person)){
				$sum = round(intval($_POST['sum']),2);
				$val = 'RUB';

			if ($sum <= $maxPay){

				if($sum >= $minPay){

					if($sum <= $user_data['money_p']){

					# Проверяем на существующие заявки
						$db->Query("SELECT COUNT(*) FROM db_payment WHERE user_id = '$user_id' AND (status = '0' OR status = '1')");
						if($db->FetchRow() == 0){

							$sum_pay = round( ($sum / $config_site['ser_per_wmr']), 2);
							if($user_data["insert_sum"] >= 10){
							# Делаем выплату
								$payeer = new rfs_payeer($config->AccountNumber, $config->apiId, $config->apiKey);
								if ($payeer->isAuth()){
									$arBalance = $payeer->getBalance();
									if($arBalance['auth_error'] == 0){
										$balance = $arBalance['balance']['RUB']['DOSTUPNO'];
										if($balance >= $sum_pay){
											$array = array(
												'action' => 'output',
												'ps' => $ps,
												'curIn' => $val, // счет списания
												'sumOut' => $sum_pay, // сумма получения
												'curOut' => $val, // валюта получения
												'param_ACCOUNT_NUMBER' => $purse // получатель
											);
											if(!empty($person)){
												$array['param_CONTACT_PERSON'] = $person;
											}
											$initOutput = $payeer->initOutput($array);
											if ($initOutput){
												$historyId = $payeer->output();
													if ($historyId > 0){
													# Снимаем с пользователя
														$db->Query("UPDATE db_users_b SET money_p = money_p - '$sum', payment_sum = payment_sum + '$sum_pay', pay_points = pay_points - '$sum_pay' WHERE id = '$user_id'");
														
														# Вставляем запись в выплаты
														$da = time();
														$dd = $da + 60*60*24*15;
														
														$ppid = $arTransfer["historyId"];
															
														$db->Query("INSERT INTO db_payment (user, user_id, purse, sum, valuta, serebro, pay_sys_id, payment_id, date_add, status) VALUES ('$usname','$user_id','$purse','$sum_pay','RUB', '$sum', '$ps', '$ppid','".time()."', '3')");
															
														$db->Query("UPDATE db_stats SET all_payments = all_payments + '$sum_pay' WHERE id = '1'");
														echo "<center><font color = 'green'><b>Выплата прошла! Пожалуйста оставьте отзыв о проекте.</b></font></center><BR />";
														$db->Query("SELECT * FROM db_users_b WHERE id = '$user_id' LIMIT 1");
														$user_data = $db->FetchArray();
													}else{
														echo '<center><font color = "red"><b>Ошибка ['.print_r($payeer->getErrors(), true).'] - попробуйте через  20-30 секунд или сообщите о ней администратору!</b></font></center><BR />';
													}
											}else{
												echo '<center><font color = "red"><b>Ошибка ['.print_r($payeer->getErrors(), true).'] - попробуйте через 20-30 секунд или сообщите о ней администратору!</b></font></center><BR />';
											}
										}else echo '<center><font color = "red"><b>Ошибка платежной системы - попробуйте чуть позже, или сообщите о ней администратору.</b></font></center><BR />';
									}else echo '<center><font color = "red"><b>Ошибка системы! Попробуйте позже.</b></font></center><BR />';
								}else echo '<center><font color = "red"><b>Ошибка платежного шлюза! Попробуйте позже.</b></font></center><BR />';
    						}else echo '<center><font color = "red"><b>Выплату могут заказывать пользователи пополнившие на сумму от 10 руб.</b></font></center><BR />';
						}else echo '<center><font color = "red"><b>У вас имеются необработанные заявки. Дождитесь их выполнения.</b></font></center><BR />';
					}else echo '<center><font color = "red"><b>Вы указали больше, чем имеется на вашем счету.</b></font></center><BR />';
				}else echo '<center><b><font color = "red">Минимальная сумма для выплаты составляет '.$minPay.' монет!</font></b></center><BR />';
		}else echo '<center class="alert alert-danger"><b>Вы не можете выплатить более '.$maxPay.' монет за один раз!</b></center><BR />';
				}else echo '<center><b><font color = "red">Данные держателя карты указаны неверно!</font></b></center><BR />';
			}else echo '<center><b><font color = "red">Номер счета '.$purse.' указан неверно</font></b></center><BR />';

	}else echo '<center class="alert alert-danger"><b>Выплаты можно совершать не чаще чем 1 раз в 8 часов</b></center><BR />';
	
		}else echo '<center><b><font color = "red">Платежная система не указана!</font></b></center><BR />';
	}else echo '<center class="alert alert-danger"><b>Вы не ввели номер кошелька</b></center><BR />';
}else echo '<center><b><font color="red">Не верно указан Платежный пароль!</font></b></center><BR />';
}
?>



<div class="row">
<div class="col-lg-4">
<style>
.selectPS{
	display: inline-block;
	width: 120px;
	vertical-align: top;
	text-align: center;
	padding: 2px 5px;
	margin: 3px 2px;
	text-transform: uppercase;
	border-radius: 4px;
	background: #fff;
	border: 1px solid #f2f3f4;
	cursor: pointer;
	font-size: 12pt;
}
.selectPS:hover{
	background: #f2f3f4;
}
.selectPS .imagesps{
	width: 55px;
	box-sizing: border-box;
	height: 55px;margin: 0 auto;
	display: block;
}
.table td {
	padding: 5px;border: 0;
}
</style>
<script type="text/javascript">
function addfield(ps,name){
	var el = document.getElementById('new');
	var el1 = document.getElementById('new1');
	var el2 = document.getElementById('new2');
	var el3 = document.getElementById('new3');
	if(el){el.parentNode.removeChild(el);}
	if(el1){el1.parentNode.removeChild(el1);}
	if(el2){el2.parentNode.removeChild(el2);}
	if(el3){el3.parentNode.removeChild(el3);}
	if(ps == 'phone'){
		var newTd = document.createElement('td');
		newTd['id'] = 'new';
		newTd.innerHTML = '<label>Номер телефона '+name+':</label>';
		paysys.insertBefore(newTd, paysys.children[0]);
		var newTd = document.createElement('td');
		newTd['id'] = 'new1';
		newTd.innerHTML = '<input class="form-control" style="margin: 2px 0;" type="text" name="purse" size="15"><input type="hidden" name="ps" value="'+name+'"><input type="hidden" name="phone">';
		paysys.insertBefore(newTd, paysys.children[1]);
		min = 1000;
		document.getElementById('str_min').style.display = 'block';
		document.getElementById('min').innerHTML = min;
		document.getElementById('name_ps').innerHTML = name;
	}
	if(ps == 'eps'){
		var newTd = document.createElement('td');
		newTd['id'] = 'new';
		newTd.innerHTML = '<label>Номер счета '+name+':</label>';
		paysys.insertBefore(newTd, paysys.children[0]);
		var newTd = document.createElement('td');
		newTd['id'] = 'new1';
		newTd.innerHTML = '<input type="text" class="form-control" style="margin: 2px 0;" name="purse" size="15"><input type="hidden" name="ps" value="'+name+'">';
		paysys.insertBefore(newTd, paysys.children[1]);
		min = <?=$minPay;?>;
		if(name == 'ЯндексДеньги'){min = 1000;}
		document.getElementById('str_min').style.display = 'block';
		document.getElementById('min').innerHTML = min;
		document.getElementById('name_ps').innerHTML = name;
	}	
	if(ps == 'card'){
		var newTd = document.createElement('td');
		newTd['id'] = 'new';
		newTd.innerHTML = '<label>Номер карты '+name+':</label>';
		paysys.insertBefore(newTd, paysys.children[0]);
		var newTd = document.createElement('td');
		newTd['id'] = 'new1';
		newTd.innerHTML = '<input type="text" class="form-control" name="purse" size="15"><input type="hidden" name="ps" value="'+name+'"><input type="hidden" name="card">';
		paysys.insertBefore(newTd, paysys.children[1]);
		var newTd = document.createElement('td');
		newTd['id'] = 'new2';
		newTd.innerHTML = '<label>Имя, Фамилия держателя:</label>';
		person.insertBefore(newTd, person.children[0]);
		var newTd = document.createElement('td');
		newTd['id'] = 'new3';
		newTd.innerHTML = '<input class="form-control" style="margin: 2px 0;" type="text" name="person" size="15">';
		person.insertBefore(newTd, person.children[1]);
		min = 65000;
		document.getElementById('str_min').style.display = 'block';
		document.getElementById('min').innerHTML = min;
		document.getElementById('name_ps').innerHTML = name;
	}
}
</script>
    <div class="ale1rt bg1-light" align="center" style="padding: 0;margin: 0 auto;">

                            <div class="selectPS" >
                            <div class="imagesps" style="background: url(/img/ps/payeer.png) no-repeat 50%;" onclick="addfield('eps','Payeer');"></div>
                            Payeer
                    </div>
                            <div class="selectPS" >
                            <div class="imagesps" style="background: url(/img/ps/qiwi.png) no-repeat 50%;" onclick="addfield('phone','QIWI');"></div>
                            QIWI
                    </div>
                            <div class="selectPS">
                            <div class="imagesps" style="background: url(/img/ps/yandex.png) no-repeat 50%;" onclick="addfield('eps','ЯндексДеньги');"></div>
                            Яндекс
                    </div>
                            
    </div>
<br/>
</div>
<div class="col-lg-8">
<?

# Заглушка от халявщиков
if($user_data["insert_sum"] >=0){

?>
<?php
# Платежный пароль
if ($user_date["plat_pass"] == 0){
?>
<div class="alert alert-info">Укажите в <b><a href="/settings"><font color="red">настройках</font></a></b> платежный пароль!</div>
<?php
} elseif ($user_date["payeer"] == '0'){
?>
<div class="alert alert-info">Привяжите в <b><a href="/settings"><font color="red">настройках</font></a></b> кошелек PAYEER!</div>
<?php
} else{
?>

<div class="card">
<div id="str_min" class="card-header" style="display:none;">Минимальная сумма выплаты на <b><span id="name_ps"></span></b> составляет <span id="min"></span> монет.</div>
<form action="" method="post">
<div class="card-body">
<table id="pay" class="table" style="max-width: 700px;margin: 0 auto;" border="0">
  <tr style="border: 0;" align="left" id="paysys"></tr>
  <tr align="left" id="person"></tr>
  <tr align="left">
    <td><label>Сумма для вывода:</label> </td>
	<td><div class="input-group" style="max-width: 170px;"><input class="form-control" type="text" style="margin-top: 0;" name="sum" id="sum" value="<?=round($user_data['money_p']); ?>" size="15"><div class="input-group-prepend">
	<span class="input-group-text">монет</span>
	</div></div></td>
  </tr>
  <tr align="left">
    <td><label>Платежный пароль:</label></td>
	<td><div class="form-group" style="max-width: 170px;"><input class="form-control" type="text" style="margin-top: 0;" name="plat" value="" size="15"></div></td>
  </tr>
</table><center><p style="margin-bottom: 10px;font-size: 16px;text-transform: uppercase;">Курс игровой валюты: <font color="#e55">100 монет = 1 РУБ!</font></p></center></div>
<div class="card-footer text-center">
	<input class="btn btn-danger btn-lg" type="submit" name="swap" value="Заказать выплату" />
</form></div>
</div>


<?php } ?>
<?$minPay = '';?>
</div>
</div>

<center class="card-header"><b>Последние 10 выплат</b></center>
<table class="table table-bordered table-striped">
<thead>
	<td align="center" class="m-tb">Монет</td>
	<td align="center" class="m-tb">Сумма</td>
	<td align="center" class="m-tb">Система</td>
	<td align="center" class="m-tb">Кошелек</td>
	<td align="center" class="m-tb">Дата</td>
	<td align="center" class="m-tb">Статус</td>
</thead>
  <?PHP
  
  $db->Query("SELECT * FROM db_payment WHERE user_id = '$user_id' ORDER BY id DESC LIMIT 10");
  
	if($db->NumRows() > 0){
	$img = Array(
		'1136053'=>'payeer',
		'26808'=>'qiwi',
		'57378077'=>'yandex',
		'24898938'=>'beeline',
		'24899391'=>'megafon',
		'24899291'=>'mts',
		'95877310'=>'tele2',
		'117146509' =>'visa',
		'57644634' =>'master',
		'57766314' =>'maestro'
		);
  		while($ref = $db->FetchArray()){
		
		?>
	<tr class="htt">
    		<td align="center"><?=$ref["serebro"]; ?></td>
    		<td align="center"><?=sprintf("%.2f",$ref["sum"] - $ref["comission"]); ?> <?=$ref["valuta"]; ?></td>
		<td align="center"><? if(!empty($ref["pay_sys_id"])){echo '<img src="/img/ps/'.$img[$ref["pay_sys_id"]].'.png" width="25px">';}?></td>
    		<td align="center"><?=$ref["purse"]; ?></td>
		<td align="center"><?=date("d.m.Y",$ref["date_add"]); ?></td>
    		<td align="center"><?=$status_array[$ref["status"]]; ?></td>
  	</tr>
		<?PHP
		
		}
  
	}else echo '<tr><td align="center" colspan="6">Нет записей</td></tr>'
  
  ?>
</table>
<?PHP

return;
}

?>

<center class="bg-danger text-light p-2">
<b>ВЫ НЕ МОЖЕТЕ ЗАКАЗАТЬ ВЫПЛАТУ!</b><br/>
<small>ДЛЯ ЗАКАЗА ВЫПЛАТ НЕОБХОДИМО <a href="/insert" class="text-warning"><b>ПОПОЛНИТЬ БАЛАНС</b></a> НА ОБЩУЮ СУММУ 50 РУБЛЕЙ!<BR />
ПОСЛЕ ЭТОГО МОЖНО ВЫВОДИТЬ БЕЗ ОГРАНИЧЕНИЙ И ЛИМИТОВ.</small></center>
</div></div>