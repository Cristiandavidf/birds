<?PHP
$_OPTIMIZATION["title"] = "Ошибка";
$_OPTIMIZATION["description"] = "Указанная страница отсутствует на сервере";
$_OPTIMIZATION["keywords"] = "Ошибка, error, 404, Not Found";
?>
<!-- Get Started -->
<div class="main">
	<div class="card card-body">
		<h2>Страница не существует</h2>
		<p>Ошибка 404</p>
	</div>
	<p>
<a href="/" class="btn btn-outline-primary btn-lg">Главная страница</a>
	</p>
</div>
