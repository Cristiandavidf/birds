<?PHP
$_OPTIMIZATION["title"] = "Поддержка";
$_OPTIMIZATION["description"] = "Связь с администрацией";
$_OPTIMIZATION["keywords"] = "Связь с администрацией проекта";
?>

<div class="title">
        <h3>ТЕХНИЧЕСКАЯ ПОДДЕРЖКА</h3>
<p>Для решения проблем, по-поводу сотрудничества и других вопросов.<br/>
Наша поддержка, круглосуточно готова вам помочь если вам что то не понятно или по другим вопросам. 
</p>
    </div>
<br/>
 
<div class="container">
	<div class="row">
<div class="col-md-3">

</div>
<div class="col-md-6">
<center class="card">
<center><img style="width: 158px;margin-top: 20px;" src="/img/email.png"></center>
<h3><?=$config->SUPPORT;?></h3>
<p>E-mail поддержка:</p>
</center>
</div>

<div class="col-md-3">

</div>

	</div>
</div><br/>
<?PHP 
include("inc/_adsense_b.php"); 
?>

<br/><br/><br/><br/><br/><br/><br/><br/>
