<?PHP

$eid = intval($_GET["id"]);
$db->Query("SELECT * FROM db_blogs WHERE id = '$eid' LIMIT 1");
$news = $db->FetchArray();

$_OPTIMIZATION["title"] = "Блоги";
$_OPTIMIZATION["description"] = "Блоги на нашем проекте, также интересные статьи по заработку";
$_OPTIMIZATION["keywords"] = "новости заработка, блоги, обзоры, информация";
$usid = $_SESSION["user_id"];
$usname = $_SESSION["user"];
$date = time();
$db->Query("SELECT * FROM db_users_b WHERE id = '$usid' LIMIT 1");
$user_data = $db->FetchArray();
?>

<div class="title">
	<h3>Интересные статьи</h3>
<p style="position: relative;z-index: 99;font-size: 120%;">
Здесь вы найдете любую интересующую информацию о заработке в интернете, а также полезные статьи.
</p>
</div>

<?PHP
	include("inc/_adsense.php");
?>


<div class="container">

<?
############### Новость + комменты
if (isset($_GET['id'])) {

$_OPTIMIZATION["title"] = $news["title"];

$eid = intval($_GET["id"]);

$db->Query("SELECT * FROM db_blogs WHERE id = '$eid' LIMIT 1");

# Проверяем на существование
if($db->NumRows() != 1){ echo "<center><b>Указанная статья не найдена</b></center><BR />"; }
$newcom = $db->FetchArray();
?>

<div class="card bg-light">
<h3 class="card-header"><?=$newcom["title"]; ?> - <small><strong><?=date("d.m.Y",$newcom["date_add"]); ?></strong></small></h3>
<div class="card-body"><?=$newcom["news"]; ?></div>
</div>

<div style="margin-top:10px;"> </div>
<center><font color="green" size="+1"><b>Комментарии:</b></font></center>
<div style="margin-top:20px;"> </div>

<script language="JavaScript">
function show(obj) {
if (document.getElementById(obj).style.display == 'none')
document.getElementById(obj).style.display = 'block';
else document.getElementById(obj).style.display = 'none';
}
</script>

<?php
if(!isset($_SESSION["user"])) {
    echo '';
} else {?>

<center>
<span onclick="show('1')"><a onclick="return false"><button class="btn btn-success" type="button">Оставить комментарий к данной новости</button></a></span><br />
</center><br />
<span class="sub" id="1" style="display: none;">
<?php
if(isset($_POST['comment'])) {

$com = $db->RealEscape($_POST['comment']);//Фильтрация


$db->Query("SELECT * FROM db_blogs_com WHERE user_id = '$usid' AND news_id='$eid'");
    if(!empty($com)) {
    $en = 10;
    if($en <= $user_data["money_b"]){
        if($db->NumRows() <= 0) {
        if(strlen($text) > 100 or $text == "") {
$db->Query("INSERT INTO db_blogs_com (user_id, login, date, text, news_id) VALUES ('$usid', '$usname', '$date', '$com', '$eid')");
        $db->Query("UPDATE db_users_b SET money_p = money_p - 10 WHERE id = '$usid'");
        $ms = '<center><font color="green">Комментарий успешно оставлен!</font></center>';
       
           }else echo "<center><font color='red'>Максимальное количество символов 150.</font></center>";
        }else echo "<center><font color='red'>Разрешено оставлять только 1 комментарий!</font></center>";
       
        }else echo "<center><font color='red'>Недостаточно средств.</font></center>";
    }else echo "<center><font color='red'>Введите текст комментария.</font></center>";
}
?>
<table class="ta" width="60%" align="center"><tr><td>
<form method="post" action="">
<label><b><center>Введите текст комментария (~ 150 символов)</b></center></label>
<br>
<textarea class="form-control" name="comment" rows="3" cols="40"></textarea>
<center>
<input type="submit" class="btn btn-success" name="com_send" value="Добавить комментарий" /></center>
</form></td></tr>
<tr><td><center class="alert alert-info">За комментарий снимается 10 сатоши.</center></td></tr>
</table>
<br/>
</span>

<?php
}


//Delete Otziv
if(isset($_POST["delotz"]) AND isset($_POST["del_id"]))
{
    $idd = intval($_POST["del_id"]);
    if($usid == 1)
    {
        $db->Query("DELETE FROM db_blogs_com WHERE news_id = '$eid' AND user_id = '$idd'");
        echo('<center>Комментарий успешно удалён!</center>');
    }
}



$db->Query("SELECT * FROM db_blogs_com WHERE news_id = '$eid'");
if($db->NumRows() > 0) {

$num = 20;
$page = $_GET['page'];
$result00 = $db->Query("SELECT COUNT(*) FROM db_blogs_com WHERE news_id = '$eid'");
$temp = $db->FetchArray($result00);
$posts = $temp[0];
$total = (($posts - 1) / $num) + 1;
$total =  intval($total);
$page = intval($page);
if(empty($page) or $page < 0) $page = 1;
if($page > $total) $page = $total;
$start = $page * $num - $num;       
       
$db->Query("SELECT * FROM db_blogs_com WHERE news_id = '$eid' ORDER BY id DESC LIMIT $start, $num");

while($otziv = $db->FetchArray()) {
?>
<table width="550px" border="0" align="center" cellspacing="0" class="ta">
<tr>
<td valign="top" class="nobdr">
<div class="alert bg-light">
<sup><?=date('d-m-Y H:i', $otziv['date']); ?> комментарий от
<b><a href='/user/<?=$otziv['login']; ?>' target='_blank'><?=$otziv['login']; ?></a></b></sup>
<br>
<div style="margin: 3px 0;padding: 10px;border: 1px solid #eee;border-radius: 4px;background: #fff;"><?=$otziv['text']; ?></div>
<?php
$by_user_id = $otziv['user_id'];
if($usid == 1) { ?>
            <form action="" method="post">
            <input type="hidden" name="del_id" value="<?=$by_user_id;?>">
            <input type="submit" name="delotz" class="btn btn-danger" value="Удалить" />
            </form>
    <?    }  ?>
</div>

</td>
</tr>
</table>



<?php
} 
// Вывод меню если страниц больше одной

if ($total > 1)
{
Error_Reporting(E_ALL & ~E_NOTICE);

}
} else {
echo '<tr><td align="center" colspan="6"><font color="green" size="+1"><center><b>Комментариев еще не было!</b></center></font></td></tr><br />';
}
?>

</div>


<?PHP
return;
}

$db->Query("SELECT * FROM db_blogs");
if($db->NumRows() > 0) {

######### Список всех новостей
$num2 = 10;
$page = $_GET['page'];
$result00 = $db->Query("SELECT COUNT(*) FROM db_blogs");
$temp = $db->FetchArray($result00);
$posts = $temp[0];
$total = (($posts - 1) / $num2) + 1;
$total =  intval($total);
$page = intval($page);
if(empty($page) or $page < 0) $page = 1;
if($page > $total) $page = $total;
$start = $page * $num2 - $num2;       

$db->Query("SELECT * FROM db_blogs ORDER BY id DESC LIMIT $start, $num2");



while($news = $db->FetchArray()) {

    ?>
<div class="card bg-light">
<h4 class="card-header"><span class="fa fa-angle-double-right"></span> <a title="Нажмите чтобы прочитать..." href="/blogs/id/<?=$news["id"];?>"><?=$news["title"]; ?></a></h4>
<div class="card-footer">Дата размещения: <strong><?=date("d.m.Y",$news["date_add"]); ?></strong></div>
</div>



<BR />

<?PHP

}

// Проверяем нужны ли стрелки назад
if ($page != 1) $pervpage = '<a href=/blogs/p/1>Первая</a> | <a href=/blogs/p/'. ($page - 1) .'>Предыдущая</a> | ';
// Проверяем нужны ли стрелки вперед
if ($page != $total) $nextpage = ' | <a href=/blogs/p/'. ($page + 1) .'>Следующая</a> | <a href=/blogs/p/' .$total. '>Последняя</a>';

// Находим две ближайшие станицы с обоих краев, если они есть
if($page - 5 > 0) $page5left = ' <a href=/blogs/p/'. ($page - 5) .'>'. ($page - 5) .'</a> | ';
if($page - 4 > 0) $page4left = ' <a href=/blogs/p/'. ($page - 4) .'>'. ($page - 4) .'</a> | ';
if($page - 3 > 0) $page3left = ' <a href=/blogs/p/'. ($page - 3) .'>'. ($page - 3) .'</a> | ';
if($page - 2 > 0) $page2left = ' <a href=/blogs/p/'. ($page - 2) .'>'. ($page - 2) .'</a> | ';
if($page - 1 > 0) $page1left = '<a href=/blogs/p/'. ($page - 1) .'>'. ($page - 1) .'</a> | ';

if($page + 5 <= $total) $page5right = ' | <a href=/blogs/p/'. ($page + 5) .'>'. ($page + 5) .'</a>';
if($page + 4 <= $total) $page4right = ' | <a href=/blogs/p/'. ($page + 4) .'>'. ($page + 4) .'</a>';
if($page + 3 <= $total) $page3right = ' | <a href=/blogs/p/'. ($page + 3) .'>'. ($page + 3) .'</a>';
if($page + 2 <= $total) $page2right = ' | <a href=/blogs/p/'. ($page + 2) .'>'. ($page + 2) .'</a>';
if($page + 1 <= $total) $page1right = ' | <a href=/blogs/p/'. ($page + 1) .'>'. ($page + 1) .'</a>';

// Вывод меню если страниц больше одной

if ($total > 1)
{
Error_Reporting(E_ALL & ~E_NOTICE);
echo "<div class=\"pstrnav\">";
echo $pervpage.$page5left.$page4left.$page3left.$page2left.$page1left.'<b>'.$page.'</b>'.$page1right.$page2right.$page3right.$page4right.$page5right.$nextpage;
echo "</div>";
}

}else echo "<center>Блогов нет :(</center>";
?>

</div>