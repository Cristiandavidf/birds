<?php
define('TIME', time());
header("Content-Type: text/html; charset=utf-8");

$_OPTIMIZATION["title"] = "Серфинг";
$_OPTIMIZATION["description"] = "Заработок без вложений на просмотре сайтов, серфинг сайтов.";
$_OPTIMIZATION["keywords"] = "серфинг, фф, заработок на серфинге,платящие буксы, серфинги";

$usid = $_SESSION["user_id"];
$usname = $_SESSION["user"];

$db->Query("SELECT * FROM db_users_a WHERE id = '".$_SESSION['user_id']."'");
$users_info = $db->FetchArray();

    if (isset($_GET['delete']))
    {
        $id = (int)$_GET['delete'];

        #if (isset($_SESSION['admin']))
        if ($config->serfIdAdmin() == $_SESSION["user_id"])
        {
            $db->query("SELECT `money`, `user_name` FROM `db_serfing` WHERE id = '".$id."' LIMIT 1");

            $result = $db->FetchArray();

            $db->query("UPDATE db_users_b SET money_b = money_b + '".$result['money']."' WHERE user = '".$result['user_name']."'");

            $db->query("DELETE FROM db_serfing WHERE id = '".$id."'");
            #$db->query("DELETE FROM db_serfing_view WHERE ident = '".$id."'");
        }
    }
?>
<div class="title">
	<h3>Серфинг заработок</h3>
	<p>Просматривайте ссылки рекламодателей и получайте деньги, это отличный способ заработка без вложений!</p>
</div>


<div class="container">
<?php
    $db->query("SELECT ident, time_add FROM db_serfing_view WHERE user_id = '$usid' AND time_add + INTERVAL 24*60*60 SECOND > NOW()");

    while ($row_view = $db->FetchArray())
    {
        $visits[$row_view['ident']] = $row_view;
    }

    $db->Query("SELECT * FROM db_serfing WHERE `money` >= `price` and `status` = '2' ORDER BY high DESC, wind DESC, money DESC, time_add DESC");

    if ($db->NumRows())
    {
        while ($row = $db->FetchArray())
        {

            if (isset($visits[$row['id']])) continue;

            if ($row['speed'] > 1)
            {
                if (mt_rand(1, $row['speed']) != 1) continue;
            }

            $high = ($row['high']) ? 'bg-warning' : 'bg-light';
            $pay_user = number_format($row['price'] - $row['price'] * (30/100), 2); //оплата пользователю

            if ($row['id'] == 2) {
?>

<?php

            }else{

?>
<div id="tr<?=$row['id']; ?>" class="serf">
<div class="row" id="<?=$row['id']; ?>">
<div class="col-sm-10 normalm">
<h4><img src="https://www.google.com/s2/favicons?domain=<?=$row['url']; ?>"> <a href="<?=$row['url']; ?>" onclick="showFrame(this, '<?php echo $row['id']; ?>');" class="serf-title" title="Начать просмотр сайта"><?=$row['title']; ?> </a> </h4>
<h6><i><span class="text-danger"><i class="fa fa-clock-o"></i> Время просмотра: <?=$row['timer']; ?> сек.</span>
<?=($row['wind'] == 1) ? '<span class="text-info"><i class="fa fa-tv"></i> Активное окно</span>' : '';?>

<span class="pull-right" style="padding-right: 0;">Осталось <?php echo (int)($row['money']/$row['price']); ?> просмотров
</span>
</i></h6></div>
<div class="col-sm-2 <?=$high; ?>">
<h2 class="serf-cent"><i class="fa fa-money"></i> <?=$pay_user; ?></h2>
</div>

</div>
</div>
<?php
            }
        }
    }
    else
    {
        echo "<center><h3>Нет ссылок для просмотра</h3></center>";
    }
 
?>
<br/>
<center class="row">
    <div class="col-lg-6"></div>
    <div class="col-lg-6"></div>
</center><br/>
</div>

